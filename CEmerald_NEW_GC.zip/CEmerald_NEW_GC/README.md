# emeraldc — an Intel-syntax x86-64 compiler for Emerald (Linux · macOS · Windows)

`emeraldc` compiles the [Emerald programming language](https://github.com/Dr-Cosmic/Emerald)
to native x86-64 executables, always emitting **Intel assembler syntax**
(`.intel_syntax noprefix`), on and for three operating systems:

| target      | object format | calling convention                          | assembled & linked by |
|-------------|---------------|---------------------------------------------|-----------------------|
| **linux**   | ELF           | System V AMD64                              | `g++` (GNU as)        |
| **macos**   | Mach-O        | System V AMD64, `_`-mangled symbols         | `clang++`             |
| **windows** | COFF (PE)     | Microsoft x64 (RCX/RDX/R8/R9 + 32-byte shadow space) | MinGW-w64 `g++` (GNU as) |

It is derived from the CEmerald `emeraldc` compiler
(`CEmerald_x86_ATT_x86_Intel_ARM.zip` in
[Dr-Cosmic/CEmerald](https://github.com/Dr-Cosmic/CEmerald)), which targeted
Linux only (x86-64 in AT&T syntax, AArch64, and i686 in Intel syntax).  This
edition keeps that compiler's proven architecture — the reference
interpreter's own lexer and parser as the front end, the interpreter's value
model, environments, builtins, SQL engine and JSON store linked verbatim into
the runtime library (`libemrt-<os>.a`), and a single AST walk driving small
emission helpers — and replaces the back end with one x86-64 Intel-syntax
code generator parameterised by the target OS ABI.  The runtime and the
`vendored/` interpreter sources are carried over byte-for-byte.

Because the front end and runtime *are* the reference implementation,
compiled programs are observationally equivalent to the interpreter: same
output, same runtime-error messages (with line **and** column), same exit
codes.  A compiled `fib(27)` runs ~2.5× faster than the interpreter.

---

## 1. Getting the sources

```sh
git clone https://github.com/Dr-Cosmic/Emerald     # reference repo (tests/examples)
# put this directory (emeraldc-intel) next to it, e.g.:
#   parent/
#     Emerald/
#     emeraldc-intel/
```

The side-by-side layout is only needed for `make test`; the compiler itself
is self-contained.

## 2. Building and running

### Linux (Debian, Ubuntu, Fedora, RHEL, …)

```sh
# Debian/Ubuntu prerequisites:   sudo apt install g++ make
# Fedora/RHEL prerequisites:     sudo dnf install gcc-c++ make

cd emeraldc-intel
make                                   # build/emeraldc + build/libemrt-linux.a

build/emeraldc ../Emerald/examples/hello.em -o hello
./hello
```

### macOS (Intel **and** Apple Silicon)

```sh
xcode-select --install                 # Command Line Tools (clang++, make)

cd emeraldc-intel
make                                   # build/emeraldc + build/libemrt-macos.a

build/emeraldc ../Emerald/examples/hello.em -o hello
./hello
```

Everything is built for x86-64 (that is what the code generator emits).  On
Apple Silicon the toolchain cross-builds this transparently and both the
compiler and the programs it produces run under Rosetta 2 — install it once
with `softwareupdate --install-rosetta` if you have never run an Intel binary.

### Windows 10/11 (MSYS2 / MinGW-w64)

The compiler drives GNU `as` and `g++`, so the supported Windows toolchain is
MinGW-w64, most easily via [MSYS2](https://www.msys2.org):

1. Install MSYS2, then open the **“MSYS2 UCRT64”** shell and install the
   toolchain:

   ```sh
   pacman -S --needed make mingw-w64-ucrt-x86_64-gcc
   ```

2. Build and use exactly as on Unix (still in the UCRT64 shell):

   ```sh
   cd emeraldc-intel
   make                               # build/emeraldc.exe + build/libemrt-windows.a

   build/emeraldc.exe ../Emerald/examples/hello.em -o hello.exe
   ./hello.exe
   ```

Produced `.exe` files are **statically linked** — they run on any 64-bit
Windows machine (or under Wine) with no MinGW DLLs.
`emeraldc.exe` itself only needs `g++` on `PATH` when it links, which the
UCRT64 shell provides; a plain `cmd.exe` works too if you add
`C:\msys64\ucrt64\bin` to `PATH`.

### Cross-compiling Windows programs from Linux

```sh
sudo apt install g++-mingw-w64-x86-64        # Fedora: mingw64-gcc-c++
make windows-runtime                          # build/libemrt-windows.a
build/emeraldc prog.em --target=windows -o prog.exe
wine ./prog.exe                               # or copy to a Windows box
```

## 3. Usage

```
emeraldc file.em [-o out] [--target=linux|macos|windows|native]
                 [-S out.s] [--keep-asm] [-v]
```

* `--target` defaults to the host OS (`native`).
* `-S out.s` writes the generated Intel-syntax assembly (and still links if
  the target's runtime library and toolchain are available; otherwise it
  succeeds with the assembly alone — handy for cross-OS inspection).
* `--keep-asm` keeps the assembly next to the output as `<out>.s`.
* Environment: `EMERALDC_HOME` — directory containing `libemrt-<os>.a`
  (default: next to the `emeraldc` binary); `EMERALDC_CXX` — override the
  assemble-and-link command (e.g. an osxcross `o64-clang++`).
* Imports are resolved at compile time exactly as in the original: every
  `import`ed module (`<name>.em` / `<name>.emerald` beside the script, then
  the CWD) is compiled into the same executable, with runtime init-on-first-
  import, caching and circular-import detection.

## 4. Testing

`scripts/run_tests.sh` compiles every program in the reference repo's
`tests/` and byte-compares the output with the interpreter's `.expected`
files (set `EMERALD_REPO` if the clone is not at `../Emerald`):

```sh
make test              # host-native suite (Linux, macOS, or Windows/MSYS2)
make test-windows      # on Linux: cross-compiled .exe suite, run under Wine
```

On Windows the comparison strips the `\r` that the Microsoft CRT's text-mode
stdout adds to every line; the bytes are otherwise identical.

## 5. What is compiled vs. what is runtime

Generated machine code natively handles statement sequencing,
`if`/`elif`/`else`, all three loop forms with `break`/`continue` as jumps,
function bodies, class bodies and parent-constructor argument thunks,
short-circuit `&&`/`||`, `return`, and all call/argument marshalling.  The
runtime ABI (`src/rt.cpp`) supplies the dynamic semantics — Emerald's numeric
tower, loose/strict equality, string interpolation, arrays with nil-gap
growth and gather indexing, member/index access, typed declarations with
coercion, classes with inheritance, closures, `for … in`, modules — as
faithful ports or direct reuse of interpreter code, and every builtin
(`print`, `len`, the math library, `getinput`, `shellexec`,
`sqlexec`/`execsql`, `File`, …) is the interpreter's own `builtins.cpp`,
unmodified.  Three tiny vendored patches (marked `[emeraldc]`) provide the
native entry points; everything else in `vendored/` is byte-identical to
upstream.

### The one back end, three ABIs

Frames are `rbp`-based with a fixed `rsp`: an outgoing call area at the
bottom (System V: 16 bytes for the single seven-argument runtime call's
stack argument; Windows: the mandatory 32-byte shadow space plus any stack
arguments beyond the four register arguments), the argv scratch area above
it, and value slots below `rbp`.  Entry `rsp ≡ 8 (mod 16)`, `push rbp`, and a
16-byte-multiple frame keep every call site 16-byte aligned as both ABIs
require, with no dynamic pushes.  Argument registers are
RDI/RSI/RDX/RCX/R8/R9 (System V) or RCX/RDX/R8/R9 (Windows); R10 is the only
scratch register, volatile in both ABIs, and the Windows callee-saved
RSI/RDI are never touched on that target.  Object-format differences are
confined to symbol mangling (`_` on Mach-O), local-label prefixes (`L` on
Mach-O, `.L` elsewhere), and section directives (`.rodata` / `.rdata,"dr"` /
`__TEXT,__cstring`); constant `Value*` slots live as zero quads in `.data`,
which behaves identically in all three formats.  C++ exceptions never unwind
through generated frames: every runtime entry point traps `EmeraldError`,
reports it in the interpreter's format, and exits.

### Memory management

The runtime includes a precise, stop-the-world, non-moving garbage
collector.  It only has two jobs, because the deep object graph (arrays,
objects, closures, class/module data) is `shared_ptr` reference-counted by
the vendored interpreter code and reclaims itself: the collector frees dead
*Value boxes* (the temporaries generated code holds raw pointers to) and
drops *environment pins* no generated frame references, after which
reference counting cascades through everything else.  Anything that must
survive — closure environments, module environments, values stored in
containers — is held by `shared_ptr` from the object graph itself and is
unaffected by unpinning.

Every generated function registers its frame (`em_frame_enter` /
`em_frame_leave`, ~4 instructions per activation), and the collector scans
exactly the live frames' slot/argv/outgoing words.  A word is treated as a
root only if it is a live slot in the box slabs or a key in the pin table,
which makes integers, garbage and stale slot contents harmless; the worst
case is that a dead value is briefly retained until its slot is reused.
Boxes are allocated from 16-byte slots in fixed-size slabs with
used/mark/immortal bitmaps — allocation is a bit-scan, membership a binary
search plus a bit test, and the sweep a word-at-a-time bitmap walk with no
per-box `malloc`/`free`.  Slot recycling keeps the hot allocation path in
cache; in practice allocation-heavy programs run *faster* with the
collector on than off.  Collection is triggered inside `box()` before the
new allocation is registered, so an in-flight allocation can never be swept
by the collection its own birth triggered.  Startup constants are installed
via `em_const_store`, which marks them immortal.  Because Emerald has no
finalisers, weak references or lifetime-observing constructs, collection is
semantically invisible: it cannot change program output.

Environment variables (read at program start):

| variable | effect |
|---|---|
| `EMERALDC_NO_GC=1` | disable collection entirely (v1 pin-forever behaviour) |
| `EMERALDC_GC_STRESS=1` | collect on **every** allocation (testing/debugging) |
| `EMERALDC_GC_THRESHOLD=N` | first collection after N allocations (default 65536; thereafter adaptive at 2× the live set) |
| `EMERALDC_GC_STATS=1` | print collector statistics to stderr at exit |

## 6. Verification status

* **Linux x86-64** — the reference repo's full suite (`tests/test_*.em`, 11
  files) and all runnable `examples/` pass **byte-identically**, as do
  runtime-error diagnostics (message, line, column) and exit codes.
* **Windows x86-64** — the identical battery passes with cross-built `.exe`
  files under Wine 9 (modulo the CRT's `\r\n` text mode), including
  `shellexec`, file I/O and the SQL engine; the compiler itself also builds
  and runs as a native Windows program.
* **macOS x86-64** — every test and example compiles to assembly that
  `clang -target x86_64-apple-macos11` assembles cleanly, with all symbols
  correctly `_`-mangled and only the expected Mach-O relocation types
  (BRANCH / SIGNED / SIGNED_4 / UNSIGNED); the runtime builds under clang++.
  This port was validated with Apple's toolchain but not executed on Apple
  hardware — if anything misbehaves, `-S` plus an issue report is welcome.
* **Garbage collector** — the full Linux and Windows suites also pass
  byte-identically under `EMERALDC_GC_STRESS=1` (a collection on **every**
  allocation), as do a closure/object-retention stress program and a torture
  program covering closures, inheritance, iterators and SQL (~175,000
  collections in one run, peak live boxes under 100).  The same battery
  linked against an AddressSanitizer build of the runtime reports **zero
  memory errors** under per-allocation collection.  A 1,000,000-iteration
  allocation loop runs in a steady ~23 MB with the collector on; with
  `EMERALDC_NO_GC=1` the same program exceeds 3.8 GB and is OOM-killed.
  `fib(27)`: ~1.0 s with GC on, ~1.7 s with GC off (slot recycling beats
  `operator new`), ~4.2 s interpreted.

## 7. Limitations

The collector is stop-the-world and non-moving; a value whose address
lingers in an already-dead slot is retained until the slot is reused
(bounded, conservative-by-membership behaviour — never unsafe, occasionally
generous).  Variable access walks environment chains for exact
scoping/closure semantics.  The REPL remains the interpreter's domain.
Only x86-64 is emitted; on Apple Silicon, programs run under Rosetta 2.

## 8. License

Emerald is GPL-3.0; `emeraldc` vendors and links its sources and is
therefore distributed under GPL-3.0 as a derivative work.  See `LICENSE`.
