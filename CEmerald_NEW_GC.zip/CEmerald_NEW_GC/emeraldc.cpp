// emeraldc.cpp - A native-code compiler for the Emerald language.
//                Intel-syntax x86-64 edition for Linux, macOS and Windows.
//
// Author: Jean-Jacques François Reibel
// Derived from the CEmerald `emeraldc` compiler (x86-64 AT&T / AArch64 /
// i686-Intel, Linux-only).  This edition keeps that compiler's front end,
// runtime and code-generation structure, and replaces the back end with a
// single x86-64 code generator that always emits Intel assembler syntax
// (`.intel_syntax noprefix`) and knows three operating-system ABIs:
//
//   linux    ELF,    System V AMD64 ABI            (GNU as via g++)
//   macos    Mach-O, System V AMD64 ABI, `_`-mangled symbols (clang++)
//   windows  COFF,   Microsoft x64 ABI (RCX/RDX/R8/R9 + 32-byte shadow
//            space), MinGW-w64 (GNU as via g++)
//
// Front end: the reference implementation's own lexer & parser (vendored),
// so emeraldc accepts exactly the language the interpreter accepts.
// Back end: a single AST walk; every machine instruction is produced by
// small emission helpers that consult the target OS for calling convention,
// symbol mangling and object-format directives.  Dynamic-language operations
// call the runtime ABI implemented in rt.cpp, which is portable C++ and is
// compiled once per OS into libemrt-<os>.a.
//
// Usage: emeraldc file.em [-o out] [--target=linux|macos|windows|native]
//                         [-S asm.s] [--keep-asm] [-v]

#include "../vendored/lexer.h"
#include "../vendored/parser.h"
#include "../vendored/ast.h"
#include "../vendored/errors.h"

#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <filesystem>
#include <fstream>
#include <functional>
#include <map>
#include <memory>
#include <sstream>
#include <string>
#include <unordered_map>
#include <vector>

#if defined(_WIN32)
  #include <process.h>
  #include <windows.h>
  #define EMC_GETPID _getpid
#else
  #include <unistd.h>
  #define EMC_GETPID getpid
#endif
#if defined(__APPLE__)
  #include <mach-o/dyld.h>
#endif

using namespace emerald;

enum class TargetOS { Linux, MacOS, Windows };

struct CompileError {
    std::string msg;
    int line, col;
};

//======================= assembly text helpers =======================

static std::string escAsm(const std::string& s) {
    std::string out;
    for (unsigned char c : s) {
        if (c == '"' || c == '\\') { out += '\\'; out += static_cast<char>(c); }
        else if (c >= 32 && c < 127) out += static_cast<char>(c);
        else {
            char buf[8];
            std::snprintf(buf, sizeof buf, "\\%03o", c);
            out += buf;
        }
    }
    return out;
}

//======================= per-function emission context =======================

enum class FnKind { Top, Fn, Body, Pargs };

struct FuncCtx {
    std::string label;
    FnKind kind;
    std::ostringstream o;          // body text with placeholders
    int nextSlot = 0, maxSlots = 0;
    std::vector<int> freeSlots;
    int maxArgs = 0;               // argv scratch entries
    int envSlot = -1;              // slot holding current Environment*
    int outSlot = -1;              // Pargs: slot holding Value** out
    std::string retLabel;
    struct Loop { std::string brk, cont; };
    std::vector<Loop> loops;
    int maxStackArgs = 0;          // windows: outgoing stack arguments beyond RCX..R9

    int alloc() {
        if (!freeSlots.empty()) { int s = freeSlots.back(); freeSlots.pop_back(); return s; }
        int s = nextSlot++;
        if (nextSlot > maxSlots) maxSlots = nextSlot;
        return s;
    }
    void free(int s) { if (s >= 0) freeSlots.push_back(s); }
};

// A pending function to emit (worklist keeps buffers independent).
struct Pending {
    std::string label;
    FnKind kind;
    Node* node;         // FnDecl (Fn), ClassDecl (Body/Pargs), or nullptr (Top)
};

//======================= the code generator =======================

class CodeGen {
public:
    explicit CodeGen(TargetOS t) : os_(t) {}

    std::string compile(Program& mainProg,
                        std::vector<std::pair<std::string, Program*>>& modules) {
        std::vector<std::pair<std::string, std::string>> moduleInits;
        for (auto& m : modules) {
            std::string lbl = "emmod_" + std::to_string(fnCounter_++);
            moduleInits.push_back({m.first, lbl});
            pending_.push_back({lbl, FnKind::Top, nullptr});
            pendingTop_[lbl] = &m.second->statements;
        }
        pending_.push_back({"emtop", FnKind::Top, nullptr});
        pendingTop_["emtop"] = &mainProg.statements;

        while (!pending_.empty()) {
            Pending p = pending_.front();
            pending_.erase(pending_.begin());
            emitFunction(p);
        }
        emitConstsFn();
        emitMain(moduleInits);

        std::ostringstream out;
        out << "\t.intel_syntax noprefix\n";
        out << rodata_.str();
        out << data_.str();
        out << "\t.text\n";
        out << text_.str();
        if (os_ == TargetOS::Linux)
            out << "\t.section .note.GNU-stack,\"\",@progbits\n";
        if (os_ == TargetOS::MacOS)
            out << ".subsections_via_symbols\n";
        return out.str();
    }

private:
    TargetOS os_;
    int fnCounter_ = 0, labelCounter_ = 0, strCounter_ = 0, constCounter_ = 0,
        arrCounter_ = 0;
    std::ostringstream rodata_, data_, text_;
    std::vector<Pending> pending_;
    std::unordered_map<std::string, std::vector<NodePtr>*> pendingTop_;
    std::unordered_map<std::string, std::string> strLabels_;   // raw text -> label

    struct ConstSpec {
        enum Kind { Int, Float, Char, Str } kind;
        long long imm = 0;         // value / bits / char code / string length
        std::string strLbl;        // Str: label of the character data
        std::string slot;          // slot receiving the built Value*
    };
    std::map<std::string, std::string> valueConsts_;           // key -> slot label
    std::vector<ConstSpec> constSpecs_;

    //--- symbols, labels and sections per object format ----------------------

    // Real (linker-visible) symbols: `_`-mangled on Mach-O.
    std::string sym(const std::string& s) const {
        return os_ == TargetOS::MacOS ? "_" + s : s;
    }
    // Assembler-local label prefix: Mach-O treats `L`, ELF/COFF treat `.L`.
    std::string lp() const { return os_ == TargetOS::MacOS ? "L" : ".L"; }

    std::string newLabel(const std::string& stem) {
        return lp() + stem + std::to_string(labelCounter_++);
    }
    const char* rodataSection() const {
        switch (os_) {
            case TargetOS::Linux:   return "\t.section .rodata\n";
            case TargetOS::Windows: return "\t.section .rdata,\"dr\"\n";
            default:                return "\t.section __TEXT,__cstring,cstring_literals\n";
        }
    }

    // ---- constants ----
    std::string strLabel(const std::string& s) {
        auto it = strLabels_.find(s);
        if (it != strLabels_.end()) return it->second;
        std::string lbl = lp() + "c" + std::to_string(strCounter_++);
        rodata_ << rodataSection() << lbl << ":\n\t.asciz \"" << escAsm(s)
                << "\"\n";
        strLabels_[s] = lbl;
        return lbl;
    }
    std::string valueConst(const std::string& key, ConstSpec spec) {
        auto it = valueConsts_.find(key);
        if (it != valueConsts_.end()) return it->second;
        std::string lbl = lp() + "Vc" + std::to_string(constCounter_++);
        // Zero-initialised Value* written once by em_consts at startup: a
        // plain .data quad is identical on ELF, Mach-O and COFF.
        data_ << "\t.data\n\t.p2align 3\n" << lbl << ":\n\t.quad 0\n";
        spec.slot = lbl;
        constSpecs_.push_back(spec);
        valueConsts_[key] = lbl;
        return lbl;
    }
    std::string intConst(long long v) {
        return valueConst("i:" + std::to_string(v), {ConstSpec::Int, v, "", ""});
    }
    std::string floatConst(double d) {
        long long bits;
        std::memcpy(&bits, &d, 8);
        return valueConst("f:" + std::to_string(bits), {ConstSpec::Float, bits, "", ""});
    }
    std::string charConst(char c) {
        long long v = (long long)(unsigned char)c;
        return valueConst("c:" + std::to_string(v), {ConstSpec::Char, v, "", ""});
    }
    std::string stringConst(const std::string& s) {
        std::string cl = strLabel(s);
        return valueConst("s:" + s, {ConstSpec::Str, (long long)s.size(), cl, ""});
    }
    std::string paramArray(const std::vector<Param>& params) {
        std::string lbl = lp() + "PN" + std::to_string(arrCounter_++);
        data_ << "\t.data\n\t.p2align 3\n" << lbl << ":\n";
        for (auto& p : params) data_ << "\t.quad\t" << strLabel(p.name) << "\n";
        if (params.empty()) data_ << "\t.quad\t0\n";
        return lbl;
    }

    //======================= x86-64 emission primitives =======================
    //
    // Frame layout (identical shape on all three ABIs; rbp-based, fixed rsp):
    //
    //   [rbp-8]                      8-byte hole (keeps slot maths simple)
    //   [rbp-16-8*s]                 value slot s            (grows down)
    //   ...alignment slack...
    //   [rsp+outBytes+8*j]           argv scratch entry j    (grows up)
    //   [rsp+0 .. outBytes-1]        outgoing call area:
    //                                  SysV:  16 bytes (the one 7-argument
    //                                         runtime call's stack argument)
    //                                  Win64: 32-byte shadow space +
    //                                         8*maxStackArgs
    //
    // Entry rsp === 8 (mod 16); `push rbp` makes it 0; the frame is a
    // multiple of 16, so rsp is 16-byte aligned at every call site, as both
    // the System V and Microsoft x64 ABIs require.  No dynamic pushes.

    struct Arg {
        enum K { Slot, Imm, Lea, Argv, ConstSlot, NullPtr } k;
        long long imm = 0;
        int slot = -1;
        std::string label;
        static Arg S(int s)                { Arg a; a.k = Slot;      a.slot = s;  return a; }
        static Arg I(long long v)          { Arg a; a.k = Imm;       a.imm = v;   return a; }
        static Arg L(const std::string& l) { Arg a; a.k = Lea;       a.label = l; return a; }
        static Arg AV()                    { Arg a; a.k = Argv;                   return a; }
        static Arg C(const std::string& l) { Arg a; a.k = ConstSlot; a.label = l; return a; }
        static Arg P0()                    { Arg a; a.k = NullPtr;                return a; }
    };

    int nRegArgs() const { return os_ == TargetOS::Windows ? 4 : 6; }
    const char* argReg(size_t i) const {
        static const char* sysv[6] = {"rdi", "rsi", "rdx", "rcx", "r8", "r9"};
        static const char* win[4]  = {"rcx", "rdx", "r8", "r9"};
        return os_ == TargetOS::Windows ? win[i] : sysv[i];
    }
    std::string slotRef(int s) const {
        return "QWORD PTR [rbp-" + std::to_string(16 + 8 * s) + "]";
    }
    void loadArg(FuncCtx& f, const Arg& a, const char* reg) {
        switch (a.k) {
            case Arg::Slot:
                f.o << "\tmov\t" << reg << ", " << slotRef(a.slot) << "\n";
                break;
            case Arg::Imm:
                if (a.imm >= -2147483648LL && a.imm <= 2147483647LL)
                    f.o << "\tmov\t" << reg << ", " << a.imm << "\n";
                else
                    f.o << "\tmovabs\t" << reg << ", " << a.imm << "\n";
                break;
            case Arg::Lea:
                f.o << "\tlea\t" << reg << ", [rip+" << a.label << "]\n";
                break;
            case Arg::Argv:
                f.o << "\tlea\t" << reg << ", @AVB@\n";
                break;
            case Arg::ConstSlot:
                f.o << "\tmov\t" << reg << ", QWORD PTR [rip+" << a.label << "]\n";
                break;
            case Arg::NullPtr:
                f.o << "\tmov\t" << reg << ", 0\n";
                break;
        }
    }
    // Call a runtime function; the result (if any) lands in rax.
    void call(FuncCtx& f, const std::string& fn, std::vector<Arg> args) {
        int nreg = nRegArgs();
        for (size_t i = 0; i < args.size() && (int)i < nreg; i++)
            loadArg(f, args[i], argReg(i));
        for (size_t i = nreg; i < args.size(); i++) {
            loadArg(f, args[i], "r10");
            long long off = os_ == TargetOS::Windows
                          ? 32 + 8LL * (long long)(i - nreg)   // above shadow space
                          : 8LL * (long long)(i - nreg);
            f.o << "\tmov\tQWORD PTR [rsp+" << off << "], r10\n";
            if ((int)(i - nreg) + 1 > f.maxStackArgs)
                f.maxStackArgs = (int)(i - nreg) + 1;
        }
        callRaw(f, fn);
    }
    void callRaw(FuncCtx& f, const std::string& fn) {
        f.o << "\tcall\t" << sym(fn) << "\n";
    }
    int saveRet(FuncCtx& f) {
        int s = f.alloc();
        storeRetToSlot(f, s);
        return s;
    }
    void storeRetToSlot(FuncCtx& f, int s) {
        f.o << "\tmov\t" << slotRef(s) << ", rax\n";
    }
    // GC bookkeeping: every generated function reports its frame so the
    // collector can scan [rbp-frame, rbp) for live boxes and environments.
    // em_frame_leave takes and returns rax, so the function's return value
    // (box, count, or don't-care) passes through it untouched.
    void emitFrameEnter(FuncCtx& f) {
        f.o << "\tmov\t" << argReg(0) << ", rbp\n"
            << "\tmov\t" << argReg(1) << ", @FR@\n";
        callRaw(f, "em_frame_enter");
    }
    void emitFrameLeave(FuncCtx& f) {
        retToArg0(f);
        callRaw(f, "em_frame_leave");
    }
    // Stage the return value as the first argument of the next call.
    void retToArg0(FuncCtx& f) {
        f.o << "\tmov\t" << (os_ == TargetOS::Windows ? "rcx" : "rdi") << ", rax\n";
    }
    void branchIfRetZero(FuncCtx& f, const std::string& lbl) {
        f.o << "\ttest\trax, rax\n\tjz\t" << lbl << "\n";
    }
    void branchIfRetNonZero(FuncCtx& f, const std::string& lbl) {
        f.o << "\ttest\trax, rax\n\tjnz\t" << lbl << "\n";
    }
    void jmp(FuncCtx& f, const std::string& lbl) { f.o << "\tjmp\t" << lbl << "\n"; }
    void defLabel(FuncCtx& f, const std::string& lbl) { f.o << lbl << ":\n"; }
    // Copy already-evaluated slots into the argv scratch area. Slots are freed.
    void buildArgv(FuncCtx& f, std::vector<int>& slots) {
        if ((int)slots.size() > f.maxArgs) f.maxArgs = (int)slots.size();
        for (size_t j = 0; j < slots.size(); j++) {
            f.o << "\tmov\tr10, " << slotRef(slots[j]) << "\n";
            f.o << "\tmov\tQWORD PTR @AV" << j << "@, r10\n";
        }
        for (int s : slots) f.free(s);
    }
    void storeRetToOut(FuncCtx& f, int outSlot, size_t i) {   // Pargs: out[i] = ret
        f.o << "\tmov\tr10, " << slotRef(outSlot) << "\n";
        f.o << "\tmov\tQWORD PTR [r10+" << 8 * i << "], rax\n";
    }
    void emitPos(FuncCtx& f, Node* n) {
        call(f, "em_pos", {Arg::I(n->line), Arg::I(n->col)});
    }
    // Variant for sites where argument registers are already staged: writes
    // the position globals with direct memory-immediate stores (no registers).
    void emitPos2(FuncCtx& f, Node* n) {
        f.o << "\tmov\tQWORD PTR [rip+" << sym("em_line") << "], " << n->line << "\n";
        f.o << "\tmov\tQWORD PTR [rip+" << sym("em_col") << "], " << n->col << "\n";
    }

    [[noreturn]] void err(Node* n, const std::string& m) {
        throw CompileError{m, n->line, n->col};
    }

    //======================= expressions =======================

    int emitExpr(FuncCtx& f, Node* n) {
        switch (n->kind) {
            case NodeKind::IntLit: {
                loadArgToRet(f, Arg::C(intConst(static_cast<IntLit*>(n)->value)));
                return saveRet(f);
            }
            case NodeKind::FloatLit: {
                loadArgToRet(f, Arg::C(floatConst(static_cast<FloatLit*>(n)->value)));
                return saveRet(f);
            }
            case NodeKind::CharLit: {
                loadArgToRet(f, Arg::C(charConst(static_cast<CharLit*>(n)->value)));
                return saveRet(f);
            }
            case NodeKind::BoolLit:
                call(f, "em_bool", {Arg::I(static_cast<BoolLit*>(n)->value ? 1 : 0)});
                return saveRet(f);
            case NodeKind::NilLit:
                call(f, "em_nil", {});
                return saveRet(f);
            case NodeKind::StringLit: return emitStringLit(f, static_cast<StringLit*>(n));
            case NodeKind::ArrayLit: {
                auto* a = static_cast<ArrayLit*>(n);
                std::vector<int> slots;
                for (auto& e : a->elements) slots.push_back(emitExpr(f, e.get()));
                buildArgv(f, slots);
                call(f, "em_arraylit", {Arg::AV(), Arg::I((long long)a->elements.size())});
                return saveRet(f);
            }
            case NodeKind::Identifier:
                emitPos(f, n);
                call(f, "em_env_get", {Arg::S(f.envSlot),
                                       Arg::L(strLabel(static_cast<Identifier*>(n)->name))});
                return saveRet(f);
            case NodeKind::Binary:   return emitBinary(f, static_cast<Binary*>(n));
            case NodeKind::Unary: {
                auto* u = static_cast<Unary*>(n);
                if (u->op == "++" || u->op == "--")
                    return emitIncDec(f, u->operand.get(), u->op == "++" ? 1 : -1, true);
                int v = emitExpr(f, u->operand.get());
                const char* fn = u->op == "!" ? "em_not"
                               : u->op == "-" ? "em_neg"
                               : u->op == "+" ? "em_pos_op" : nullptr;
                if (!fn) err(n, "unsupported unary operator '" + u->op + "'");
                emitPos(f, n);
                call(f, fn, {Arg::S(v)});
                f.free(v);
                return saveRet(f);
            }
            case NodeKind::PostfixOp: {
                auto* p = static_cast<PostfixOp*>(n);
                return emitIncDec(f, p->operand.get(), p->op == "++" ? 1 : -1, false);
            }
            case NodeKind::Assign:   return emitAssign(f, static_cast<Assign*>(n));
            case NodeKind::Call:     return emitCall(f, static_cast<Call*>(n), false);
            case NodeKind::Index: {
                auto* ix = static_cast<Index*>(n);
                int obj = emitExpr(f, ix->object.get());
                std::vector<int> slots;
                for (auto& e : ix->indices) slots.push_back(emitExpr(f, e.get()));
                buildArgv(f, slots);
                emitPos(f, n);
                call(f, "em_index_get", {Arg::S(obj), Arg::AV(),
                                         Arg::I((long long)ix->indices.size())});
                f.free(obj);
                return saveRet(f);
            }
            case NodeKind::Member: {
                auto* m = static_cast<Member*>(n);
                int obj = emitExpr(f, m->object.get());
                emitPos(f, n);
                call(f, "em_member_get", {Arg::S(obj), Arg::L(strLabel(m->name))});
                f.free(obj);
                return saveRet(f);
            }
            default:
                err(n, "invalid expression");
        }
    }
    // Load an operand into rax (used for constant loads so the shared saveRet
    // path applies uniformly).
    void loadArgToRet(FuncCtx& f, const Arg& a) { loadArg(f, a, "rax"); }

    int emitStringLit(FuncCtx& f, StringLit* s) {
        if (s->parts.size() == 1 && !s->parts[0].isExpr) {
            loadArgToRet(f, Arg::C(stringConst(s->parts[0].literal)));
            return saveRet(f);
        }
        if (s->parts.empty()) {
            loadArgToRet(f, Arg::C(stringConst("")));
            return saveRet(f);
        }
        std::vector<int> slots;
        for (auto& part : s->parts) {
            if (part.isExpr) {
                slots.push_back(emitExpr(f, part.expr.get()));
            } else {
                loadArgToRet(f, Arg::C(stringConst(part.literal)));
                slots.push_back(saveRet(f));
            }
        }
        size_t n = slots.size();
        buildArgv(f, slots);
        call(f, "em_interp", {Arg::AV(), Arg::I((long long)n)});
        return saveRet(f);
    }

    int emitBinary(FuncCtx& f, Binary* b) {
        const std::string& op = b->op;
        if (op == "&&" || op == "||") {
            std::string lShort = newLabel("sc"), lEnd = newLabel("scend");
            int res = f.alloc();
            int l = emitExpr(f, b->left.get());
            call(f, "em_truthy", {Arg::S(l)});
            f.free(l);
            if (op == "&&") branchIfRetZero(f, lShort);
            else            branchIfRetNonZero(f, lShort);
            int r = emitExpr(f, b->right.get());
            call(f, "em_truthy", {Arg::S(r)});
            f.free(r);
            retToArg0(f);
            callRaw(f, "em_bool");
            storeRetToSlot(f, res);
            jmp(f, lEnd);
            defLabel(f, lShort);
            call(f, "em_bool", {Arg::I(op == "&&" ? 0 : 1)});
            storeRetToSlot(f, res);
            defLabel(f, lEnd);
            return res;
        }
        int l = emitExpr(f, b->left.get());
        int r = emitExpr(f, b->right.get());
        emitPos(f, b);
        if (op == "==")       call(f, "em_eq",  {Arg::S(l), Arg::S(r), Arg::I(0), Arg::I(0)});
        else if (op == "!=")  call(f, "em_eq",  {Arg::S(l), Arg::S(r), Arg::I(0), Arg::I(1)});
        else if (op == "===") call(f, "em_eq",  {Arg::S(l), Arg::S(r), Arg::I(1), Arg::I(0)});
        else if (op == "!==") call(f, "em_eq",  {Arg::S(l), Arg::S(r), Arg::I(1), Arg::I(1)});
        else if (op == "<")   call(f, "em_cmp", {Arg::S(l), Arg::S(r), Arg::I(0)});
        else if (op == "<=")  call(f, "em_cmp", {Arg::S(l), Arg::S(r), Arg::I(1)});
        else if (op == ">")   call(f, "em_cmp", {Arg::S(l), Arg::S(r), Arg::I(2)});
        else if (op == ">=")  call(f, "em_cmp", {Arg::S(l), Arg::S(r), Arg::I(3)});
        else if (op == "+")   call(f, "em_add",  {Arg::S(l), Arg::S(r)});
        else if (op == "-")   call(f, "em_sub",  {Arg::S(l), Arg::S(r)});
        else if (op == "*")   call(f, "em_mul",  {Arg::S(l), Arg::S(r)});
        else if (op == "/")   call(f, "em_div",  {Arg::S(l), Arg::S(r)});
        else if (op == "//")  call(f, "em_fdiv", {Arg::S(l), Arg::S(r)});
        else if (op == "%")   call(f, "em_mod",  {Arg::S(l), Arg::S(r)});
        else if (op == "**")  call(f, "em_pow",  {Arg::S(l), Arg::S(r)});
        else err(b, "unsupported binary operator '" + op + "'");
        f.free(l); f.free(r);
        return saveRet(f);
    }

    void emitStore(FuncCtx& f, Node* target, int valSlot) {
        emitPos(f, target);
        switch (target->kind) {
            case NodeKind::Identifier:
                call(f, "em_env_assign", {Arg::S(f.envSlot),
                     Arg::L(strLabel(static_cast<Identifier*>(target)->name)),
                     Arg::S(valSlot)});
                return;
            case NodeKind::Member: {
                auto* m = static_cast<Member*>(target);
                int obj = emitExpr(f, m->object.get());
                emitPos(f, target);
                call(f, "em_member_set", {Arg::S(obj), Arg::L(strLabel(m->name)),
                                          Arg::S(valSlot)});
                f.free(obj);
                return;
            }
            case NodeKind::Index: {
                auto* ix = static_cast<Index*>(target);
                if (ix->indices.size() != 1) { call(f, "em_index_set_multi_error", {}); return; }
                int obj = emitExpr(f, ix->object.get());
                int idx = emitExpr(f, ix->indices[0].get());
                emitPos(f, target);
                call(f, "em_index_set", {Arg::S(obj), Arg::S(idx), Arg::S(valSlot)});
                f.free(obj); f.free(idx);
                return;
            }
            default:
                err(target, "invalid assignment target");
        }
    }
    int emitLvalueGet(FuncCtx& f, Node* target) {
        if (target->kind == NodeKind::Identifier || target->kind == NodeKind::Member ||
            target->kind == NodeKind::Index)
            return emitExpr(f, target);
        err(target, "invalid target of '++'/'--'");
    }

    int emitAssign(FuncCtx& f, Assign* a) {
        int v = emitExpr(f, a->value.get());
        call(f, "em_assign_prepare", {Arg::S(v)});
        f.free(v);
        int prepared = saveRet(f);
        emitStore(f, a->target.get(), prepared);
        return prepared;
    }

    int emitIncDec(FuncCtx& f, Node* target, long long delta, bool prefix) {
        int oldv = emitLvalueGet(f, target);
        call(f, "em_incdec_next", {Arg::S(oldv), Arg::I(delta)});
        int next = saveRet(f);
        emitStore(f, target, next);
        if (prefix) { f.free(oldv); return next; }
        f.free(next);
        return oldv;
    }

    int emitCall(FuncCtx& f, Call* c, bool stmtCtx) {
        std::vector<int> argSlots;
        if (c->callee->kind == NodeKind::Member) {
            auto* m = static_cast<Member*>(c->callee.get());
            int recv = emitExpr(f, m->object.get());
            for (auto& a : c->args) argSlots.push_back(emitExpr(f, a.get()));
            size_t n = argSlots.size();
            buildArgv(f, argSlots);
            emitPos2(f, c);
            call(f, "em_method_call", {Arg::S(recv), Arg::L(strLabel(m->name)),
                                       Arg::AV(), Arg::I((long long)n),
                                       Arg::I(c->trailingComma ? 1 : 0),
                                       Arg::I(stmtCtx ? 1 : 0)});
            f.free(recv);
            return saveRet(f);
        }
        int callee = emitExpr(f, c->callee.get());
        for (auto& a : c->args) argSlots.push_back(emitExpr(f, a.get()));
        size_t n = argSlots.size();
        buildArgv(f, argSlots);
        emitPos2(f, c);
        call(f, "em_call_value", {Arg::S(callee), Arg::AV(), Arg::I((long long)n)});
        f.free(callee);
        return saveRet(f);
    }

    //======================= statements =======================

    bool isExprKind(NodeKind k) {
        switch (k) {
            case NodeKind::IntLit: case NodeKind::FloatLit: case NodeKind::CharLit:
            case NodeKind::StringLit: case NodeKind::BoolLit: case NodeKind::NilLit:
            case NodeKind::ArrayLit: case NodeKind::Identifier: case NodeKind::Binary:
            case NodeKind::Unary: case NodeKind::PostfixOp: case NodeKind::Assign:
            case NodeKind::Call: case NodeKind::Index: case NodeKind::Member:
                return true;
            default: return false;
        }
    }

    void emitBlockIn(FuncCtx& f, Block* b, int parentEnvSlot) {
        call(f, "em_env_new", {Arg::S(parentEnvSlot)});
        int child = saveRet(f);
        int saved = f.envSlot; f.envSlot = child;
        for (auto& st : b->statements) emitStmt(f, st.get());
        f.envSlot = saved; f.free(child);
    }

    void emitStmt(FuncCtx& f, Node* n) {
        emitPos(f, n);
        switch (n->kind) {
            case NodeKind::VarDecl:   emitVarDecl(f, static_cast<VarDecl*>(n)); return;
            case NodeKind::ExprStmt: {
                auto* es = static_cast<ExprStmt*>(n);
                int s;
                if (es->expr->kind == NodeKind::Call)
                    s = emitCall(f, static_cast<Call*>(es->expr.get()), true);
                else
                    s = emitExpr(f, es->expr.get());
                f.free(s);
                return;
            }
            case NodeKind::Block:
                emitBlockIn(f, static_cast<Block*>(n), f.envSlot);
                return;
            case NodeKind::FnDecl:    emitFnDecl(f, static_cast<FnDecl*>(n)); return;
            case NodeKind::ClassDecl: emitClassDecl(f, static_cast<ClassDecl*>(n)); return;
            case NodeKind::Return: {
                auto* r = static_cast<Return*>(n);
                int v;
                if (r->value) v = emitExpr(f, r->value.get());
                else { call(f, "em_nil", {}); v = saveRet(f); }
                call(f, "em_clone", {Arg::S(v)});          // ReturnSignal clones
                f.free(v);
                jmp(f, f.retLabel);
                return;
            }
            case NodeKind::If: {
                auto* s = static_cast<If*>(n);
                std::string lEnd = newLabel("ifend");
                for (auto& br : s->branches) {
                    std::string lNext = newLabel("ifnx");
                    if (br.condition) {
                        int c = emitExpr(f, br.condition.get());
                        call(f, "em_truthy", {Arg::S(c)});
                        f.free(c);
                        branchIfRetZero(f, lNext);
                    }
                    emitBlockIn(f, br.body.get(), f.envSlot);
                    jmp(f, lEnd);
                    defLabel(f, lNext);
                    if (!br.condition) break;
                }
                defLabel(f, lEnd);
                return;
            }
            case NodeKind::ForClassic: {
                auto* s = static_cast<ForClassic*>(n);
                call(f, "em_env_new", {Arg::S(f.envSlot)});
                int loopEnv = saveRet(f);
                int saved = f.envSlot; f.envSlot = loopEnv;
                if (s->init) {
                    if (isExprKind(s->init->kind)) { int t = emitExpr(f, s->init.get()); f.free(t); }
                    else emitStmt(f, s->init.get());
                }
                std::string lCond = newLabel("forc"), lCont = newLabel("forU"),
                            lBrk = newLabel("forX");
                defLabel(f, lCond);
                if (s->condition) {
                    int c = emitExpr(f, s->condition.get());
                    call(f, "em_truthy", {Arg::S(c)});
                    f.free(c);
                    branchIfRetZero(f, lBrk);
                }
                f.loops.push_back({lBrk, lCont});
                emitBlockIn(f, s->body.get(), loopEnv);
                f.loops.pop_back();
                defLabel(f, lCont);
                if (s->update) { int u = emitExpr(f, s->update.get()); f.free(u); }
                jmp(f, lCond);
                defLabel(f, lBrk);
                f.envSlot = saved; f.free(loopEnv);
                return;
            }
            case NodeKind::ForIn: {
                auto* s = static_cast<ForIn*>(n);
                int seq = emitExpr(f, s->iterable.get());
                call(f, "em_iter_begin", {Arg::S(seq)});
                f.free(seq);
                int iter = saveRet(f);
                call(f, "em_env_new", {Arg::S(f.envSlot)});
                int loopEnv = saveRet(f);
                std::string lNext = newLabel("finN"), lBrk = newLabel("finX");
                defLabel(f, lNext);
                call(f, "em_iter_next", {Arg::S(iter)});
                branchIfRetZero(f, lBrk);
                int el = saveRet(f);
                call(f, "em_env_define", {Arg::S(loopEnv), Arg::L(strLabel(s->varName)),
                                          Arg::S(el)});
                f.free(el);
                f.loops.push_back({lBrk, lNext});
                emitBlockIn(f, s->body.get(), loopEnv);
                f.loops.pop_back();
                jmp(f, lNext);
                defLabel(f, lBrk);
                f.free(loopEnv); f.free(iter);
                return;
            }
            case NodeKind::While: {
                auto* s = static_cast<While*>(n);
                std::string lCond = newLabel("whC"), lBrk = newLabel("whX");
                defLabel(f, lCond);
                int c = emitExpr(f, s->condition.get());
                call(f, "em_truthy", {Arg::S(c)});
                f.free(c);
                branchIfRetZero(f, lBrk);
                f.loops.push_back({lBrk, lCond});
                emitBlockIn(f, s->body.get(), f.envSlot);
                f.loops.pop_back();
                jmp(f, lCond);
                defLabel(f, lBrk);
                return;
            }
            case NodeKind::Import: {
                auto* s = static_cast<Import*>(n);
                if (s->isFrom)
                    call(f, "em_import_from", {Arg::S(f.envSlot),
                         Arg::L(strLabel(s->moduleName)), Arg::L(strLabel(s->symbolName))});
                else
                    call(f, "em_import", {Arg::S(f.envSlot),
                                          Arg::L(strLabel(s->moduleName))});
                return;
            }
            case NodeKind::Break:
                if (f.loops.empty()) err(n, "'break' used outside of a loop");
                jmp(f, f.loops.back().brk);
                return;
            case NodeKind::Continue:
                if (f.loops.empty()) err(n, "'continue' used outside of a loop");
                jmp(f, f.loops.back().cont);
                return;
            default: {
                int s = emitExpr(f, n);
                f.free(s);
                return;
            }
        }
    }

    void emitVarDecl(FuncCtx& f, VarDecl* d) {
        int init = -1;
        if (d->initializer) init = emitExpr(f, d->initializer.get());
        std::vector<int> ctorSlots;
        for (auto& a : d->ctorArgs) ctorSlots.push_back(emitExpr(f, a.get()));
        size_t nCtor = ctorSlots.size();
        if (nCtor) buildArgv(f, ctorSlots);
        emitPos(f, d);
        std::vector<Arg> args = {Arg::S(f.envSlot),
                                 Arg::L(strLabel(d->declaredType)),
                                 Arg::L(strLabel(d->name)),
                                 Arg::I(d->isArray ? 1 : 0)};
        args.push_back(init >= 0 ? Arg::S(init) : Arg::P0());
        args.push_back(nCtor ? Arg::AV() : Arg::P0());
        args.push_back(Arg::I((long long)nCtor));
        call(f, "em_vardecl", args);
        f.free(init);
    }

    void emitFnDecl(FuncCtx& f, FnDecl* d) {
        std::string lbl = "emfn_" + std::to_string(fnCounter_++);
        pending_.push_back({lbl, FnKind::Fn, d});
        std::string pn = paramArray(d->params);
        call(f, "em_fn_decl", {Arg::S(f.envSlot), Arg::L(strLabel(d->name)),
                               Arg::L(sym(lbl)), Arg::L(pn), Arg::I((long long)d->params.size())});
    }

    void emitClassDecl(FuncCtx& f, ClassDecl* d) {
        if (d->isObjectVarDecl) {
            call(f, "em_object_var_decl", {Arg::S(f.envSlot), Arg::L(strLabel(d->name))});
            return;
        }
        std::string bodyLbl = "emcb_" + std::to_string(fnCounter_++);
        pending_.push_back({bodyLbl, FnKind::Body, d});
        std::string pargsLbl;
        if (d->hasParent) {
            pargsLbl = "empa_" + std::to_string(fnCounter_++);
            pending_.push_back({pargsLbl, FnKind::Pargs, d});
        }
        std::string pn = paramArray(d->params);
        std::vector<Arg> args = {Arg::S(f.envSlot), Arg::L(strLabel(d->name)),
                                 Arg::L(pn), Arg::I((long long)d->params.size()),
                                 Arg::L(sym(bodyLbl))};
        args.push_back(d->hasParent ? Arg::L(strLabel(d->parentName)) : Arg::P0());
        args.push_back(d->hasParent ? Arg::L(sym(pargsLbl)) : Arg::P0());
        call(f, "em_class_decl", args);
    }

    //======================= whole functions =======================

    long long outBytes(const FuncCtx& f) const {
        // SysV: fixed 16 bytes covers the one 7-argument runtime call's stack
        // argument.  Win64: every call needs the 32-byte shadow space, plus
        // any stack arguments beyond RCX/RDX/R8/R9.
        return os_ == TargetOS::Windows ? 32 + 8LL * f.maxStackArgs : 16;
    }
    long long frameSize(const FuncCtx& f) const {
        long long frame = 8 + 8LL * f.maxSlots + 8LL * f.maxArgs + outBytes(f);
        return (frame + 15) & ~15LL;
    }
    std::string patchPlaceholders(const FuncCtx& f) const {
        std::string body = f.o.str();
        auto replaceAll = [&](const std::string& ph, const std::string& real) {
            size_t pos;
            while ((pos = body.find(ph)) != std::string::npos)
                body.replace(pos, ph.size(), real);
        };
        long long base = outBytes(f);           // argv sits just above outgoing
        for (int j = 0; j < f.maxArgs; j++)
            replaceAll("@AV" + std::to_string(j) + "@",
                       "[rsp+" + std::to_string(base + 8LL * j) + "]");
        replaceAll("@AVB@", "[rsp+" + std::to_string(base) + "]");
        replaceAll("@FR@", std::to_string(frameSize(f)));
        return body;
    }

    void emitFnHeader(const std::string& name) {
        text_ << "\t.globl\t" << sym(name) << "\n";
        if (os_ == TargetOS::Linux)
            text_ << "\t.type\t" << sym(name) << ", @function\n";
        text_ << sym(name) << ":\n";
    }
    void emitFnFooter(const std::string& name) {
        if (os_ == TargetOS::Linux)
            text_ << "\t.size\t" << sym(name) << ", .-" << sym(name) << "\n";
        text_ << "\n";
    }
    void emitPrologue(long long frame) {
        text_ << "\tpush\trbp\n\tmov\trbp, rsp\n"
              << "\tsub\trsp, " << frame << "\n";
    }
    void emitEpilogueText() { text_ << "\tmov\trsp, rbp\n\tpop\trbp\n\tret\n"; }

    void emitFunction(const Pending& p) {
        FuncCtx f;
        f.label = p.label;
        f.kind = p.kind;
        f.retLabel = lp() + "ret_" + p.label;
        f.envSlot = f.alloc();
        // Incoming arguments per the platform C ABI: (env) or (env, out).
        f.o << "\tmov\t" << slotRef(f.envSlot) << ", " << argReg(0) << "\n";
        if (p.kind == FnKind::Pargs) {
            f.outSlot = f.alloc();
            f.o << "\tmov\t" << slotRef(f.outSlot) << ", " << argReg(1) << "\n";
        }
        emitFrameEnter(f);

        if (p.kind == FnKind::Top) {
            for (auto& st : *pendingTop_[p.label]) emitStmt(f, st.get());
        } else if (p.kind == FnKind::Fn) {
            auto* d = static_cast<FnDecl*>(p.node);
            for (auto& st : d->body->statements) emitStmt(f, st.get());
        } else if (p.kind == FnKind::Body) {
            auto* d = static_cast<ClassDecl*>(p.node);
            for (auto& st : d->body->statements) emitStmt(f, st.get());
        } else { // Pargs
            auto* d = static_cast<ClassDecl*>(p.node);
            for (size_t i = 0; i < d->parentArgs.size(); i++) {
                emitPos(f, d->parentArgs[i].get());
                int v = emitExpr(f, d->parentArgs[i].get());
                call(f, "em_clone", {Arg::S(v)});
                f.free(v);
                storeRetToOut(f, f.outSlot, i);
            }
        }

        if (p.kind == FnKind::Fn) callRaw(f, "em_nil");
        else if (p.kind == FnKind::Pargs) {
            auto* d = static_cast<ClassDecl*>(p.node);
            loadArgToRet(f, Arg::I((long long)d->parentArgs.size()));
        }
        defLabel(f, f.retLabel);
        emitFrameLeave(f);
        f.o << "\tmov\trsp, rbp\n\tpop\trbp\n\tret\n";

        std::string body = patchPlaceholders(f);
        emitFnHeader(p.label);
        emitPrologue(frameSize(f));
        text_ << body;
        emitFnFooter(p.label);
    }

    void framedHelper(const std::string& name, std::function<void(FuncCtx&)> body) {
        FuncCtx f;
        emitFrameEnter(f);
        body(f);
        emitFrameLeave(f);
        std::string b = patchPlaceholders(f);
        emitFnHeader(name);
        emitPrologue(frameSize(f));
        text_ << b;
        emitEpilogueText();
        emitFnFooter(name);
    }
    void emitConstsFn() {
        framedHelper("em_consts", [&](FuncCtx& f) {
            for (auto& c : constSpecs_) {
                switch (c.kind) {
                    case ConstSpec::Int:   call(f, "em_int",        {Arg::I(c.imm)}); break;
                    case ConstSpec::Float: call(f, "em_float_bits", {Arg::I(c.imm)}); break;
                    case ConstSpec::Char:  call(f, "em_char",       {Arg::I(c.imm)}); break;
                    case ConstSpec::Str:
                        call(f, "em_string", {Arg::L(c.strLbl), Arg::I(c.imm)});
                        break;
                }
                // em_const_store writes the Vc cell and marks the box
                // immortal for the collector.
                retToArg0(f);
                f.o << "\tlea\t" << argReg(1) << ", [rip+" << c.slot << "]\n";
                callRaw(f, "em_const_store");
            }
        });
    }

    void emitMain(const std::vector<std::pair<std::string, std::string>>& moduleInits) {
        framedHelper("main", [&](FuncCtx& f) {
            call(f, "em_rt_init", {});
            call(f, "em_consts", {});
            for (auto& m : moduleInits)
                call(f, "em_module_register", {Arg::L(strLabel(m.first)), Arg::L(sym(m.second))});
            call(f, "em_globals", {});
            retToArg0(f);
            callRaw(f, "emtop");
            f.o << "\txor\teax, eax\n";
        });
    }
};

//======================= import resolution (compile time) =======================

static std::string dirOf(const std::string& path) {
    size_t slash = path.find_last_of("/\\");
    return slash == std::string::npos ? std::string(".") : path.substr(0, slash);
}
static bool readFile(const std::string& path, std::string& out) {
    std::ifstream in(path, std::ios::binary);
    if (!in.good()) return false;
    std::stringstream ss;
    ss << in.rdbuf();
    out = ss.str();
    return true;
}
static std::string findModuleFile(const std::string& name, const std::string& scriptDir) {
    const char* exts[] = {".em", ".emerald"};
    std::string dirs[] = {scriptDir, "."};
    for (auto& d : dirs)
        for (auto* e : exts) {
            std::string cand = d + "/" + name + e;
            std::ifstream probe(cand);
            if (probe.good()) return cand;
        }
    return "";
}

struct ModuleSet {
    std::vector<std::pair<std::string, Program*>> ordered;
    std::vector<std::unique_ptr<Program>> owner;
    std::vector<std::string> names;
    bool has(const std::string& n) {
        for (auto& x : names) if (x == n) return true;
        return false;
    }
};

static void collectImports(Node* n, std::vector<Import*>& out);
static void collectImportsBlock(Block* b, std::vector<Import*>& out) {
    if (!b) return;
    for (auto& s : b->statements) collectImports(s.get(), out);
}
static void collectImports(Node* n, std::vector<Import*>& out) {
    if (!n) return;
    switch (n->kind) {
        case NodeKind::Import:     out.push_back(static_cast<Import*>(n)); return;
        case NodeKind::Block:      collectImportsBlock(static_cast<Block*>(n), out); return;
        case NodeKind::FnDecl:     collectImportsBlock(static_cast<FnDecl*>(n)->body.get(), out); return;
        case NodeKind::ClassDecl:  collectImportsBlock(static_cast<ClassDecl*>(n)->body.get(), out); return;
        case NodeKind::If:
            for (auto& br : static_cast<If*>(n)->branches)
                collectImportsBlock(br.body.get(), out);
            return;
        case NodeKind::ForClassic: {
            auto* s = static_cast<ForClassic*>(n);
            collectImports(s->init.get(), out);
            collectImportsBlock(s->body.get(), out);
            return;
        }
        case NodeKind::ForIn:  collectImportsBlock(static_cast<ForIn*>(n)->body.get(), out); return;
        case NodeKind::While:  collectImportsBlock(static_cast<While*>(n)->body.get(), out); return;
        default: return;
    }
}

static void resolveModules(Program& prog, const std::string& scriptDir, ModuleSet& mods) {
    std::vector<Import*> imports;
    for (auto& s : prog.statements) collectImports(s.get(), imports);
    for (auto* imp : imports) {
        if (mods.has(imp->moduleName)) continue;
        std::string path = findModuleFile(imp->moduleName, scriptDir);
        if (path.empty()) {
            std::fprintf(stderr,
                "emeraldc: cannot find module '%s' (looked for %s.em / %s.emerald)\n",
                imp->moduleName.c_str(), imp->moduleName.c_str(), imp->moduleName.c_str());
            std::exit(1);
        }
        std::string src;
        readFile(path, src);
        Lexer lx(src, path);
        Parser ps(lx.tokenize());
        auto p = ps.parseProgram();
        mods.names.push_back(imp->moduleName);
        Program* raw = p.get();
        mods.owner.push_back(std::move(p));
        resolveModules(*raw, scriptDir, mods);
        mods.ordered.push_back({imp->moduleName, raw});
    }
}

//======================= driver =======================

static TargetOS hostOS() {
#if defined(_WIN32)
    return TargetOS::Windows;
#elif defined(__APPLE__)
    return TargetOS::MacOS;
#else
    return TargetOS::Linux;
#endif
}
static const char* osName(TargetOS t) {
    switch (t) {
        case TargetOS::Linux:   return "linux";
        case TargetOS::MacOS:   return "macos";
        default:                return "windows";
    }
}

static std::string exeDir() {
#if defined(_WIN32)
    char buf[MAX_PATH];
    DWORD n = GetModuleFileNameA(nullptr, buf, MAX_PATH);
    if (n == 0 || n >= MAX_PATH) return ".";
    return dirOf(std::string(buf, n));
#elif defined(__APPLE__)
    char buf[4096];
    uint32_t size = sizeof buf;
    if (_NSGetExecutablePath(buf, &size) != 0) return ".";
    std::error_code ec;
    auto canon = std::filesystem::weakly_canonical(buf, ec);
    return dirOf(ec ? std::string(buf) : canon.string());
#else
    char buf[4096];
    ssize_t n = readlink("/proc/self/exe", buf, sizeof buf - 1);
    if (n <= 0) return ".";
    buf[n] = 0;
    return dirOf(buf);
#endif
}
static bool fileExists(const std::string& p) {
    std::ifstream f(p);
    return f.good();
}
// Quote a path for the host shell that std::system() uses.
static std::string shellQuote(const std::string& s) {
#if defined(_WIN32)
    return "\"" + s + "\"";              // cmd.exe; '"' is illegal in paths
#else
    std::string out = "'";
    for (char c : s) { if (c == '\'') out += "'\\''"; else out += c; }
    return out + "'";
#endif
}
static std::string tempPath(const std::string& stem) {
    std::error_code ec;
    auto dir = std::filesystem::temp_directory_path(ec);
    std::string base = stem + std::to_string((long long)EMC_GETPID());
    if (ec) return base;
    return (dir / base).string();
}

int main(int argc, char** argv) {
    std::string inPath, outPath, asmPath;
    bool keepAsm = false, verbose = false;
    TargetOS target = hostOS();
    for (int i = 1; i < argc; i++) {
        std::string a = argv[i];
        if (a == "-o" && i + 1 < argc)      outPath = argv[++i];
        else if (a == "-S" && i + 1 < argc) asmPath = argv[++i];
        else if (a == "--keep-asm")         keepAsm = true;
        else if (a == "-v")                 verbose = true;
        else if (a.rfind("--target=", 0) == 0) {
            std::string t = a.substr(9);
            if (t == "linux" || t == "elf")                              target = TargetOS::Linux;
            else if (t == "macos" || t == "mac" || t == "osx" ||
                     t == "darwin" || t == "macho")                      target = TargetOS::MacOS;
            else if (t == "windows" || t == "win" || t == "win64" ||
                     t == "mingw" || t == "coff")                        target = TargetOS::Windows;
            else if (t == "native")                                      target = hostOS();
            else {
                std::fprintf(stderr, "emeraldc: unknown target '%s' "
                             "(supported: linux, macos, windows, native)\n", t.c_str());
                return 2;
            }
        }
        else if (a == "-h" || a == "--help") {
            std::puts("usage: emeraldc file.em [-o out] "
                      "[--target=linux|macos|windows|native] [-S out.s] [--keep-asm] [-v]\n"
                      "\nCompiles Emerald to a native executable via Intel-syntax x86-64\n"
                      "assembly.  The default target is the host operating system.\n"
                      "Environment: EMERALDC_HOME (directory of libemrt-<os>.a),\n"
                      "             EMERALDC_CXX  (assemble-and-link command override).");
            return 0;
        }
        else if (!a.empty() && a[0] == '-') {
            std::fprintf(stderr, "emeraldc: unknown option '%s'\n", a.c_str());
            return 2;
        }
        else inPath = a;
    }
    if (inPath.empty()) {
        std::fprintf(stderr, "emeraldc: no input file\nusage: emeraldc file.em [-o out]\n");
        return 2;
    }
    std::string src;
    if (!readFile(inPath, src)) {
        std::fprintf(stderr, "emeraldc: cannot open '%s'\n", inPath.c_str());
        return 1;
    }
    if (outPath.empty()) {
        std::string base = inPath;
        size_t slash = base.find_last_of("/\\");
        if (slash != std::string::npos) base = base.substr(slash + 1);
        size_t dot = base.find_last_of('.');
        if (dot != std::string::npos) base = base.substr(0, dot);
        outPath = base.empty() ? "a.out" : base;
        if (target == TargetOS::Windows) outPath += ".exe";
    }

    std::string assembly;
    try {
        Lexer lexer(src, inPath);
        Parser parser(lexer.tokenize());
        auto program = parser.parseProgram();
        ModuleSet mods;
        resolveModules(*program, dirOf(inPath), mods);
        CodeGen cg(target);
        assembly = cg.compile(*program, mods.ordered);
        if (verbose)
            std::fprintf(stderr, "emeraldc: target %s (x86-64, Intel syntax), "
                         "%zu module(s), %zu bytes of assembly\n",
                         osName(target), mods.ordered.size(), assembly.size());
    } catch (const EmeraldError& e) {
        std::fprintf(stderr, "emeraldc: %s", e.stage.c_str());
        if (e.line >= 0) {
            std::fprintf(stderr, " at line %d", e.line);
            if (e.col >= 0) std::fprintf(stderr, ", col %d", e.col);
        }
        std::fprintf(stderr, ": %s\n", e.what());
        return 1;
    } catch (const CompileError& e) {
        std::fprintf(stderr, "emeraldc: compile error at line %d, col %d: %s\n",
                     e.line, e.col, e.msg.c_str());
        return 1;
    }

    std::string sPath = !asmPath.empty() ? asmPath
                       : keepAsm ? outPath + ".s"
                       : tempPath("emeraldc_") + ".s";
    {
        std::ofstream sf(sPath, std::ios::binary);
        sf << assembly;
    }
    // ---- assemble & link with the platform C++ driver -----------------------
    // One command does both: GNU as / clang's integrated assembler accept the
    // generated `.intel_syntax noprefix` file directly.
    std::string libName = std::string("libemrt-") + osName(target) + ".a";
    std::string home = exeDir();
    std::string lib;
    const char* envHome = std::getenv("EMERALDC_HOME");
    for (std::string cand : {envHome ? std::string(envHome) + "/" + libName : "",
                             home + "/" + libName, home + "/../lib/" + libName,
                             envHome ? std::string(envHome) + "/libemrt.a" : "",
                             home + "/libemrt.a"}) {
        if (!cand.empty() && fileExists(cand)) { lib = cand; break; }
    }
    if (lib.empty()) {
        if (!asmPath.empty()) {
            std::fprintf(stderr, "emeraldc: wrote %s assembly to %s (no %s here "
                         "to link against)\n", osName(target), asmPath.c_str(),
                         libName.c_str());
            return 0;
        }
        std::fprintf(stderr, "emeraldc: cannot find %s next to the compiler "
                     "(set EMERALDC_HOME, or run `make` / `make windows-runtime` first)\n",
                     libName.c_str());
        return 1;
    }

    std::string cxx;
    bool userCxx = false;
    if (const char* env = std::getenv("EMERALDC_CXX")) {
        cxx = env;
        userCxx = true;
    } else if (target == hostOS()) {
        // -arch x86_64 makes Apple Silicon assemble/link our x86-64 output
        // (the binaries then run under Rosetta 2); it is a no-op on Intel Macs.
        cxx = target == TargetOS::MacOS ? "clang++ -arch x86_64" : "g++";
    } else if (target == TargetOS::Windows && hostOS() == TargetOS::Linux) {
        cxx = "x86_64-w64-mingw32-g++";      // stock Debian/Ubuntu/Fedora cross toolchain
    } else if (!asmPath.empty()) {
        std::fprintf(stderr, "emeraldc: wrote %s assembly to %s (no cross toolchain "
                     "on this %s host to link it; set EMERALDC_CXX to do so)\n",
                     osName(target), asmPath.c_str(), osName(hostOS()));
        return 0;
    } else {
        std::fprintf(stderr, "emeraldc: no default toolchain to link a %s binary on a "
                     "%s host.\nUse -S file.s to get the assembly, or set EMERALDC_CXX "
                     "to a cross C++ compiler for the target.\n",
                     osName(target), osName(hostOS()));
        return 1;
    }
    // Static-link Windows binaries so they need no MinGW DLLs (and run
    // cleanly under Wine).  -lm is accepted by all three toolchains.
    std::string extra = (!userCxx && target == TargetOS::Windows) ? " -static" : "";
    std::string cmd = cxx + extra + " -o " + shellQuote(outPath) + " " +
                      shellQuote(sPath) + " " + shellQuote(lib) + " -lm";
    if (verbose) std::fprintf(stderr, "emeraldc: %s\n", cmd.c_str());
    if (std::system(cmd.c_str()) != 0) {
        std::fprintf(stderr, "emeraldc: assemble/link failed (asm kept at %s)\n",
                     sPath.c_str());
        return 1;
    }
    if (asmPath.empty() && !keepAsm) std::remove(sPath.c_str());
    return 0;
}
