# emeraldc — a native-code compiler for the Emerald language

# Author: Jean-Jacques François Reibel

`emeraldc` compiles Emerald (https://github.com/Dr-Cosmic/Emerald) to native
Linux executables for two targets: **x86-64** (System V AMD64 ABI, AT&T
assembly via GNU `as`) and **ARM AArch64** (ARMv8-A, AAPCS64, GNU `as`). It is engineered *on top of everything that already exists* for
Emerald: the reference interpreter's own lexer and parser are the compiler's
front end, and the interpreter's own value model, environments, builtins, SQL
engine and JSON store are linked verbatim into the runtime library. What is
new is the back end — a code generator that turns the AST into machine code —
and a thin `extern "C"` runtime ABI that the generated code calls for dynamic
operations.

## Build & use

    make                      # build/emeraldc + build/libemrt.a (x86-64 runtime)
    make aarch64              # build/libemrt-aarch64.a (needs g++-aarch64-linux-gnu)
    build/emeraldc prog.em -o prog                     # native target
    build/emeraldc prog.em --target=aarch64 -o prog    # cross-compile for ARM
    ./prog                    # (or qemu-aarch64 ./prog when cross-compiled)

Options: `-o out`, `--target=x86_64|aarch64|native` (default: the host
architecture — the driver built on an ARM machine targets ARM natively),
`-S out.s` (write the generated assembly), `--keep-asm`, `-v`. Cross links are
static so the binaries run anywhere, including under `qemu-user`, with no
sysroot. Imports are resolved at compile time: every
`import`ed module (searched as `<name>.em` / `<name>.emerald` beside the
script, then in the CWD) is parsed and compiled into the same executable;
module initialisers run on first import at runtime, with caching and
circular-import detection, exactly like the interpreter.

    make test                 # full reference suite, x86-64
    make test-aarch64         # the same suite cross-compiled, run under qemu
                              # (set EMERALD_REPO if the clone lives elsewhere)

## Multi-target design

One AST walk drives all targets; every machine instruction is produced by
small per-architecture emission helpers (argument loading, calls, branches,
constant materialisation, prologue/epilogue). Frames differ per ABI — x86-64
uses `rbp`-relative negative offsets with a 16-byte outgoing area for the one
seven-argument shim; AArch64 stores `fp`/`lr` at `[sp]` with positive
`x29`-relative slots, and AAPCS64's eight argument registers mean no shim
argument ever touches the stack. Both use the same post-emission patching for
frame size and the argv scratch area. 64-bit immediates become
`movq`/`movabsq` on x86-64 and `movz`/`movk` chains on AArch64; addresses use
RIP-relative `leaq` versus `adrp`+`:lo12:` pairs (PIE-safe on both). The
runtime library is portable C++ compiled once per target into
`libemrt.a` / `libemrt-aarch64.a`.

## What is compiled vs. what is runtime

Generated machine code natively handles: statement sequencing, `if`/`elif`/
`else`, all three loop forms with `break`/`continue` as jumps, function bodies
(`Value* f(Environment*)`), class bodies and parent-constructor argument
thunks, short-circuit `&&`/`||`, `return` as a jump to the epilogue, and all
call/argument marshalling (a frame-local argv scratch area; frames are
16-byte aligned with no dynamic pushes).

The runtime ABI (`src/rt.cpp`) supplies the dynamic semantics as faithful
ports or direct reuse of interpreter code: arithmetic with Emerald's numeric
tower (`/` always float, Python-style `//` and `%`, `**`), loose vs. strict
equality, comparisons, string interpolation, arrays (grow-on-write with nil
gaps, gather indexing, deep-copy value semantics), member/index access, typed
declarations with coercion, `File` creation, class instantiation with
inheritance (parent args evaluated in the child's constructor scope; fields vs.
locals via the interpreter's own `constructing` environments), first-class
functions and closures, `for … in` over arrays/strings/tables, and modules.
Builtins — `print`, `printdlm`, `printtbl`, `len`/`length`, `type`, casts,
the math library, `getinput`, `shellexec`, `sqlexec`/`execsql`/`sqldatadir`,
`File`, `pi`, `e` — are the interpreter's own `builtins.cpp`, unmodified.

Three tiny vendored patches (marked `[emeraldc]`) make this possible: native
entry-point fields on `FunctionData`/`ClassData`, native-dispatch branches in
`callValue`/`constructLevel`, and public wrappers on `Interpreter`. Everything
else in `vendored/` is byte-identical to the upstream sources.

## Fidelity

Correctness is defined as observational equivalence with the interpreter. The
repository's full test suite (`tests/test_*.em`, 11 files covering basics,
operators, strings, arrays, control flow, functions, classes, files, shell,
SQL and imports) passes byte-identically, as do all runnable `examples/`.
Runtime errors match the interpreter's format, message, line **and column**
(positions are asserted per operation, not per statement), and exit codes
agree — including cases where a buggy program fails: the compiled binary
reproduces the interpreter's exact diagnostic. The identical battery — the
11-test suite, all examples, a torture script and the error cases — also
passes byte-for-byte on AArch64 (verified under `qemu-user` 8.2 with binaries
produced by the GCC 13 cross toolchain). Note that plain `char` is unsigned on
AArch64 Linux and signed on x86-64; the vendored value code already handles
characters through `unsigned char` casts, and the differential suite confirms
identical observable behaviour on both targets.

## Limitations (v1, by design)

Memory: value boxes and environments are never freed (no GC yet); long-running
loop-heavy programs grow steadily. Variable access goes through environment
chains for exact scoping/closure semantics — a compiled `fib(27)` runs about
2.3× faster than the interpreter on x86-64, but slot-allocating provably-local
variables and adding a box freelist are the obvious next optimisations. (Do
not benchmark the ARM binaries under `qemu-user` — emulation dominates; on ARM
silicon the compiled-vs-interpreted ratio mirrors the x86 result since both
sides share the same runtime.) Supported targets are x86-64 and AArch64 Linux;
32-bit x86 and 32-bit ARM are not supported. The REPL remains the
interpreter's domain. C++ exceptions never unwind through generated frames:
every ABI entry traps `EmeraldError` and reports/exits, and `return`/`break`/
`continue` compile to jumps.

## License

Emerald is GPL-3.0; `emeraldc` vendors and links its sources and is therefore
distributed under GPL-3.0 as a derivative work. See `LICENSE`.
