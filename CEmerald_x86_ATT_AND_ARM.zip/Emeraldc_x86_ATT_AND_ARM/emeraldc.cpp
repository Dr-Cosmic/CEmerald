// emeraldc.cpp - A native-code compiler for the Emerald language.
//
// Targets:
//   x86_64   System V AMD64, Linux (AT&T syntax, GNU as)
//   aarch64  ARMv8-A AArch64, AAPCS64, Linux (GNU as)
//
// Front end: the reference implementation's own lexer & parser (vendored),
// so emeraldc accepts exactly the language the interpreter accepts.
// Back end: a single AST walk shared by all targets; every machine
// instruction is produced by small per-architecture emission helpers.
// Dynamic-language operations call the runtime ABI implemented in rt.cpp,
// which is portable C++ and is cross-compiled per target (libemrt*.a).
//
// Usage: emeraldc file.em [-o out] [--target=x86_64|aarch64] [-S asm.s]
//                         [--keep-asm] [-v]

#include "../vendored/lexer.h"
#include "../vendored/parser.h"
#include "../vendored/ast.h"
#include "../vendored/errors.h"

#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <fstream>
#include <functional>
#include <map>
#include <memory>
#include <sstream>
#include <string>
#include <unistd.h>
#include <unordered_map>
#include <vector>

using namespace emerald;

enum class Target { X86_64, AArch64 };

struct CompileError {
    std::string msg;
    int line, col;
};

//======================= assembly text helpers =======================

static std::string escAsm(const std::string& s) {
    std::string out;
    for (unsigned char c : s) {
        if (c == '"' || c == '\\') { out += '\\'; out += static_cast<char>(c); }
        else if (c >= 32 && c < 127) out += static_cast<char>(c);
        else {
            char buf[8];
            std::snprintf(buf, sizeof buf, "\\%03o", c);
            out += buf;
        }
    }
    return out;
}

//======================= per-function emission context =======================

enum class FnKind { Top, Fn, Body, Pargs };

struct FuncCtx {
    std::string label;
    FnKind kind;
    std::ostringstream o;          // body text with placeholders
    int nextSlot = 0, maxSlots = 0;
    std::vector<int> freeSlots;
    int maxArgs = 0;
    int envSlot = -1;              // slot holding current Environment*
    int outSlot = -1;              // Pargs: slot holding Value** out
    std::string retLabel;
    struct Loop { std::string brk, cont; };
    std::vector<Loop> loops;

    int alloc() {
        if (!freeSlots.empty()) { int s = freeSlots.back(); freeSlots.pop_back(); return s; }
        int s = nextSlot++;
        if (nextSlot > maxSlots) maxSlots = nextSlot;
        return s;
    }
    void free(int s) { if (s >= 0) freeSlots.push_back(s); }
};

// A pending function to emit (worklist keeps buffers independent).
struct Pending {
    std::string label;
    FnKind kind;
    Node* node;         // FnDecl (Fn), ClassDecl (Body/Pargs), or nullptr (Top)
};

//======================= the code generator =======================

class CodeGen {
public:
    explicit CodeGen(Target t) : target_(t) {}

    std::string compile(Program& mainProg,
                        std::vector<std::pair<std::string, Program*>>& modules) {
        std::vector<std::pair<std::string, std::string>> moduleInits;
        for (auto& m : modules) {
            std::string lbl = "emmod_" + std::to_string(fnCounter_++);
            moduleInits.push_back({m.first, lbl});
            pending_.push_back({lbl, FnKind::Top, nullptr});
            pendingTop_[lbl] = &m.second->statements;
        }
        pending_.push_back({"emtop", FnKind::Top, nullptr});
        pendingTop_["emtop"] = &mainProg.statements;

        while (!pending_.empty()) {
            Pending p = pending_.front();
            pending_.erase(pending_.begin());
            emitFunction(p);
        }
        emitConstsFn();
        emitMain(moduleInits);

        std::ostringstream out;
        out << "\t.file\t\"emeraldc\"\n";
        out << rodata_.str();
        out << data_.str();
        out << bss_.str();
        out << "\t.text\n";
        out << text_.str();
        out << "\t.section .note.GNU-stack,\"\","
            << (target_ == Target::X86_64 ? "@progbits" : "%progbits") << "\n";
        return out.str();
    }

private:
    Target target_;
    int fnCounter_ = 0, labelCounter_ = 0, strCounter_ = 0, constCounter_ = 0,
        arrCounter_ = 0;
    std::ostringstream rodata_, data_, bss_, text_;
    std::vector<Pending> pending_;
    std::unordered_map<std::string, std::vector<NodePtr>*> pendingTop_;
    std::unordered_map<std::string, std::string> strLabels_;   // raw text -> .Lc label

    struct ConstSpec {
        enum Kind { Int, Float, Char, Str } kind;
        long long imm = 0;         // value / bits / char code / string length
        std::string strLbl;        // Str: label of the character data
        std::string slot;          // Vc slot receiving the built Value*
    };
    std::map<std::string, std::string> valueConsts_;           // key -> Vc label
    std::vector<ConstSpec> constSpecs_;

    std::string newLabel(const std::string& stem) {
        return ".L" + stem + std::to_string(labelCounter_++);
    }

    // ---- constants ----
    std::string strLabel(const std::string& s) {
        auto it = strLabels_.find(s);
        if (it != strLabels_.end()) return it->second;
        std::string lbl = ".Lc" + std::to_string(strCounter_++);
        rodata_ << "\t.section .rodata\n" << lbl << ":\n\t.string \"" << escAsm(s)
                << "\"\n";
        strLabels_[s] = lbl;
        return lbl;
    }
    std::string valueConst(const std::string& key, ConstSpec spec) {
        auto it = valueConsts_.find(key);
        if (it != valueConsts_.end()) return it->second;
        std::string lbl = "Vc" + std::to_string(constCounter_++);
        bss_ << "\t.bss\n\t.balign 8\n" << lbl << ":\n\t.zero 8\n";
        spec.slot = lbl;
        constSpecs_.push_back(spec);
        valueConsts_[key] = lbl;
        return lbl;
    }
    std::string intConst(long long v) {
        return valueConst("i:" + std::to_string(v), {ConstSpec::Int, v, "", ""});
    }
    std::string floatConst(double d) {
        long long bits;
        std::memcpy(&bits, &d, 8);
        return valueConst("f:" + std::to_string(bits), {ConstSpec::Float, bits, "", ""});
    }
    std::string charConst(char c) {
        long long v = (long long)(unsigned char)c;
        return valueConst("c:" + std::to_string(v), {ConstSpec::Char, v, "", ""});
    }
    std::string stringConst(const std::string& s) {
        std::string cl = strLabel(s);
        return valueConst("s:" + s, {ConstSpec::Str, (long long)s.size(), cl, ""});
    }
    std::string paramArray(const std::vector<Param>& params) {
        std::string lbl = "PN" + std::to_string(arrCounter_++);
        data_ << "\t.data\n\t.balign 8\n" << lbl << ":\n";
        for (auto& p : params) data_ << "\t.quad\t" << strLabel(p.name) << "\n";
        if (params.empty()) data_ << "\t.quad\t0\n";
        return lbl;
    }

    //======================= per-architecture primitives =======================

    struct Arg {
        enum K { Slot, Imm, Lea, Argv, ConstSlot } k;
        long long imm = 0;
        int slot = -1;
        std::string label;
        static Arg S(int s)                { Arg a; a.k = Slot;      a.slot = s;  return a; }
        static Arg I(long long v)          { Arg a; a.k = Imm;       a.imm = v;   return a; }
        static Arg L(const std::string& l) { Arg a; a.k = Lea;       a.label = l; return a; }
        static Arg AV()                    { Arg a; a.k = Argv;                   return a; }
        static Arg C(const std::string& l) { Arg a; a.k = ConstSlot; a.label = l; return a; }
    };
    int nRegArgs() const { return target_ == Target::X86_64 ? 6 : 8; }
    const char* argReg(size_t i) const {
        static const char* x86[6] = {"%rdi", "%rsi", "%rdx", "%rcx", "%r8", "%r9"};
        static const char* a64[8] = {"x0", "x1", "x2", "x3", "x4", "x5", "x6", "x7"};
        return target_ == Target::X86_64 ? x86[i] : a64[i];
    }
    std::string slotRef(int s) const {
        return target_ == Target::X86_64
             ? "-" + std::to_string(16 + 8 * s) + "(%rbp)"
             : "[x29, #" + std::to_string(24 + 8 * s) + "]";
    }
    // Materialise an arbitrary 64-bit immediate into a register (AArch64).
    void a64Imm(FuncCtx& f, const char* reg, long long v) {
        unsigned long long u = (unsigned long long)v;
        bool first = true;
        for (int sh = 0; sh < 64; sh += 16) {
            unsigned long long chunk = (u >> sh) & 0xffffULL;
            if (chunk == 0 && !(first && sh == 48)) continue;
            f.o << "\t" << (first ? "movz" : "movk") << "\t" << reg << ", #" << chunk;
            if (sh) f.o << ", lsl #" << sh;
            f.o << "\n";
            first = false;
        }
        if (first) f.o << "\tmovz\t" << reg << ", #0\n";
    }
    void loadArg(FuncCtx& f, const Arg& a, const char* reg) {
        if (target_ == Target::X86_64) {
            switch (a.k) {
                case Arg::Slot: f.o << "\tmovq\t" << slotRef(a.slot) << ", " << reg << "\n"; break;
                case Arg::Imm:
                    if (a.imm >= -2147483648LL && a.imm <= 2147483647LL)
                        f.o << "\tmovq\t$" << a.imm << ", " << reg << "\n";
                    else
                        f.o << "\tmovabsq\t$" << a.imm << ", " << reg << "\n";
                    break;
                case Arg::Lea:  f.o << "\tleaq\t" << a.label << "(%rip), " << reg << "\n"; break;
                case Arg::Argv: f.o << "\tleaq\t@AV0@, " << reg << "\n"; break;
                case Arg::ConstSlot:
                    f.o << "\tmovq\t" << a.label << "(%rip), " << reg << "\n"; break;
            }
        } else {
            switch (a.k) {
                case Arg::Slot: f.o << "\tldr\t" << reg << ", " << slotRef(a.slot) << "\n"; break;
                case Arg::Imm:  a64Imm(f, reg, a.imm); break;
                case Arg::Lea:
                    f.o << "\tadrp\t" << reg << ", " << a.label << "\n";
                    f.o << "\tadd\t" << reg << ", " << reg << ", :lo12:" << a.label << "\n";
                    break;
                case Arg::Argv: f.o << "\tadd\t" << reg << ", x29, @AVB@\n"; break;
                case Arg::ConstSlot:
                    f.o << "\tadrp\t" << reg << ", " << a.label << "\n";
                    f.o << "\tldr\t" << reg << ", [" << reg << ", :lo12:" << a.label << "]\n";
                    break;
            }
        }
    }
    // Call a runtime function; result (if any) lands in the return register.
    void call(FuncCtx& f, const std::string& fn, std::vector<Arg> args) {
        int nreg = nRegArgs();
        for (size_t i = 0; i < args.size() && (int)i < nreg; i++)
            loadArg(f, args[i], argReg(i));
        for (size_t i = nreg; i < args.size(); i++) {   // x86 only: 7th+ on stack
            loadArg(f, args[i], "%r10");
            f.o << "\tmovq\t%r10, " << 8 * (i - nreg) << "(%rsp)\n";
        }
        callRaw(f, fn);
    }
    void callRaw(FuncCtx& f, const std::string& fn) {
        f.o << (target_ == Target::X86_64 ? "\tcall\t" : "\tbl\t") << fn << "\n";
    }
    int saveRet(FuncCtx& f) {
        int s = f.alloc();
        storeRetToSlot(f, s);
        return s;
    }
    void storeRetToSlot(FuncCtx& f, int s) {
        if (target_ == Target::X86_64)
            f.o << "\tmovq\t%rax, " << slotRef(s) << "\n";
        else
            f.o << "\tstr\tx0, " << slotRef(s) << "\n";
    }
    void retToArg0(FuncCtx& f) {              // stage return value as first argument
        if (target_ == Target::X86_64) f.o << "\tmovq\t%rax, %rdi\n";
        // AArch64: return register x0 is already the first argument register.
    }
    void branchIfRetZero(FuncCtx& f, const std::string& lbl) {
        if (target_ == Target::X86_64)
            f.o << "\ttestq\t%rax, %rax\n\tjz\t" << lbl << "\n";
        else
            f.o << "\tcbz\tx0, " << lbl << "\n";
    }
    void branchIfRetNonZero(FuncCtx& f, const std::string& lbl) {
        if (target_ == Target::X86_64)
            f.o << "\ttestq\t%rax, %rax\n\tjnz\t" << lbl << "\n";
        else
            f.o << "\tcbnz\tx0, " << lbl << "\n";
    }
    void jmp(FuncCtx& f, const std::string& lbl) {
        f.o << (target_ == Target::X86_64 ? "\tjmp\t" : "\tb\t") << lbl << "\n";
    }
    void defLabel(FuncCtx& f, const std::string& lbl) { f.o << lbl << ":\n"; }
    // Copy already-evaluated slots into the argv scratch area. Slots are freed.
    void buildArgv(FuncCtx& f, std::vector<int>& slots) {
        if ((int)slots.size() > f.maxArgs) f.maxArgs = (int)slots.size();
        for (size_t j = 0; j < slots.size(); j++) {
            if (target_ == Target::X86_64) {
                f.o << "\tmovq\t" << slotRef(slots[j]) << ", %r10\n";
                f.o << "\tmovq\t%r10, @AV" << j << "@\n";
            } else {
                f.o << "\tldr\tx9, " << slotRef(slots[j]) << "\n";
                f.o << "\tstr\tx9, @AV" << j << "@\n";
            }
        }
        for (int s : slots) f.free(s);
    }
    void storeRetToOut(FuncCtx& f, int outSlot, size_t i) {   // Pargs: out[i] = ret
        if (target_ == Target::X86_64) {
            f.o << "\tmovq\t" << slotRef(outSlot) << ", %r10\n";
            f.o << "\tmovq\t%rax, " << 8 * i << "(%r10)\n";
        } else {
            f.o << "\tldr\tx9, " << slotRef(outSlot) << "\n";
            f.o << "\tstr\tx0, [x9, #" << 8 * i << "]\n";
        }
    }
    void emitPos(FuncCtx& f, Node* n) {
        call(f, "em_pos", {Arg::I(n->line), Arg::I(n->col)});
    }
    // Variant for sites where argument registers are already staged: writes the
    // position globals directly using scratch registers only.
    void emitPos2(FuncCtx& f, Node* n) {
        if (target_ == Target::X86_64) {
            f.o << "\tmovq\t$" << n->line << ", em_line(%rip)\n";
            f.o << "\tmovq\t$" << n->col << ", em_col(%rip)\n";
        } else {
            f.o << "\tadrp\tx9, em_line\n";
            a64Imm(f, "x10", n->line);
            f.o << "\tstr\tx10, [x9, :lo12:em_line]\n";
            f.o << "\tadrp\tx9, em_col\n";
            a64Imm(f, "x10", n->col);
            f.o << "\tstr\tx10, [x9, :lo12:em_col]\n";
        }
    }

    [[noreturn]] void err(Node* n, const std::string& m) {
        throw CompileError{m, n->line, n->col};
    }

    //======================= expressions =======================

    int emitExpr(FuncCtx& f, Node* n) {
        switch (n->kind) {
            case NodeKind::IntLit: {
                loadArgToRet(f, Arg::C(intConst(static_cast<IntLit*>(n)->value)));
                return saveRet(f);
            }
            case NodeKind::FloatLit: {
                loadArgToRet(f, Arg::C(floatConst(static_cast<FloatLit*>(n)->value)));
                return saveRet(f);
            }
            case NodeKind::CharLit: {
                loadArgToRet(f, Arg::C(charConst(static_cast<CharLit*>(n)->value)));
                return saveRet(f);
            }
            case NodeKind::BoolLit:
                call(f, "em_bool", {Arg::I(static_cast<BoolLit*>(n)->value ? 1 : 0)});
                return saveRet(f);
            case NodeKind::NilLit:
                call(f, "em_nil", {});
                return saveRet(f);
            case NodeKind::StringLit: return emitStringLit(f, static_cast<StringLit*>(n));
            case NodeKind::ArrayLit: {
                auto* a = static_cast<ArrayLit*>(n);
                std::vector<int> slots;
                for (auto& e : a->elements) slots.push_back(emitExpr(f, e.get()));
                buildArgv(f, slots);
                call(f, "em_arraylit", {Arg::AV(), Arg::I((long long)a->elements.size())});
                return saveRet(f);
            }
            case NodeKind::Identifier:
                emitPos(f, n);
                call(f, "em_env_get", {Arg::S(f.envSlot),
                                       Arg::L(strLabel(static_cast<Identifier*>(n)->name))});
                return saveRet(f);
            case NodeKind::Binary:   return emitBinary(f, static_cast<Binary*>(n));
            case NodeKind::Unary: {
                auto* u = static_cast<Unary*>(n);
                if (u->op == "++" || u->op == "--")
                    return emitIncDec(f, u->operand.get(), u->op == "++" ? 1 : -1, true);
                int v = emitExpr(f, u->operand.get());
                const char* fn = u->op == "!" ? "em_not"
                               : u->op == "-" ? "em_neg"
                               : u->op == "+" ? "em_pos_op" : nullptr;
                if (!fn) err(n, "unsupported unary operator '" + u->op + "'");
                emitPos(f, n);
                call(f, fn, {Arg::S(v)});
                f.free(v);
                return saveRet(f);
            }
            case NodeKind::PostfixOp: {
                auto* p = static_cast<PostfixOp*>(n);
                return emitIncDec(f, p->operand.get(), p->op == "++" ? 1 : -1, false);
            }
            case NodeKind::Assign:   return emitAssign(f, static_cast<Assign*>(n));
            case NodeKind::Call:     return emitCall(f, static_cast<Call*>(n), false);
            case NodeKind::Index: {
                auto* ix = static_cast<Index*>(n);
                int obj = emitExpr(f, ix->object.get());
                std::vector<int> slots;
                for (auto& e : ix->indices) slots.push_back(emitExpr(f, e.get()));
                buildArgv(f, slots);
                emitPos(f, n);
                call(f, "em_index_get", {Arg::S(obj), Arg::AV(),
                                         Arg::I((long long)ix->indices.size())});
                f.free(obj);
                return saveRet(f);
            }
            case NodeKind::Member: {
                auto* m = static_cast<Member*>(n);
                int obj = emitExpr(f, m->object.get());
                emitPos(f, n);
                call(f, "em_member_get", {Arg::S(obj), Arg::L(strLabel(m->name))});
                f.free(obj);
                return saveRet(f);
            }
            default:
                err(n, "invalid expression");
        }
    }
    // Load an operand into the *return* register (used for constant loads so the
    // shared saveRet path applies uniformly).
    void loadArgToRet(FuncCtx& f, const Arg& a) {
        loadArg(f, a, target_ == Target::X86_64 ? "%rax" : "x0");
    }

    int emitStringLit(FuncCtx& f, StringLit* s) {
        if (s->parts.size() == 1 && !s->parts[0].isExpr) {
            loadArgToRet(f, Arg::C(stringConst(s->parts[0].literal)));
            return saveRet(f);
        }
        if (s->parts.empty()) {
            loadArgToRet(f, Arg::C(stringConst("")));
            return saveRet(f);
        }
        std::vector<int> slots;
        for (auto& part : s->parts) {
            if (part.isExpr) {
                slots.push_back(emitExpr(f, part.expr.get()));
            } else {
                loadArgToRet(f, Arg::C(stringConst(part.literal)));
                slots.push_back(saveRet(f));
            }
        }
        size_t n = slots.size();
        buildArgv(f, slots);
        call(f, "em_interp", {Arg::AV(), Arg::I((long long)n)});
        return saveRet(f);
    }

    int emitBinary(FuncCtx& f, Binary* b) {
        const std::string& op = b->op;
        if (op == "&&" || op == "||") {
            std::string lShort = newLabel("sc"), lEnd = newLabel("scend");
            int res = f.alloc();
            int l = emitExpr(f, b->left.get());
            call(f, "em_truthy", {Arg::S(l)});
            f.free(l);
            if (op == "&&") branchIfRetZero(f, lShort);
            else            branchIfRetNonZero(f, lShort);
            int r = emitExpr(f, b->right.get());
            call(f, "em_truthy", {Arg::S(r)});
            f.free(r);
            retToArg0(f);
            callRaw(f, "em_bool");
            storeRetToSlot(f, res);
            jmp(f, lEnd);
            defLabel(f, lShort);
            call(f, "em_bool", {Arg::I(op == "&&" ? 0 : 1)});
            storeRetToSlot(f, res);
            defLabel(f, lEnd);
            return res;
        }
        int l = emitExpr(f, b->left.get());
        int r = emitExpr(f, b->right.get());
        emitPos(f, b);
        if (op == "==")       call(f, "em_eq",  {Arg::S(l), Arg::S(r), Arg::I(0), Arg::I(0)});
        else if (op == "!=")  call(f, "em_eq",  {Arg::S(l), Arg::S(r), Arg::I(0), Arg::I(1)});
        else if (op == "===") call(f, "em_eq",  {Arg::S(l), Arg::S(r), Arg::I(1), Arg::I(0)});
        else if (op == "!==") call(f, "em_eq",  {Arg::S(l), Arg::S(r), Arg::I(1), Arg::I(1)});
        else if (op == "<")   call(f, "em_cmp", {Arg::S(l), Arg::S(r), Arg::I(0)});
        else if (op == "<=")  call(f, "em_cmp", {Arg::S(l), Arg::S(r), Arg::I(1)});
        else if (op == ">")   call(f, "em_cmp", {Arg::S(l), Arg::S(r), Arg::I(2)});
        else if (op == ">=")  call(f, "em_cmp", {Arg::S(l), Arg::S(r), Arg::I(3)});
        else if (op == "+")   call(f, "em_add",  {Arg::S(l), Arg::S(r)});
        else if (op == "-")   call(f, "em_sub",  {Arg::S(l), Arg::S(r)});
        else if (op == "*")   call(f, "em_mul",  {Arg::S(l), Arg::S(r)});
        else if (op == "/")   call(f, "em_div",  {Arg::S(l), Arg::S(r)});
        else if (op == "//")  call(f, "em_fdiv", {Arg::S(l), Arg::S(r)});
        else if (op == "%")   call(f, "em_mod",  {Arg::S(l), Arg::S(r)});
        else if (op == "**")  call(f, "em_pow",  {Arg::S(l), Arg::S(r)});
        else err(b, "unsupported binary operator '" + op + "'");
        f.free(l); f.free(r);
        return saveRet(f);
    }

    void emitStore(FuncCtx& f, Node* target, int valSlot) {
        emitPos(f, target);
        switch (target->kind) {
            case NodeKind::Identifier:
                call(f, "em_env_assign", {Arg::S(f.envSlot),
                     Arg::L(strLabel(static_cast<Identifier*>(target)->name)),
                     Arg::S(valSlot)});
                return;
            case NodeKind::Member: {
                auto* m = static_cast<Member*>(target);
                int obj = emitExpr(f, m->object.get());
                emitPos(f, target);
                call(f, "em_member_set", {Arg::S(obj), Arg::L(strLabel(m->name)),
                                          Arg::S(valSlot)});
                f.free(obj);
                return;
            }
            case NodeKind::Index: {
                auto* ix = static_cast<Index*>(target);
                if (ix->indices.size() != 1) { call(f, "em_index_set_multi_error", {}); return; }
                int obj = emitExpr(f, ix->object.get());
                int idx = emitExpr(f, ix->indices[0].get());
                emitPos(f, target);
                call(f, "em_index_set", {Arg::S(obj), Arg::S(idx), Arg::S(valSlot)});
                f.free(obj); f.free(idx);
                return;
            }
            default:
                err(target, "invalid assignment target");
        }
    }
    int emitLvalueGet(FuncCtx& f, Node* target) {
        if (target->kind == NodeKind::Identifier || target->kind == NodeKind::Member ||
            target->kind == NodeKind::Index)
            return emitExpr(f, target);
        err(target, "invalid target of '++'/'--'");
    }

    int emitAssign(FuncCtx& f, Assign* a) {
        int v = emitExpr(f, a->value.get());
        call(f, "em_assign_prepare", {Arg::S(v)});
        f.free(v);
        int prepared = saveRet(f);
        emitStore(f, a->target.get(), prepared);
        return prepared;
    }

    int emitIncDec(FuncCtx& f, Node* target, long long delta, bool prefix) {
        int oldv = emitLvalueGet(f, target);
        call(f, "em_incdec_next", {Arg::S(oldv), Arg::I(delta)});
        int next = saveRet(f);
        emitStore(f, target, next);
        if (prefix) { f.free(oldv); return next; }
        f.free(next);
        return oldv;
    }

    int emitCall(FuncCtx& f, Call* c, bool stmtCtx) {
        std::vector<int> argSlots;
        if (c->callee->kind == NodeKind::Member) {
            auto* m = static_cast<Member*>(c->callee.get());
            int recv = emitExpr(f, m->object.get());
            for (auto& a : c->args) argSlots.push_back(emitExpr(f, a.get()));
            size_t n = argSlots.size();
            buildArgv(f, argSlots);
            emitPos2(f, c);
            call(f, "em_method_call", {Arg::S(recv), Arg::L(strLabel(m->name)),
                                       Arg::AV(), Arg::I((long long)n),
                                       Arg::I(c->trailingComma ? 1 : 0),
                                       Arg::I(stmtCtx ? 1 : 0)});
            f.free(recv);
            return saveRet(f);
        }
        int callee = emitExpr(f, c->callee.get());
        for (auto& a : c->args) argSlots.push_back(emitExpr(f, a.get()));
        size_t n = argSlots.size();
        buildArgv(f, argSlots);
        emitPos2(f, c);
        call(f, "em_call_value", {Arg::S(callee), Arg::AV(), Arg::I((long long)n)});
        f.free(callee);
        return saveRet(f);
    }

    //======================= statements =======================

    bool isExprKind(NodeKind k) {
        switch (k) {
            case NodeKind::IntLit: case NodeKind::FloatLit: case NodeKind::CharLit:
            case NodeKind::StringLit: case NodeKind::BoolLit: case NodeKind::NilLit:
            case NodeKind::ArrayLit: case NodeKind::Identifier: case NodeKind::Binary:
            case NodeKind::Unary: case NodeKind::PostfixOp: case NodeKind::Assign:
            case NodeKind::Call: case NodeKind::Index: case NodeKind::Member:
                return true;
            default: return false;
        }
    }

    void emitBlockIn(FuncCtx& f, Block* b, int parentEnvSlot) {
        call(f, "em_env_new", {Arg::S(parentEnvSlot)});
        int child = saveRet(f);
        int saved = f.envSlot; f.envSlot = child;
        for (auto& st : b->statements) emitStmt(f, st.get());
        f.envSlot = saved; f.free(child);
    }

    void emitStmt(FuncCtx& f, Node* n) {
        emitPos(f, n);
        switch (n->kind) {
            case NodeKind::VarDecl:   emitVarDecl(f, static_cast<VarDecl*>(n)); return;
            case NodeKind::ExprStmt: {
                auto* es = static_cast<ExprStmt*>(n);
                int s;
                if (es->expr->kind == NodeKind::Call)
                    s = emitCall(f, static_cast<Call*>(es->expr.get()), true);
                else
                    s = emitExpr(f, es->expr.get());
                f.free(s);
                return;
            }
            case NodeKind::Block:
                emitBlockIn(f, static_cast<Block*>(n), f.envSlot);
                return;
            case NodeKind::FnDecl:    emitFnDecl(f, static_cast<FnDecl*>(n)); return;
            case NodeKind::ClassDecl: emitClassDecl(f, static_cast<ClassDecl*>(n)); return;
            case NodeKind::Return: {
                auto* r = static_cast<Return*>(n);
                int v;
                if (r->value) v = emitExpr(f, r->value.get());
                else { call(f, "em_nil", {}); v = saveRet(f); }
                call(f, "em_clone", {Arg::S(v)});          // ReturnSignal clones
                f.free(v);
                jmp(f, f.retLabel);
                return;
            }
            case NodeKind::If: {
                auto* s = static_cast<If*>(n);
                std::string lEnd = newLabel("ifend");
                for (auto& br : s->branches) {
                    std::string lNext = newLabel("ifnx");
                    if (br.condition) {
                        int c = emitExpr(f, br.condition.get());
                        call(f, "em_truthy", {Arg::S(c)});
                        f.free(c);
                        branchIfRetZero(f, lNext);
                    }
                    emitBlockIn(f, br.body.get(), f.envSlot);
                    jmp(f, lEnd);
                    defLabel(f, lNext);
                    if (!br.condition) break;
                }
                defLabel(f, lEnd);
                return;
            }
            case NodeKind::ForClassic: {
                auto* s = static_cast<ForClassic*>(n);
                call(f, "em_env_new", {Arg::S(f.envSlot)});
                int loopEnv = saveRet(f);
                int saved = f.envSlot; f.envSlot = loopEnv;
                if (s->init) {
                    if (isExprKind(s->init->kind)) { int t = emitExpr(f, s->init.get()); f.free(t); }
                    else emitStmt(f, s->init.get());
                }
                std::string lCond = newLabel("forc"), lCont = newLabel("forU"),
                            lBrk = newLabel("forX");
                defLabel(f, lCond);
                if (s->condition) {
                    int c = emitExpr(f, s->condition.get());
                    call(f, "em_truthy", {Arg::S(c)});
                    f.free(c);
                    branchIfRetZero(f, lBrk);
                }
                f.loops.push_back({lBrk, lCont});
                emitBlockIn(f, s->body.get(), loopEnv);
                f.loops.pop_back();
                defLabel(f, lCont);
                if (s->update) { int u = emitExpr(f, s->update.get()); f.free(u); }
                jmp(f, lCond);
                defLabel(f, lBrk);
                f.envSlot = saved; f.free(loopEnv);
                return;
            }
            case NodeKind::ForIn: {
                auto* s = static_cast<ForIn*>(n);
                int seq = emitExpr(f, s->iterable.get());
                call(f, "em_iter_begin", {Arg::S(seq)});
                f.free(seq);
                int iter = saveRet(f);
                call(f, "em_env_new", {Arg::S(f.envSlot)});
                int loopEnv = saveRet(f);
                std::string lNext = newLabel("finN"), lBrk = newLabel("finX");
                defLabel(f, lNext);
                call(f, "em_iter_next", {Arg::S(iter)});
                branchIfRetZero(f, lBrk);
                int el = saveRet(f);
                call(f, "em_env_define", {Arg::S(loopEnv), Arg::L(strLabel(s->varName)),
                                          Arg::S(el)});
                f.free(el);
                f.loops.push_back({lBrk, lNext});
                emitBlockIn(f, s->body.get(), loopEnv);
                f.loops.pop_back();
                jmp(f, lNext);
                defLabel(f, lBrk);
                f.free(loopEnv); f.free(iter);
                return;
            }
            case NodeKind::While: {
                auto* s = static_cast<While*>(n);
                std::string lCond = newLabel("whC"), lBrk = newLabel("whX");
                defLabel(f, lCond);
                int c = emitExpr(f, s->condition.get());
                call(f, "em_truthy", {Arg::S(c)});
                f.free(c);
                branchIfRetZero(f, lBrk);
                f.loops.push_back({lBrk, lCond});
                emitBlockIn(f, s->body.get(), f.envSlot);
                f.loops.pop_back();
                jmp(f, lCond);
                defLabel(f, lBrk);
                return;
            }
            case NodeKind::Import: {
                auto* s = static_cast<Import*>(n);
                if (s->isFrom)
                    call(f, "em_import_from", {Arg::S(f.envSlot),
                         Arg::L(strLabel(s->moduleName)), Arg::L(strLabel(s->symbolName))});
                else
                    call(f, "em_import", {Arg::S(f.envSlot),
                                          Arg::L(strLabel(s->moduleName))});
                return;
            }
            case NodeKind::Break:
                if (f.loops.empty()) err(n, "'break' used outside of a loop");
                jmp(f, f.loops.back().brk);
                return;
            case NodeKind::Continue:
                if (f.loops.empty()) err(n, "'continue' used outside of a loop");
                jmp(f, f.loops.back().cont);
                return;
            default: {
                int s = emitExpr(f, n);
                f.free(s);
                return;
            }
        }
    }

    void emitVarDecl(FuncCtx& f, VarDecl* d) {
        int init = -1;
        if (d->initializer) init = emitExpr(f, d->initializer.get());
        std::vector<int> ctorSlots;
        for (auto& a : d->ctorArgs) ctorSlots.push_back(emitExpr(f, a.get()));
        size_t nCtor = ctorSlots.size();
        if (nCtor) buildArgv(f, ctorSlots);
        emitPos(f, d);
        std::vector<Arg> args = {Arg::S(f.envSlot),
                                 Arg::L(strLabel(d->declaredType)),
                                 Arg::L(strLabel(d->name)),
                                 Arg::I(d->isArray ? 1 : 0)};
        args.push_back(init >= 0 ? Arg::S(init) : Arg::I(0));
        args.push_back(nCtor ? Arg::AV() : Arg::I(0));
        args.push_back(Arg::I((long long)nCtor));
        call(f, "em_vardecl", args);
        f.free(init);
    }

    void emitFnDecl(FuncCtx& f, FnDecl* d) {
        std::string lbl = "emfn_" + std::to_string(fnCounter_++);
        pending_.push_back({lbl, FnKind::Fn, d});
        std::string pn = paramArray(d->params);
        call(f, "em_fn_decl", {Arg::S(f.envSlot), Arg::L(strLabel(d->name)),
                               Arg::L(lbl), Arg::L(pn), Arg::I((long long)d->params.size())});
    }

    void emitClassDecl(FuncCtx& f, ClassDecl* d) {
        if (d->isObjectVarDecl) {
            call(f, "em_object_var_decl", {Arg::S(f.envSlot), Arg::L(strLabel(d->name))});
            return;
        }
        std::string bodyLbl = "emcb_" + std::to_string(fnCounter_++);
        pending_.push_back({bodyLbl, FnKind::Body, d});
        std::string pargsLbl;
        if (d->hasParent) {
            pargsLbl = "empa_" + std::to_string(fnCounter_++);
            pending_.push_back({pargsLbl, FnKind::Pargs, d});
        }
        std::string pn = paramArray(d->params);
        std::vector<Arg> args = {Arg::S(f.envSlot), Arg::L(strLabel(d->name)),
                                 Arg::L(pn), Arg::I((long long)d->params.size()),
                                 Arg::L(bodyLbl)};
        args.push_back(d->hasParent ? Arg::L(strLabel(d->parentName)) : Arg::I(0));
        args.push_back(d->hasParent ? Arg::L(pargsLbl) : Arg::I(0));
        call(f, "em_class_decl", args);
    }

    //======================= whole functions =======================

    long long frameSize(const FuncCtx& f) const {
        long long frame = 24 + 8LL * f.maxSlots + 8LL * f.maxArgs;
        return (frame + 15) & ~15LL;
    }
    std::string patchPlaceholders(const FuncCtx& f, long long frame) const {
        std::string body = f.o.str();
        auto replaceAll = [&](const std::string& ph, const std::string& real) {
            size_t pos;
            while ((pos = body.find(ph)) != std::string::npos)
                body.replace(pos, ph.size(), real);
        };
        if (target_ == Target::X86_64) {
            for (int j = 0; j < f.maxArgs; j++)
                replaceAll("@AV" + std::to_string(j) + "@",
                           "-" + std::to_string(frame - 16 - 8LL * j) + "(%rbp)");
            replaceAll("@AV0@", "-" + std::to_string(frame - 16) + "(%rbp)"); // Argv lea
        } else {
            long long base = 24 + 8LL * f.maxSlots;
            for (int j = 0; j < f.maxArgs; j++)
                replaceAll("@AV" + std::to_string(j) + "@",
                           "[x29, #" + std::to_string(base + 8LL * j) + "]");
            replaceAll("@AVB@", "#" + std::to_string(base));
            replaceAll("@FR@", "#" + std::to_string(frame));
        }
        return body;
    }

    void emitFunction(const Pending& p) {
        FuncCtx f;
        f.label = p.label;
        f.kind = p.kind;
        f.retLabel = ".Lret_" + p.label;
        f.envSlot = f.alloc();
        if (target_ == Target::X86_64)
            f.o << "\tmovq\t%rdi, " << slotRef(f.envSlot) << "\n";
        else
            f.o << "\tstr\tx0, " << slotRef(f.envSlot) << "\n";
        if (p.kind == FnKind::Pargs) {
            f.outSlot = f.alloc();
            if (target_ == Target::X86_64)
                f.o << "\tmovq\t%rsi, " << slotRef(f.outSlot) << "\n";
            else
                f.o << "\tstr\tx1, " << slotRef(f.outSlot) << "\n";
        }

        if (p.kind == FnKind::Top) {
            for (auto& st : *pendingTop_[p.label]) emitStmt(f, st.get());
        } else if (p.kind == FnKind::Fn) {
            auto* d = static_cast<FnDecl*>(p.node);
            for (auto& st : d->body->statements) emitStmt(f, st.get());
        } else if (p.kind == FnKind::Body) {
            auto* d = static_cast<ClassDecl*>(p.node);
            for (auto& st : d->body->statements) emitStmt(f, st.get());
        } else { // Pargs
            auto* d = static_cast<ClassDecl*>(p.node);
            for (size_t i = 0; i < d->parentArgs.size(); i++) {
                emitPos(f, d->parentArgs[i].get());
                int v = emitExpr(f, d->parentArgs[i].get());
                call(f, "em_clone", {Arg::S(v)});
                f.free(v);
                storeRetToOut(f, f.outSlot, i);
            }
        }

        if (p.kind == FnKind::Fn) callRaw(f, "em_nil");
        else if (p.kind == FnKind::Pargs) {
            auto* d = static_cast<ClassDecl*>(p.node);
            loadArgToRet(f, Arg::I((long long)d->parentArgs.size()));
        }
        defLabel(f, f.retLabel);
        if (target_ == Target::X86_64)
            f.o << "\tmovq\t%rbp, %rsp\n\tpopq\t%rbp\n\tret\n";
        else
            f.o << "\tldp\tx29, x30, [sp]\n\tadd\tsp, sp, @FR@\n\tret\n";

        long long frame = frameSize(f);
        if (target_ == Target::AArch64 && frame > 4095)
            throw CompileError{"function frame exceeds 4095 bytes (too many "
                               "simultaneous temporaries)", 0, 0};
        std::string body = patchPlaceholders(f, frame);

        const char* typeSuffix = target_ == Target::X86_64 ? "@function" : "%function";
        text_ << "\t.globl\t" << p.label << "\n\t.type\t" << p.label << ", "
              << typeSuffix << "\n" << p.label << ":\n";
        if (target_ == Target::X86_64) {
            text_ << "\tpushq\t%rbp\n\tmovq\t%rsp, %rbp\n"
                  << "\tsubq\t$" << frame << ", %rsp\n";
        } else {
            text_ << "\tsub\tsp, sp, #" << frame << "\n"
                  << "\tstp\tx29, x30, [sp]\n\tmov\tx29, sp\n";
        }
        text_ << body << "\t.size\t" << p.label << ", .-" << p.label << "\n\n";
    }

    void emitConstsFn() {
        const char* typeSuffix = target_ == Target::X86_64 ? "@function" : "%function";
        text_ << "\t.globl\tem_consts\n\t.type\tem_consts, " << typeSuffix
              << "\nem_consts:\n";
        FuncCtx f;                                   // scratch ctx for helpers
        if (target_ == Target::X86_64)
            f.o << "\tpushq\t%rbp\n\tmovq\t%rsp, %rbp\n";
        else
            f.o << "\tstp\tx29, x30, [sp, #-16]!\n\tmov\tx29, sp\n";
        for (auto& c : constSpecs_) {
            switch (c.kind) {
                case ConstSpec::Int:
                    loadArg(f, Arg::I(c.imm), argReg(0));
                    callRaw(f, "em_int");
                    break;
                case ConstSpec::Float:
                    loadArg(f, Arg::I(c.imm), argReg(0));
                    callRaw(f, "em_float_bits");
                    break;
                case ConstSpec::Char:
                    loadArg(f, Arg::I(c.imm), argReg(0));
                    callRaw(f, "em_char");
                    break;
                case ConstSpec::Str:
                    loadArg(f, Arg::L(c.strLbl), argReg(0));
                    loadArg(f, Arg::I(c.imm), argReg(1));
                    callRaw(f, "em_string");
                    break;
            }
            if (target_ == Target::X86_64) {
                f.o << "\tmovq\t%rax, " << c.slot << "(%rip)\n";
            } else {
                f.o << "\tadrp\tx9, " << c.slot << "\n";
                f.o << "\tstr\tx0, [x9, :lo12:" << c.slot << "]\n";
            }
        }
        if (target_ == Target::X86_64)
            f.o << "\tpopq\t%rbp\n\tret\n";
        else
            f.o << "\tldp\tx29, x30, [sp], #16\n\tret\n";
        text_ << f.o.str() << "\n";
    }

    void emitMain(const std::vector<std::pair<std::string, std::string>>& moduleInits) {
        const char* typeSuffix = target_ == Target::X86_64 ? "@function" : "%function";
        text_ << "\t.globl\tmain\n\t.type\tmain, " << typeSuffix << "\nmain:\n";
        FuncCtx f;
        if (target_ == Target::X86_64)
            f.o << "\tpushq\t%rbp\n\tmovq\t%rsp, %rbp\n";
        else
            f.o << "\tstp\tx29, x30, [sp, #-16]!\n\tmov\tx29, sp\n";
        callRaw(f, "em_rt_init");
        callRaw(f, "em_consts");
        for (auto& m : moduleInits) {
            loadArg(f, Arg::L(strLabel(m.first)), argReg(0));
            loadArg(f, Arg::L(m.second), argReg(1));
            callRaw(f, "em_module_register");
        }
        callRaw(f, "em_globals");
        retToArg0(f);
        callRaw(f, "emtop");
        if (target_ == Target::X86_64)
            f.o << "\tmovl\t$0, %eax\n\tpopq\t%rbp\n\tret\n";
        else
            f.o << "\tmov\tw0, #0\n\tldp\tx29, x30, [sp], #16\n\tret\n";
        text_ << f.o.str() << "\t.size\tmain, .-main\n\n";
    }
};

//======================= import resolution (compile time) =======================

static std::string dirOf(const std::string& path) {
    size_t slash = path.find_last_of('/');
    return slash == std::string::npos ? std::string(".") : path.substr(0, slash);
}
static bool readFile(const std::string& path, std::string& out) {
    std::ifstream in(path, std::ios::binary);
    if (!in.good()) return false;
    std::stringstream ss;
    ss << in.rdbuf();
    out = ss.str();
    return true;
}
static std::string findModuleFile(const std::string& name, const std::string& scriptDir) {
    const char* exts[] = {".em", ".emerald"};
    std::string dirs[] = {scriptDir, "."};
    for (auto& d : dirs)
        for (auto* e : exts) {
            std::string cand = d + "/" + name + e;
            std::ifstream probe(cand);
            if (probe.good()) return cand;
        }
    return "";
}

struct ModuleSet {
    std::vector<std::pair<std::string, Program*>> ordered;
    std::vector<std::unique_ptr<Program>> owner;
    std::vector<std::string> names;
    bool has(const std::string& n) {
        for (auto& x : names) if (x == n) return true;
        return false;
    }
};

static void collectImports(Node* n, std::vector<Import*>& out);
static void collectImportsBlock(Block* b, std::vector<Import*>& out) {
    if (!b) return;
    for (auto& s : b->statements) collectImports(s.get(), out);
}
static void collectImports(Node* n, std::vector<Import*>& out) {
    if (!n) return;
    switch (n->kind) {
        case NodeKind::Import:     out.push_back(static_cast<Import*>(n)); return;
        case NodeKind::Block:      collectImportsBlock(static_cast<Block*>(n), out); return;
        case NodeKind::FnDecl:     collectImportsBlock(static_cast<FnDecl*>(n)->body.get(), out); return;
        case NodeKind::ClassDecl:  collectImportsBlock(static_cast<ClassDecl*>(n)->body.get(), out); return;
        case NodeKind::If:
            for (auto& br : static_cast<If*>(n)->branches)
                collectImportsBlock(br.body.get(), out);
            return;
        case NodeKind::ForClassic: {
            auto* s = static_cast<ForClassic*>(n);
            collectImports(s->init.get(), out);
            collectImportsBlock(s->body.get(), out);
            return;
        }
        case NodeKind::ForIn:  collectImportsBlock(static_cast<ForIn*>(n)->body.get(), out); return;
        case NodeKind::While:  collectImportsBlock(static_cast<While*>(n)->body.get(), out); return;
        default: return;
    }
}

static void resolveModules(Program& prog, const std::string& scriptDir, ModuleSet& mods) {
    std::vector<Import*> imports;
    for (auto& s : prog.statements) collectImports(s.get(), imports);
    for (auto* imp : imports) {
        if (mods.has(imp->moduleName)) continue;
        std::string path = findModuleFile(imp->moduleName, scriptDir);
        if (path.empty()) {
            std::fprintf(stderr,
                "emeraldc: cannot find module '%s' (looked for %s.em / %s.emerald)\n",
                imp->moduleName.c_str(), imp->moduleName.c_str(), imp->moduleName.c_str());
            std::exit(1);
        }
        std::string src;
        readFile(path, src);
        Lexer lx(src, path);
        Parser ps(lx.tokenize());
        auto p = ps.parseProgram();
        mods.names.push_back(imp->moduleName);
        Program* raw = p.get();
        mods.owner.push_back(std::move(p));
        resolveModules(*raw, scriptDir, mods);
        mods.ordered.push_back({imp->moduleName, raw});
    }
}

//======================= driver =======================

static std::string exeDir() {
    char buf[4096];
    ssize_t n = readlink("/proc/self/exe", buf, sizeof buf - 1);
    if (n <= 0) return ".";
    buf[n] = 0;
    return dirOf(buf);
}
static bool fileExists(const std::string& p) {
    std::ifstream f(p);
    return f.good();
}
static std::string shellQuote(const std::string& s) {
    std::string out = "'";
    for (char c : s) { if (c == '\'') out += "'\\''"; else out += c; }
    return out + "'";
}
static Target hostTarget() {
#if defined(__aarch64__)
    return Target::AArch64;
#else
    return Target::X86_64;
#endif
}

int main(int argc, char** argv) {
    std::string inPath, outPath, asmPath;
    bool keepAsm = false, verbose = false;
    Target target = hostTarget();
    for (int i = 1; i < argc; i++) {
        std::string a = argv[i];
        if (a == "-o" && i + 1 < argc)      outPath = argv[++i];
        else if (a == "-S" && i + 1 < argc) asmPath = argv[++i];
        else if (a == "--keep-asm")         keepAsm = true;
        else if (a == "-v")                 verbose = true;
        else if (a.rfind("--target=", 0) == 0) {
            std::string t = a.substr(9);
            if (t == "x86_64" || t == "x86-64" || t == "amd64") target = Target::X86_64;
            else if (t == "aarch64" || t == "arm64" || t == "arm") target = Target::AArch64;
            else if (t == "native") target = hostTarget();
            else {
                std::fprintf(stderr, "emeraldc: unknown target '%s' "
                             "(supported: x86_64, aarch64)\n", t.c_str());
                return 2;
            }
        }
        else if (a == "-h" || a == "--help") {
            std::puts("usage: emeraldc file.em [-o out] [--target=x86_64|aarch64] "
                      "[-S out.s] [--keep-asm] [-v]");
            return 0;
        }
        else if (!a.empty() && a[0] == '-') {
            std::fprintf(stderr, "emeraldc: unknown option '%s'\n", a.c_str());
            return 2;
        }
        else inPath = a;
    }
    if (inPath.empty()) {
        std::fprintf(stderr, "emeraldc: no input file\nusage: emeraldc file.em [-o out]\n");
        return 2;
    }
    std::string src;
    if (!readFile(inPath, src)) {
        std::fprintf(stderr, "emeraldc: cannot open '%s'\n", inPath.c_str());
        return 1;
    }
    if (outPath.empty()) {
        std::string base = inPath;
        size_t slash = base.find_last_of('/');
        if (slash != std::string::npos) base = base.substr(slash + 1);
        size_t dot = base.find_last_of('.');
        if (dot != std::string::npos) base = base.substr(0, dot);
        outPath = base.empty() ? "a.out" : base;
    }

    std::string assembly;
    try {
        Lexer lexer(src, inPath);
        Parser parser(lexer.tokenize());
        auto program = parser.parseProgram();
        ModuleSet mods;
        resolveModules(*program, dirOf(inPath), mods);
        CodeGen cg(target);
        assembly = cg.compile(*program, mods.ordered);
        if (verbose)
            std::fprintf(stderr, "emeraldc: target %s, %zu module(s), %zu bytes of assembly\n",
                         target == Target::X86_64 ? "x86_64" : "aarch64",
                         mods.ordered.size(), assembly.size());
    } catch (const EmeraldError& e) {
        std::fprintf(stderr, "emeraldc: %s", e.stage.c_str());
        if (e.line >= 0) {
            std::fprintf(stderr, " at line %d", e.line);
            if (e.col >= 0) std::fprintf(stderr, ", col %d", e.col);
        }
        std::fprintf(stderr, ": %s\n", e.what());
        return 1;
    } catch (const CompileError& e) {
        std::fprintf(stderr, "emeraldc: compile error at line %d, col %d: %s\n",
                     e.line, e.col, e.msg.c_str());
        return 1;
    }

    std::string sPath = !asmPath.empty() ? asmPath
                       : keepAsm ? outPath + ".s"
                       : "/tmp/emeraldc_" + std::to_string(getpid()) + ".s";
    {
        std::ofstream sf(sPath, std::ios::binary);
        sf << assembly;
    }

    bool cross = target != hostTarget();
    std::string asCmd   = target == Target::X86_64 ? "as --64" : "aarch64-linux-gnu-as";
    std::string linkCmd = target == hostTarget()
                        ? "g++"
                        : (target == Target::AArch64 ? "aarch64-linux-gnu-g++" : "g++");
    std::string libName = target == Target::X86_64 ? "libemrt.a" : "libemrt-aarch64.a";

    std::string home = exeDir();
    std::string lib;
    const char* envHome = std::getenv("EMERALDC_HOME");
    for (std::string cand : {envHome ? std::string(envHome) + "/" + libName : "",
                             home + "/" + libName, home + "/../lib/" + libName}) {
        if (!cand.empty() && fileExists(cand)) { lib = cand; break; }
    }
    if (lib.empty()) {
        std::fprintf(stderr, "emeraldc: cannot find %s (set EMERALDC_HOME; "
                     "for aarch64 run 'make aarch64' first)\n", libName.c_str());
        return 1;
    }
    std::string oPath = "/tmp/emeraldc_" + std::to_string(getpid()) + ".o";
    std::string cmd1 = asCmd + " -o " + shellQuote(oPath) + " " + shellQuote(sPath);
    std::string cmd2 = linkCmd + (cross ? " -static" : "") + " -o " + shellQuote(outPath) +
                       " " + shellQuote(oPath) + " " + shellQuote(lib) + " -lm";
    if (verbose) std::fprintf(stderr, "emeraldc: %s\nemeraldc: %s\n", cmd1.c_str(), cmd2.c_str());
    if (std::system(cmd1.c_str()) != 0) {
        std::fprintf(stderr, "emeraldc: assembler failed (asm kept at %s)\n", sPath.c_str());
        return 1;
    }
    if (std::system(cmd2.c_str()) != 0) {
        std::fprintf(stderr, "emeraldc: linker failed\n");
        return 1;
    }
    std::remove(oPath.c_str());
    if (asmPath.empty() && !keepAsm) std::remove(sPath.c_str());
    return 0;
}
