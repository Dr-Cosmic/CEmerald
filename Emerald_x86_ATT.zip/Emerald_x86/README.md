# emeraldc — an x86-64 compiler for the Emerald language

# Author: Jean-Jacques François Reibel

`emeraldc` compiles Emerald (https://github.com/Dr-Cosmic/Emerald) to native
x86-64 Linux executables (System V ABI, AT&T assembly via GNU `as`, linked with
`g++`). It is engineered *on top of everything that already exists* for
Emerald: the reference interpreter's own lexer and parser are the compiler's
front end, and the interpreter's own value model, environments, builtins, SQL
engine and JSON store are linked verbatim into the runtime library. What is
new is the back end — a code generator that turns the AST into machine code —
and a thin `extern "C"` runtime ABI that the generated code calls for dynamic
operations.

## Build & use

    make                      # produces build/emeraldc and build/libemrt.a
    build/emeraldc prog.em -o prog
    ./prog

Options: `-o out` (output executable), `-S out.s` (write the generated
assembly), `--keep-asm`, `-v`. Imports are resolved at compile time: every
`import`ed module (searched as `<name>.em` / `<name>.emerald` beside the
script, then in the CWD) is parsed and compiled into the same executable;
module initialisers run on first import at runtime, with caching and
circular-import detection, exactly like the interpreter.

    make test                 # runs the reference repo's full test suite
                              # (set EMERALD_REPO if the clone lives elsewhere)

## What is compiled vs. what is runtime

Generated machine code natively handles: statement sequencing, `if`/`elif`/
`else`, all three loop forms with `break`/`continue` as jumps, function bodies
(`Value* f(Environment*)`), class bodies and parent-constructor argument
thunks, short-circuit `&&`/`||`, `return` as a jump to the epilogue, and all
call/argument marshalling (a frame-local argv scratch area; frames are
16-byte aligned with no dynamic pushes).

The runtime ABI (`src/rt.cpp`) supplies the dynamic semantics as faithful
ports or direct reuse of interpreter code: arithmetic with Emerald's numeric
tower (`/` always float, Python-style `//` and `%`, `**`), loose vs. strict
equality, comparisons, string interpolation, arrays (grow-on-write with nil
gaps, gather indexing, deep-copy value semantics), member/index access, typed
declarations with coercion, `File` creation, class instantiation with
inheritance (parent args evaluated in the child's constructor scope; fields vs.
locals via the interpreter's own `constructing` environments), first-class
functions and closures, `for … in` over arrays/strings/tables, and modules.
Builtins — `print`, `printdlm`, `printtbl`, `len`/`length`, `type`, casts,
the math library, `getinput`, `shellexec`, `sqlexec`/`execsql`/`sqldatadir`,
`File`, `pi`, `e` — are the interpreter's own `builtins.cpp`, unmodified.

Three tiny vendored patches (marked `[emeraldc]`) make this possible: native
entry-point fields on `FunctionData`/`ClassData`, native-dispatch branches in
`callValue`/`constructLevel`, and public wrappers on `Interpreter`. Everything
else in `vendored/` is byte-identical to the upstream sources.

## Fidelity

Correctness is defined as observational equivalence with the interpreter. The
repository's full test suite (`tests/test_*.em`, 11 files covering basics,
operators, strings, arrays, control flow, functions, classes, files, shell,
SQL and imports) passes byte-identically, as do all runnable `examples/`.
Runtime errors match the interpreter's format, message, line **and column**
(positions are asserted per operation, not per statement), and exit codes
agree — including cases where a buggy program fails: the compiled binary
reproduces the interpreter's exact diagnostic.

## Limitations (v1, by design)

Memory: value boxes and environments are never freed (no GC yet); long-running
loop-heavy programs grow steadily. Variable access goes through environment
chains for exact scoping/closure semantics — a compiled `fib(27)` runs about
2.3× faster than the interpreter, but slot-allocating provably-local variables
and adding a box freelist are the obvious next optimisations. Targets x86-64
SysV Linux only (32-bit x86 is not supported). The REPL remains the
interpreter's domain. C++ exceptions never unwind through generated frames:
every ABI entry traps `EmeraldError` and reports/exits, and `return`/`break`/
`continue` compile to jumps.

## License

Emerald is GPL-3.0; `emeraldc` vendors and links its sources and is therefore
distributed under GPL-3.0 as a derivative work. See `LICENSE`.
