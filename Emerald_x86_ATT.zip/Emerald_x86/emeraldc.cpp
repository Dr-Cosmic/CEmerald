// emeraldc.cpp - An x86-64 (System V, Linux) compiler for the Emerald language.
//
// Front end: the reference implementation's own lexer & parser (vendored),
// so emeraldc accepts exactly the language the interpreter accepts.
// Back end: this file - walks the AST once per function and emits AT&T
// assembly. Control flow, calls and sequencing are native machine code;
// dynamic operations call the runtime ABI implemented in rt.cpp.
//
// Usage: emeraldc file.em [-o out] [-S asm.s] [--keep-asm] [-v]

#include "../vendored/lexer.h"
#include "../vendored/parser.h"
#include "../vendored/ast.h"
#include "../vendored/errors.h"

#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <fstream>
#include <map>
#include <memory>
#include <sstream>
#include <string>
#include <unordered_map>
#include <vector>
#include <functional>
#include <unistd.h>

using namespace emerald;

struct CompileError {
    std::string msg;
    int line, col;
};

//======================= assembly text helpers =======================

static std::string escAsm(const std::string& s) {
    std::string out;
    for (unsigned char c : s) {
        if (c == '"' || c == '\\') { out += '\\'; out += static_cast<char>(c); }
        else if (c >= 32 && c < 127) out += static_cast<char>(c);
        else {
            char buf[8];
            std::snprintf(buf, sizeof buf, "\\%03o", c);
            out += buf;
        }
    }
    return out;
}

//======================= per-function emission context =======================

enum class FnKind { Top, Fn, Body, Pargs };

struct FuncCtx {
    std::string label;
    FnKind kind;
    std::ostringstream o;          // body text with placeholders
    int nextSlot = 0, maxSlots = 0;
    std::vector<int> freeSlots;
    int maxArgs = 0;
    int envSlot = -1;              // slot holding current Environment*
    int outSlot = -1;              // Pargs: slot holding Value** out
    std::string retLabel;
    struct Loop { std::string brk, cont; };
    std::vector<Loop> loops;

    int alloc() {
        if (!freeSlots.empty()) { int s = freeSlots.back(); freeSlots.pop_back(); return s; }
        int s = nextSlot++;
        if (nextSlot > maxSlots) maxSlots = nextSlot;
        return s;
    }
    void free(int s) { if (s >= 0) freeSlots.push_back(s); }
    static std::string slotRef(int s) { return "-" + std::to_string(16 + 8 * s) + "(%rbp)"; }
};

// A pending function to emit (worklist keeps buffers independent).
struct Pending {
    std::string label;
    FnKind kind;
    Node* node;         // FnDecl (Fn), ClassDecl (Body/Pargs), or nullptr (Top)
};

//======================= the code generator =======================

class CodeGen {
public:
    CodeGen() {}

    std::string compile(Program& mainProg,
                        std::vector<std::pair<std::string, Program*>>& modules) {
        // Queue module initialisers first, then the script top level.
        std::vector<std::pair<std::string, std::string>> moduleInits; // (name,label)
        for (auto& m : modules) {
            std::string lbl = "emmod_" + std::to_string(fnCounter_++);
            moduleInits.push_back({m.first, lbl});
            pending_.push_back({lbl, FnKind::Top, nullptr});
            pendingTop_[lbl] = &m.second->statements;
        }
        pending_.push_back({"emtop", FnKind::Top, nullptr});
        pendingTop_["emtop"] = &mainProg.statements;

        while (!pending_.empty()) {
            Pending p = pending_.front();
            pending_.erase(pending_.begin());
            emitFunction(p);
        }
        emitConstsFn();
        emitMain(moduleInits);

        std::ostringstream out;
        out << "\t.file\t\"emeraldc\"\n";
        out << rodata_.str();
        out << data_.str();
        out << bss_.str();
        out << "\t.text\n";
        out << text_.str();
        out << "\t.section .note.GNU-stack,\"\",@progbits\n";
        return out.str();
    }

private:
    int fnCounter_ = 0, labelCounter_ = 0, strCounter_ = 0, constCounter_ = 0,
        arrCounter_ = 0;
    std::ostringstream rodata_, data_, bss_, text_;
    std::vector<Pending> pending_;
    std::unordered_map<std::string, std::vector<NodePtr>*> pendingTop_;
    std::unordered_map<std::string, std::string> strLabels_;   // raw text -> .Lc label
    std::map<std::string, std::string> valueConsts_;           // key -> Vc label
    std::vector<std::pair<std::string, std::string>> constBuilders_; // (label,builder asm)

    std::string newLabel(const std::string& stem) {
        return ".L" + stem + std::to_string(labelCounter_++);
    }

    // ---- constants ----
    std::string strLabel(const std::string& s) {
        auto it = strLabels_.find(s);
        if (it != strLabels_.end()) return it->second;
        std::string lbl = ".Lc" + std::to_string(strCounter_++);
        rodata_ << "\t.section .rodata\n" << lbl << ":\n\t.string \"" << escAsm(s)
                << "\"\n";
        strLabels_[s] = lbl;
        return lbl;
    }
    std::string valueConst(const std::string& key,
                           std::function<std::string(const std::string&)> builder) {
        auto it = valueConsts_.find(key);
        if (it != valueConsts_.end()) return it->second;
        std::string lbl = "Vc" + std::to_string(constCounter_++);
        bss_ << "\t.bss\n\t.align 8\n" << lbl << ":\n\t.zero 8\n";
        constBuilders_.push_back({lbl, builder(lbl)});
        valueConsts_[key] = lbl;
        return lbl;
    }
    std::string intConst(long long v) {
        return valueConst("i:" + std::to_string(v), [&](const std::string& lbl) {
            std::ostringstream b;
            b << "\tmovabsq\t$" << v << ", %rdi\n\tcall\tem_int\n";
            return b.str();
        });
    }
    std::string floatConst(double d) {
        long long bits;
        std::memcpy(&bits, &d, 8);
        return valueConst("f:" + std::to_string(bits), [&](const std::string& lbl) {
            std::ostringstream b;
            b << "\tmovabsq\t$" << bits << ", %rdi\n\tcall\tem_float_bits\n";
            return b.str();
        });
    }
    std::string charConst(char c) {
        return valueConst("c:" + std::to_string((int)(unsigned char)c),
                          [&](const std::string& lbl) {
            std::ostringstream b;
            b << "\tmovq\t$" << (int)(unsigned char)c << ", %rdi\n\tcall\tem_char\n";
            return b.str();
        });
    }
    std::string stringConst(const std::string& s) {
        std::string cl = strLabel(s);
        return valueConst("s:" + s, [&](const std::string& lbl) {
            std::ostringstream b;
            b << "\tleaq\t" << cl << "(%rip), %rdi\n\tmovq\t$" << s.size()
              << ", %rsi\n\tcall\tem_string\n";
            return b.str();
        });
    }
    std::string paramArray(const std::vector<Param>& params) {
        std::string lbl = "PN" + std::to_string(arrCounter_++);
        data_ << "\t.data\n\t.align 8\n" << lbl << ":\n";
        for (auto& p : params) data_ << "\t.quad\t" << strLabel(p.name) << "\n";
        if (params.empty()) data_ << "\t.quad\t0\n";
        return lbl;
    }

    // ---- low-level emission ----
    struct Arg {                       // operand for an integer argument register
        enum K { Slot, Imm, Lea, BigImm } k;
        long long imm = 0;
        int slot = -1;
        std::string label;
        static Arg S(int s)                    { Arg a; a.k = Slot;   a.slot = s;   return a; }
        static Arg I(long long v)              { Arg a; a.k = Imm;    a.imm = v;    return a; }
        static Arg B(long long v)              { Arg a; a.k = BigImm; a.imm = v;    return a; }
        static Arg L(const std::string& l)     { Arg a; a.k = Lea;    a.label = l;  return a; }
    };
    static const char* argReg(size_t i) {
        static const char* regs[6] = {"%rdi", "%rsi", "%rdx", "%rcx", "%r8", "%r9"};
        return regs[i];
    }
    void loadArg(FuncCtx& f, const Arg& a, const char* reg) {
        switch (a.k) {
            case Arg::Slot: f.o << "\tmovq\t" << FuncCtx::slotRef(a.slot) << ", " << reg << "\n"; break;
            case Arg::Imm:  f.o << "\tmovq\t$" << a.imm << ", " << reg << "\n"; break;
            case Arg::BigImm: f.o << "\tmovabsq\t$" << a.imm << ", " << reg << "\n"; break;
            case Arg::Lea:  f.o << "\tleaq\t" << a.label << "(%rip), " << reg << "\n"; break;
        }
    }
    // Call a runtime function; result (if any) is in %rax afterwards.
    void call(FuncCtx& f, const std::string& fn, std::vector<Arg> args) {
        for (size_t i = 0; i < args.size() && i < 6; i++) loadArg(f, args[i], argReg(i));
        for (size_t i = 6; i < args.size(); i++) {           // stack args (7th+)
            loadArg(f, args[i], "%r10");
            f.o << "\tmovq\t%r10, " << 8 * (i - 6) << "(%rsp)\n";
        }
        f.o << "\tcall\t" << fn << "\n";
    }
    int saveRax(FuncCtx& f) {
        int s = f.alloc();
        f.o << "\tmovq\t%rax, " << FuncCtx::slotRef(s) << "\n";
        return s;
    }
    void emitPos(FuncCtx& f, Node* n) {
        call(f, "em_pos", {Arg::I(n->line), Arg::I(n->col)});
    }
    // Variant for sites where argument registers are already staged: stores the
    // position directly instead of calling em_pos.
    void emitPos2(FuncCtx& f, Node* n) {
        f.o << "\tmovq\t$" << n->line << ", em_line(%rip)\n";
        f.o << "\tmovq\t$" << n->col << ", em_col(%rip)\n";
    }
    // Copy already-evaluated slots into the argv scratch area; returns the
    // placeholder operand for `lea` of argv[0]. Slots are freed.
    std::string buildArgv(FuncCtx& f, std::vector<int>& slots) {
        if ((int)slots.size() > f.maxArgs) f.maxArgs = (int)slots.size();
        for (size_t j = 0; j < slots.size(); j++) {
            f.o << "\tmovq\t" << FuncCtx::slotRef(slots[j]) << ", %r10\n";
            f.o << "\tmovq\t%r10, @AV" << j << "@\n";
        }
        for (int s : slots) f.free(s);
        return "@AV0@";
    }

    [[noreturn]] void err(Node* n, const std::string& m) {
        throw CompileError{m, n->line, n->col};
    }

    //======================= expressions =======================

    // Evaluate an expression; result Value* lives in the returned slot.
    int emitExpr(FuncCtx& f, Node* n) {
        switch (n->kind) {
            case NodeKind::IntLit: {
                f.o << "\tmovq\t" << intConst(static_cast<IntLit*>(n)->value)
                    << "(%rip), %rax\n";
                return saveRax(f);
            }
            case NodeKind::FloatLit: {
                f.o << "\tmovq\t" << floatConst(static_cast<FloatLit*>(n)->value)
                    << "(%rip), %rax\n";
                return saveRax(f);
            }
            case NodeKind::CharLit: {
                f.o << "\tmovq\t" << charConst(static_cast<CharLit*>(n)->value)
                    << "(%rip), %rax\n";
                return saveRax(f);
            }
            case NodeKind::BoolLit:
                call(f, "em_bool", {Arg::I(static_cast<BoolLit*>(n)->value ? 1 : 0)});
                return saveRax(f);
            case NodeKind::NilLit:
                call(f, "em_nil", {});
                return saveRax(f);
            case NodeKind::StringLit: return emitStringLit(f, static_cast<StringLit*>(n));
            case NodeKind::ArrayLit: {
                auto* a = static_cast<ArrayLit*>(n);
                std::vector<int> slots;
                for (auto& e : a->elements) slots.push_back(emitExpr(f, e.get()));
                std::string av = buildArgv(f, slots);
                f.o << "\tleaq\t" << av << ", %rdi\n";
                f.o << "\tmovq\t$" << a->elements.size() << ", %rsi\n";
                f.o << "\tcall\tem_arraylit\n";
                return saveRax(f);
            }
            case NodeKind::Identifier:
                emitPos(f, n);
                call(f, "em_env_get", {Arg::S(f.envSlot),
                                       Arg::L(strLabel(static_cast<Identifier*>(n)->name))});
                return saveRax(f);
            case NodeKind::Binary:   return emitBinary(f, static_cast<Binary*>(n));
            case NodeKind::Unary: {
                auto* u = static_cast<Unary*>(n);
                if (u->op == "++" || u->op == "--")
                    return emitIncDec(f, u->operand.get(), u->op == "++" ? 1 : -1, true);
                int v = emitExpr(f, u->operand.get());
                const char* fn = u->op == "!" ? "em_not"
                               : u->op == "-" ? "em_neg"
                               : u->op == "+" ? "em_pos_op" : nullptr;
                if (!fn) err(n, "unsupported unary operator '" + u->op + "'");
                emitPos(f, n);
                call(f, fn, {Arg::S(v)});
                f.free(v);
                return saveRax(f);
            }
            case NodeKind::PostfixOp: {
                auto* p = static_cast<PostfixOp*>(n);
                return emitIncDec(f, p->operand.get(), p->op == "++" ? 1 : -1, false);
            }
            case NodeKind::Assign:   return emitAssign(f, static_cast<Assign*>(n));
            case NodeKind::Call:     return emitCall(f, static_cast<Call*>(n), false);
            case NodeKind::Index: {
                auto* ix = static_cast<Index*>(n);
                int obj = emitExpr(f, ix->object.get());
                std::vector<int> slots;
                for (auto& e : ix->indices) slots.push_back(emitExpr(f, e.get()));
                std::string av = buildArgv(f, slots);
                emitPos(f, n);
                f.o << "\tmovq\t" << FuncCtx::slotRef(obj) << ", %rdi\n";
                f.o << "\tleaq\t" << av << ", %rsi\n";
                f.o << "\tmovq\t$" << ix->indices.size() << ", %rdx\n";
                f.o << "\tcall\tem_index_get\n";
                f.free(obj);
                return saveRax(f);
            }
            case NodeKind::Member: {
                auto* m = static_cast<Member*>(n);
                int obj = emitExpr(f, m->object.get());
                emitPos(f, n);
                call(f, "em_member_get", {Arg::S(obj), Arg::L(strLabel(m->name))});
                f.free(obj);
                return saveRax(f);
            }
            default:
                err(n, "invalid expression");
        }
    }

    int emitStringLit(FuncCtx& f, StringLit* s) {
        if (s->parts.size() == 1 && !s->parts[0].isExpr) {
            f.o << "\tmovq\t" << stringConst(s->parts[0].literal) << "(%rip), %rax\n";
            return saveRax(f);
        }
        if (s->parts.empty()) {
            f.o << "\tmovq\t" << stringConst("") << "(%rip), %rax\n";
            return saveRax(f);
        }
        std::vector<int> slots;
        for (auto& part : s->parts) {
            if (part.isExpr) {
                slots.push_back(emitExpr(f, part.expr.get()));
            } else {
                f.o << "\tmovq\t" << stringConst(part.literal) << "(%rip), %rax\n";
                slots.push_back(saveRax(f));
            }
        }
        size_t n = slots.size();
        std::string av = buildArgv(f, slots);
        f.o << "\tleaq\t" << av << ", %rdi\n";
        f.o << "\tmovq\t$" << n << ", %rsi\n";
        f.o << "\tcall\tem_interp\n";
        return saveRax(f);
    }

    int emitBinary(FuncCtx& f, Binary* b) {
        const std::string& op = b->op;
        if (op == "&&" || op == "||") {
            std::string lShort = newLabel("sc"), lEnd = newLabel("scend");
            int res = f.alloc();
            int l = emitExpr(f, b->left.get());
            call(f, "em_truthy", {Arg::S(l)});
            f.free(l);
            f.o << "\ttestq\t%rax, %rax\n";
            f.o << (op == "&&" ? "\tjz\t" : "\tjnz\t") << lShort << "\n";
            int r = emitExpr(f, b->right.get());
            call(f, "em_truthy", {Arg::S(r)});
            f.free(r);
            f.o << "\tmovq\t%rax, %rdi\n\tcall\tem_bool\n";
            f.o << "\tmovq\t%rax, " << FuncCtx::slotRef(res) << "\n";
            f.o << "\tjmp\t" << lEnd << "\n";
            f.o << lShort << ":\n";
            call(f, "em_bool", {Arg::I(op == "&&" ? 0 : 1)});
            f.o << "\tmovq\t%rax, " << FuncCtx::slotRef(res) << "\n";
            f.o << lEnd << ":\n";
            return res;
        }
        int l = emitExpr(f, b->left.get());
        int r = emitExpr(f, b->right.get());
        emitPos(f, b);
        if (op == "==")       call(f, "em_eq",  {Arg::S(l), Arg::S(r), Arg::I(0), Arg::I(0)});
        else if (op == "!=")  call(f, "em_eq",  {Arg::S(l), Arg::S(r), Arg::I(0), Arg::I(1)});
        else if (op == "===") call(f, "em_eq",  {Arg::S(l), Arg::S(r), Arg::I(1), Arg::I(0)});
        else if (op == "!==") call(f, "em_eq",  {Arg::S(l), Arg::S(r), Arg::I(1), Arg::I(1)});
        else if (op == "<")   call(f, "em_cmp", {Arg::S(l), Arg::S(r), Arg::I(0)});
        else if (op == "<=")  call(f, "em_cmp", {Arg::S(l), Arg::S(r), Arg::I(1)});
        else if (op == ">")   call(f, "em_cmp", {Arg::S(l), Arg::S(r), Arg::I(2)});
        else if (op == ">=")  call(f, "em_cmp", {Arg::S(l), Arg::S(r), Arg::I(3)});
        else if (op == "+")   call(f, "em_add",  {Arg::S(l), Arg::S(r)});
        else if (op == "-")   call(f, "em_sub",  {Arg::S(l), Arg::S(r)});
        else if (op == "*")   call(f, "em_mul",  {Arg::S(l), Arg::S(r)});
        else if (op == "/")   call(f, "em_div",  {Arg::S(l), Arg::S(r)});
        else if (op == "//")  call(f, "em_fdiv", {Arg::S(l), Arg::S(r)});
        else if (op == "%")   call(f, "em_mod",  {Arg::S(l), Arg::S(r)});
        else if (op == "**")  call(f, "em_pow",  {Arg::S(l), Arg::S(r)});
        else err(b, "unsupported binary operator '" + op + "'");
        f.free(l); f.free(r);
        return saveRax(f);
    }

    // Store `valSlot` into an lvalue (no cloning here; callers prepare the value
    // exactly as the interpreter's assignTo expects).
    void emitStore(FuncCtx& f, Node* target, int valSlot) {
        emitPos(f, target);
        switch (target->kind) {
            case NodeKind::Identifier:
                call(f, "em_env_assign", {Arg::S(f.envSlot),
                     Arg::L(strLabel(static_cast<Identifier*>(target)->name)),
                     Arg::S(valSlot)});
                return;
            case NodeKind::Member: {
                auto* m = static_cast<Member*>(target);
                int obj = emitExpr(f, m->object.get());
                emitPos(f, target);
                call(f, "em_member_set", {Arg::S(obj), Arg::L(strLabel(m->name)),
                                          Arg::S(valSlot)});
                f.free(obj);
                return;
            }
            case NodeKind::Index: {
                auto* ix = static_cast<Index*>(target);
                if (ix->indices.size() != 1) { call(f, "em_index_set_multi_error", {}); return; }
                int obj = emitExpr(f, ix->object.get());
                int idx = emitExpr(f, ix->indices[0].get());
                emitPos(f, target);
                call(f, "em_index_set", {Arg::S(obj), Arg::S(idx), Arg::S(valSlot)});
                f.free(obj); f.free(idx);
                return;
            }
            default:
                err(target, "invalid assignment target");
        }
    }
    int emitLvalueGet(FuncCtx& f, Node* target) {
        if (target->kind == NodeKind::Identifier || target->kind == NodeKind::Member ||
            target->kind == NodeKind::Index)
            return emitExpr(f, target);
        err(target, "invalid target of '++'/'--'");
    }

    int emitAssign(FuncCtx& f, Assign* a) {
        int v = emitExpr(f, a->value.get());
        call(f, "em_assign_prepare", {Arg::S(v)});
        f.free(v);
        int prepared = saveRax(f);
        emitStore(f, a->target.get(), prepared);
        return prepared;                       // an assignment yields its value
    }

    int emitIncDec(FuncCtx& f, Node* target, long long delta, bool prefix) {
        int oldv = emitLvalueGet(f, target);
        call(f, "em_incdec_next", {Arg::S(oldv), Arg::I(delta)});
        int next = saveRax(f);
        emitStore(f, target, next);            // interpreter re-evaluates target parts
        if (prefix) { f.free(oldv); return next; }
        f.free(next);
        return oldv;
    }

    int emitCall(FuncCtx& f, Call* c, bool stmtCtx) {
        std::vector<int> argSlots;
        if (c->callee->kind == NodeKind::Member) {
            auto* m = static_cast<Member*>(c->callee.get());
            int recv = emitExpr(f, m->object.get());
            for (auto& a : c->args) argSlots.push_back(emitExpr(f, a.get()));
            size_t n = argSlots.size();
            std::string av = buildArgv(f, argSlots);
            f.o << "\tmovq\t" << FuncCtx::slotRef(recv) << ", %rdi\n";
            f.o << "\tleaq\t" << strLabel(m->name) << "(%rip), %rsi\n";
            f.o << "\tleaq\t" << av << ", %rdx\n";
            f.o << "\tmovq\t$" << n << ", %rcx\n";
            f.o << "\tmovq\t$" << (c->trailingComma ? 1 : 0) << ", %r8\n";
            // (position asserted below, right before the shim)
            f.o << "\tmovq\t$" << (stmtCtx ? 1 : 0) << ", %r9\n";
            emitPos2(f, c);
            f.o << "\tcall\tem_method_call\n";
            f.free(recv);
            return saveRax(f);
        }
        int callee = emitExpr(f, c->callee.get());
        for (auto& a : c->args) argSlots.push_back(emitExpr(f, a.get()));
        size_t n = argSlots.size();
        std::string av = buildArgv(f, argSlots);
        f.o << "\tmovq\t" << FuncCtx::slotRef(callee) << ", %rdi\n";
        f.o << "\tleaq\t" << av << ", %rsi\n";
        f.o << "\tmovq\t$" << n << ", %rdx\n";
        emitPos2(f, c);
        f.o << "\tcall\tem_call_value\n";
        f.free(callee);
        return saveRax(f);
    }

    //======================= statements =======================

    bool isExprKind(NodeKind k) {
        switch (k) {
            case NodeKind::IntLit: case NodeKind::FloatLit: case NodeKind::CharLit:
            case NodeKind::StringLit: case NodeKind::BoolLit: case NodeKind::NilLit:
            case NodeKind::ArrayLit: case NodeKind::Identifier: case NodeKind::Binary:
            case NodeKind::Unary: case NodeKind::PostfixOp: case NodeKind::Assign:
            case NodeKind::Call: case NodeKind::Index: case NodeKind::Member:
                return true;
            default: return false;
        }
    }

    void emitStmt(FuncCtx& f, Node* n) {
        emitPos(f, n);
        switch (n->kind) {
            case NodeKind::VarDecl:   emitVarDecl(f, static_cast<VarDecl*>(n)); return;
            case NodeKind::ExprStmt: {
                auto* es = static_cast<ExprStmt*>(n);
                int s;
                if (es->expr->kind == NodeKind::Call)
                    s = emitCall(f, static_cast<Call*>(es->expr.get()), true);
                else
                    s = emitExpr(f, es->expr.get());
                f.free(s);
                return;
            }
            case NodeKind::Block: {
                call(f, "em_env_new", {Arg::S(f.envSlot)});
                int child = saveRax(f);
                int saved = f.envSlot; f.envSlot = child;
                for (auto& st : static_cast<Block*>(n)->statements) emitStmt(f, st.get());
                f.envSlot = saved; f.free(child);
                return;
            }
            case NodeKind::FnDecl:    emitFnDecl(f, static_cast<FnDecl*>(n)); return;
            case NodeKind::ClassDecl: emitClassDecl(f, static_cast<ClassDecl*>(n)); return;
            case NodeKind::Return: {
                auto* r = static_cast<Return*>(n);
                int v;
                if (r->value) v = emitExpr(f, r->value.get());
                else { call(f, "em_nil", {}); v = saveRax(f); }
                call(f, "em_clone", {Arg::S(v)});          // ReturnSignal clones
                f.free(v);
                f.o << "\tjmp\t" << f.retLabel << "\n";
                return;
            }
            case NodeKind::If: {
                auto* s = static_cast<If*>(n);
                std::string lEnd = newLabel("ifend");
                for (auto& br : s->branches) {
                    std::string lNext = newLabel("ifnx");
                    if (br.condition) {
                        int c = emitExpr(f, br.condition.get());
                        call(f, "em_truthy", {Arg::S(c)});
                        f.free(c);
                        f.o << "\ttestq\t%rax, %rax\n\tjz\t" << lNext << "\n";
                    }
                    call(f, "em_env_new", {Arg::S(f.envSlot)});
                    int child = saveRax(f);
                    int saved = f.envSlot; f.envSlot = child;
                    for (auto& st : br.body->statements) emitStmt(f, st.get());
                    f.envSlot = saved; f.free(child);
                    f.o << "\tjmp\t" << lEnd << "\n";
                    f.o << lNext << ":\n";
                    if (!br.condition) break;   // `else` consumed; anything after is dead
                }
                f.o << lEnd << ":\n";
                return;
            }
            case NodeKind::ForClassic: {
                auto* s = static_cast<ForClassic*>(n);
                call(f, "em_env_new", {Arg::S(f.envSlot)});
                int loopEnv = saveRax(f);
                int saved = f.envSlot; f.envSlot = loopEnv;
                if (s->init) {
                    if (isExprKind(s->init->kind)) { int t = emitExpr(f, s->init.get()); f.free(t); }
                    else emitStmt(f, s->init.get());
                }
                std::string lCond = newLabel("forc"), lCont = newLabel("forU"),
                            lBrk = newLabel("forX");
                f.o << lCond << ":\n";
                if (s->condition) {
                    int c = emitExpr(f, s->condition.get());
                    call(f, "em_truthy", {Arg::S(c)});
                    f.free(c);
                    f.o << "\ttestq\t%rax, %rax\n\tjz\t" << lBrk << "\n";
                }
                f.loops.push_back({lBrk, lCont});
                call(f, "em_env_new", {Arg::S(loopEnv)});
                int body = saveRax(f);
                int savedB = f.envSlot; f.envSlot = body;
                for (auto& st : s->body->statements) emitStmt(f, st.get());
                f.envSlot = savedB; f.free(body);
                f.loops.pop_back();
                f.o << lCont << ":\n";
                if (s->update) { int u = emitExpr(f, s->update.get()); f.free(u); }
                f.o << "\tjmp\t" << lCond << "\n" << lBrk << ":\n";
                f.envSlot = saved; f.free(loopEnv);
                return;
            }
            case NodeKind::ForIn: {
                auto* s = static_cast<ForIn*>(n);
                int seq = emitExpr(f, s->iterable.get());
                call(f, "em_iter_begin", {Arg::S(seq)});
                f.free(seq);
                int iter = saveRax(f);
                call(f, "em_env_new", {Arg::S(f.envSlot)});
                int loopEnv = saveRax(f);
                std::string lNext = newLabel("finN"), lBrk = newLabel("finX");
                f.o << lNext << ":\n";
                call(f, "em_iter_next", {Arg::S(iter)});
                f.o << "\ttestq\t%rax, %rax\n\tjz\t" << lBrk << "\n";
                int el = saveRax(f);
                call(f, "em_env_define", {Arg::S(loopEnv), Arg::L(strLabel(s->varName)),
                                          Arg::S(el)});
                f.free(el);
                f.loops.push_back({lBrk, lNext});
                call(f, "em_env_new", {Arg::S(loopEnv)});
                int body = saveRax(f);
                int saved = f.envSlot; f.envSlot = body;
                for (auto& st : s->body->statements) emitStmt(f, st.get());
                f.envSlot = saved; f.free(body);
                f.loops.pop_back();
                f.o << "\tjmp\t" << lNext << "\n" << lBrk << ":\n";
                f.free(loopEnv); f.free(iter);
                return;
            }
            case NodeKind::While: {
                auto* s = static_cast<While*>(n);
                std::string lCond = newLabel("whC"), lBrk = newLabel("whX");
                f.o << lCond << ":\n";
                int c = emitExpr(f, s->condition.get());
                call(f, "em_truthy", {Arg::S(c)});
                f.free(c);
                f.o << "\ttestq\t%rax, %rax\n\tjz\t" << lBrk << "\n";
                f.loops.push_back({lBrk, lCond});
                call(f, "em_env_new", {Arg::S(f.envSlot)});
                int body = saveRax(f);
                int saved = f.envSlot; f.envSlot = body;
                for (auto& st : s->body->statements) emitStmt(f, st.get());
                f.envSlot = saved; f.free(body);
                f.loops.pop_back();
                f.o << "\tjmp\t" << lCond << "\n" << lBrk << ":\n";
                return;
            }
            case NodeKind::Import: {
                auto* s = static_cast<Import*>(n);
                if (s->isFrom)
                    call(f, "em_import_from", {Arg::S(f.envSlot),
                         Arg::L(strLabel(s->moduleName)), Arg::L(strLabel(s->symbolName))});
                else
                    call(f, "em_import", {Arg::S(f.envSlot),
                                          Arg::L(strLabel(s->moduleName))});
                return;
            }
            case NodeKind::Break:
                if (f.loops.empty()) err(n, "'break' used outside of a loop");
                f.o << "\tjmp\t" << f.loops.back().brk << "\n";
                return;
            case NodeKind::Continue:
                if (f.loops.empty()) err(n, "'continue' used outside of a loop");
                f.o << "\tjmp\t" << f.loops.back().cont << "\n";
                return;
            default: {
                int s = emitExpr(f, n);       // bare expression in statement position
                f.free(s);
                return;
            }
        }
    }

    void emitVarDecl(FuncCtx& f, VarDecl* d) {
        int init = -1;
        if (d->initializer) init = emitExpr(f, d->initializer.get());
        std::vector<int> ctorSlots;
        for (auto& a : d->ctorArgs) ctorSlots.push_back(emitExpr(f, a.get()));
        size_t nCtor = ctorSlots.size();
        std::string av = nCtor ? buildArgv(f, ctorSlots) : "";
        // 7-argument shim: the seventh travels on the stack.
        f.o << "\tmovq\t" << FuncCtx::slotRef(f.envSlot) << ", %rdi\n";
        f.o << "\tleaq\t" << strLabel(d->declaredType) << "(%rip), %rsi\n";
        f.o << "\tleaq\t" << strLabel(d->name) << "(%rip), %rdx\n";
        f.o << "\tmovq\t$" << (d->isArray ? 1 : 0) << ", %rcx\n";
        if (init >= 0) f.o << "\tmovq\t" << FuncCtx::slotRef(init) << ", %r8\n";
        else           f.o << "\tmovq\t$0, %r8\n";
        if (nCtor)     f.o << "\tleaq\t" << av << ", %r9\n";
        else           f.o << "\tmovq\t$0, %r9\n";
        f.o << "\tmovq\t$" << nCtor << ", %r10\n\tmovq\t%r10, 0(%rsp)\n";
        f.o << "\tcall\tem_vardecl\n";
        f.free(init);
    }

    void emitFnDecl(FuncCtx& f, FnDecl* d) {
        std::string lbl = "emfn_" + std::to_string(fnCounter_++);
        pending_.push_back({lbl, FnKind::Fn, d});
        std::string pn = paramArray(d->params);
        call(f, "em_fn_decl", {Arg::S(f.envSlot), Arg::L(strLabel(d->name)),
                               Arg::L(lbl), Arg::L(pn), Arg::I((long long)d->params.size())});
    }

    void emitClassDecl(FuncCtx& f, ClassDecl* d) {
        if (d->isObjectVarDecl) {
            call(f, "em_object_var_decl", {Arg::S(f.envSlot), Arg::L(strLabel(d->name))});
            return;
        }
        std::string bodyLbl = "emcb_" + std::to_string(fnCounter_++);
        pending_.push_back({bodyLbl, FnKind::Body, d});
        std::string pargsLbl;
        if (d->hasParent) {
            pargsLbl = "empa_" + std::to_string(fnCounter_++);
            pending_.push_back({pargsLbl, FnKind::Pargs, d});
        }
        std::string pn = paramArray(d->params);
        std::vector<Arg> args = {Arg::S(f.envSlot), Arg::L(strLabel(d->name)),
                                 Arg::L(pn), Arg::I((long long)d->params.size()),
                                 Arg::L(bodyLbl)};
        args.push_back(d->hasParent ? Arg::L(strLabel(d->parentName)) : Arg::I(0));
        args.push_back(d->hasParent ? Arg::L(pargsLbl) : Arg::I(0));
        call(f, "em_class_decl", args);
    }

    //======================= whole functions =======================

    void emitFunction(const Pending& p) {
        FuncCtx f;
        f.label = p.label;
        f.kind = p.kind;
        f.retLabel = ".Lret_" + p.label;
        f.envSlot = f.alloc();                          // env lives in slot 0
        f.o << "\tmovq\t%rdi, " << FuncCtx::slotRef(f.envSlot) << "\n";
        if (p.kind == FnKind::Pargs) {
            f.outSlot = f.alloc();
            f.o << "\tmovq\t%rsi, " << FuncCtx::slotRef(f.outSlot) << "\n";
        }

        if (p.kind == FnKind::Top) {
            for (auto& st : *pendingTop_[p.label]) emitStmt(f, st.get());
        } else if (p.kind == FnKind::Fn) {
            auto* d = static_cast<FnDecl*>(p.node);
            for (auto& st : d->body->statements) emitStmt(f, st.get());
        } else if (p.kind == FnKind::Body) {
            auto* d = static_cast<ClassDecl*>(p.node);
            for (auto& st : d->body->statements) emitStmt(f, st.get());
        } else { // Pargs: evaluate parent ctor args, clone each into out[i]
            auto* d = static_cast<ClassDecl*>(p.node);
            for (size_t i = 0; i < d->parentArgs.size(); i++) {
                emitPos(f, d->parentArgs[i].get());
                int v = emitExpr(f, d->parentArgs[i].get());
                call(f, "em_clone", {Arg::S(v)});
                f.free(v);
                f.o << "\tmovq\t" << FuncCtx::slotRef(f.outSlot) << ", %r10\n";
                f.o << "\tmovq\t%rax, " << 8 * i << "(%r10)\n";
            }
        }

        // Fallthrough return value.
        if (p.kind == FnKind::Fn)        f.o << "\tcall\tem_nil\n";
        else if (p.kind == FnKind::Pargs) {
            auto* d = static_cast<ClassDecl*>(p.node);
            f.o << "\tmovq\t$" << d->parentArgs.size() << ", %rax\n";
        }
        f.o << f.retLabel << ":\n";
        f.o << "\tmovq\t%rbp, %rsp\n\tpopq\t%rbp\n\tret\n";

        // Patch the frame size and argv placeholders, then append.
        long long frame = 24 + 8LL * f.maxSlots + 8LL * f.maxArgs;
        frame = (frame + 15) & ~15LL;
        std::string body = f.o.str();
        for (int j = 0; j < f.maxArgs; j++) {
            std::string ph = "@AV" + std::to_string(j) + "@";
            std::string real = "-" + std::to_string(frame - 16 - 8LL * j) + "(%rbp)";
            size_t pos;
            while ((pos = body.find(ph)) != std::string::npos)
                body.replace(pos, ph.size(), real);
        }
        text_ << "\t.globl\t" << p.label << "\n\t.type\t" << p.label << ", @function\n"
              << p.label << ":\n\tpushq\t%rbp\n\tmovq\t%rsp, %rbp\n"
              << "\tsubq\t$" << frame << ", %rsp\n" << body
              << "\t.size\t" << p.label << ", .-" << p.label << "\n\n";
    }

    void emitConstsFn() {
        text_ << "\t.globl\tem_consts\nem_consts:\n\tpushq\t%rbp\n\tmovq\t%rsp, %rbp\n";
        for (auto& cb : constBuilders_) {
            text_ << cb.second;
            text_ << "\tmovq\t%rax, " << cb.first << "(%rip)\n";
        }
        text_ << "\tpopq\t%rbp\n\tret\n\n";
    }

    void emitMain(const std::vector<std::pair<std::string, std::string>>& moduleInits) {
        text_ << "\t.globl\tmain\n\t.type\tmain, @function\nmain:\n"
              << "\tpushq\t%rbp\n\tmovq\t%rsp, %rbp\n"
              << "\tcall\tem_rt_init\n\tcall\tem_consts\n";
        for (auto& m : moduleInits) {
            text_ << "\tleaq\t" << strLabel(m.first) << "(%rip), %rdi\n"
                  << "\tleaq\t" << m.second << "(%rip), %rsi\n"
                  << "\tcall\tem_module_register\n";
        }
        text_ << "\tcall\tem_globals\n\tmovq\t%rax, %rdi\n\tcall\temtop\n"
              << "\tmovl\t$0, %eax\n\tpopq\t%rbp\n\tret\n"
              << "\t.size\tmain, .-main\n\n";
    }
};

//======================= import resolution (compile time) =======================

static std::string dirOf(const std::string& path) {
    size_t slash = path.find_last_of('/');
    return slash == std::string::npos ? std::string(".") : path.substr(0, slash);
}
static bool readFile(const std::string& path, std::string& out) {
    std::ifstream in(path, std::ios::binary);
    if (!in.good()) return false;
    std::stringstream ss;
    ss << in.rdbuf();
    out = ss.str();
    return true;
}
static std::string findModuleFile(const std::string& name, const std::string& scriptDir) {
    const char* exts[] = {".em", ".emerald"};
    std::string dirs[] = {scriptDir, "."};
    for (auto& d : dirs)
        for (auto* e : exts) {
            std::string cand = d + "/" + name + e;
            std::ifstream probe(cand);
            if (probe.good()) return cand;
        }
    return "";
}

struct ModuleSet {
    std::vector<std::pair<std::string, Program*>> ordered;   // dependency order
    std::vector<std::unique_ptr<Program>> owner;
    std::vector<std::string> names;
    bool has(const std::string& n) {
        for (auto& x : names) if (x == n) return true;
        return false;
    }
};

static void collectImports(Node* n, std::vector<Import*>& out);
static void collectImportsBlock(Block* b, std::vector<Import*>& out) {
    if (!b) return;
    for (auto& s : b->statements) collectImports(s.get(), out);
}
static void collectImports(Node* n, std::vector<Import*>& out) {
    if (!n) return;
    switch (n->kind) {
        case NodeKind::Import:     out.push_back(static_cast<Import*>(n)); return;
        case NodeKind::Block:      collectImportsBlock(static_cast<Block*>(n), out); return;
        case NodeKind::FnDecl:     collectImportsBlock(static_cast<FnDecl*>(n)->body.get(), out); return;
        case NodeKind::ClassDecl:  collectImportsBlock(static_cast<ClassDecl*>(n)->body.get(), out); return;
        case NodeKind::If:
            for (auto& br : static_cast<If*>(n)->branches)
                collectImportsBlock(br.body.get(), out);
            return;
        case NodeKind::ForClassic: {
            auto* s = static_cast<ForClassic*>(n);
            collectImports(s->init.get(), out);
            collectImportsBlock(s->body.get(), out);
            return;
        }
        case NodeKind::ForIn:  collectImportsBlock(static_cast<ForIn*>(n)->body.get(), out); return;
        case NodeKind::While:  collectImportsBlock(static_cast<While*>(n)->body.get(), out); return;
        default: return;
    }
}

static void resolveModules(Program& prog, const std::string& scriptDir, ModuleSet& mods) {
    std::vector<Import*> imports;
    for (auto& s : prog.statements) collectImports(s.get(), imports);
    for (auto* imp : imports) {
        if (mods.has(imp->moduleName)) continue;
        std::string path = findModuleFile(imp->moduleName, scriptDir);
        if (path.empty()) {
            std::fprintf(stderr,
                "emeraldc: cannot find module '%s' (looked for %s.em / %s.emerald)\n",
                imp->moduleName.c_str(), imp->moduleName.c_str(), imp->moduleName.c_str());
            std::exit(1);
        }
        std::string src;
        readFile(path, src);
        Lexer lx(src, path);
        Parser ps(lx.tokenize());
        auto p = ps.parseProgram();
        mods.names.push_back(imp->moduleName);
        Program* raw = p.get();
        mods.owner.push_back(std::move(p));
        resolveModules(*raw, scriptDir, mods);          // depth-first: deps come first
        mods.ordered.push_back({imp->moduleName, raw});
    }
}

//======================= driver =======================

static std::string exeDir() {
    char buf[4096];
    ssize_t n = readlink("/proc/self/exe", buf, sizeof buf - 1);
    if (n <= 0) return ".";
    buf[n] = 0;
    return dirOf(buf);
}
static bool fileExists(const std::string& p) {
    std::ifstream f(p);
    return f.good();
}
static std::string shellQuote(const std::string& s) {
    std::string out = "'";
    for (char c : s) { if (c == '\'') out += "'\\''"; else out += c; }
    return out + "'";
}

int main(int argc, char** argv) {
    std::string inPath, outPath, asmPath;
    bool keepAsm = false, verbose = false;
    for (int i = 1; i < argc; i++) {
        std::string a = argv[i];
        if (a == "-o" && i + 1 < argc)      outPath = argv[++i];
        else if (a == "-S" && i + 1 < argc) asmPath = argv[++i];
        else if (a == "--keep-asm")         keepAsm = true;
        else if (a == "-v")                 verbose = true;
        else if (a == "-h" || a == "--help") {
            std::puts("usage: emeraldc file.em [-o out] [-S out.s] [--keep-asm] [-v]");
            return 0;
        }
        else if (!a.empty() && a[0] == '-') {
            std::fprintf(stderr, "emeraldc: unknown option '%s'\n", a.c_str());
            return 2;
        }
        else inPath = a;
    }
    if (inPath.empty()) {
        std::fprintf(stderr, "emeraldc: no input file\nusage: emeraldc file.em [-o out]\n");
        return 2;
    }
    std::string src;
    if (!readFile(inPath, src)) {
        std::fprintf(stderr, "emeraldc: cannot open '%s'\n", inPath.c_str());
        return 1;
    }
    if (outPath.empty()) {
        std::string base = inPath;
        size_t slash = base.find_last_of('/');
        if (slash != std::string::npos) base = base.substr(slash + 1);
        size_t dot = base.find_last_of('.');
        if (dot != std::string::npos) base = base.substr(0, dot);
        outPath = base.empty() ? "a.out" : base;
    }

    std::string assembly;
    try {
        Lexer lexer(src, inPath);
        Parser parser(lexer.tokenize());
        auto program = parser.parseProgram();
        ModuleSet mods;
        resolveModules(*program, dirOf(inPath), mods);
        CodeGen cg;
        assembly = cg.compile(*program, mods.ordered);
        if (verbose)
            std::fprintf(stderr, "emeraldc: %zu module(s), %zu bytes of assembly\n",
                         mods.ordered.size(), assembly.size());
    } catch (const EmeraldError& e) {
        std::fprintf(stderr, "emeraldc: %s", e.stage.c_str());
        if (e.line >= 0) {
            std::fprintf(stderr, " at line %d", e.line);
            if (e.col >= 0) std::fprintf(stderr, ", col %d", e.col);
        }
        std::fprintf(stderr, ": %s\n", e.what());
        return 1;
    } catch (const CompileError& e) {
        std::fprintf(stderr, "emeraldc: compile error at line %d, col %d: %s\n",
                     e.line, e.col, e.msg.c_str());
        return 1;
    }

    std::string sPath = !asmPath.empty() ? asmPath
                       : keepAsm ? outPath + ".s"
                       : "/tmp/emeraldc_" + std::to_string(getpid()) + ".s";
    {
        std::ofstream sf(sPath, std::ios::binary);
        sf << assembly;
    }
    if (!asmPath.empty() && outPath.empty()) return 0;

    // Locate the runtime archive next to the compiler binary (or via env).
    std::string home = exeDir();
    std::string lib;
    const char* envHome = std::getenv("EMERALDC_HOME");
    for (std::string cand : {envHome ? std::string(envHome) + "/libemrt.a" : "",
                             home + "/libemrt.a", home + "/../lib/libemrt.a"}) {
        if (!cand.empty() && fileExists(cand)) { lib = cand; break; }
    }
    if (lib.empty()) {
        std::fprintf(stderr, "emeraldc: cannot find libemrt.a (set EMERALDC_HOME)\n");
        return 1;
    }
    std::string oPath = "/tmp/emeraldc_" + std::to_string(getpid()) + ".o";
    std::string cmd1 = "as --64 -o " + shellQuote(oPath) + " " + shellQuote(sPath);
    std::string cmd2 = "g++ -o " + shellQuote(outPath) + " " + shellQuote(oPath) + " " +
                       shellQuote(lib) + " -lm";
    if (verbose) std::fprintf(stderr, "emeraldc: %s\nemeraldc: %s\n", cmd1.c_str(), cmd2.c_str());
    if (std::system(cmd1.c_str()) != 0) {
        std::fprintf(stderr, "emeraldc: assembler failed (asm kept at %s)\n", sPath.c_str());
        return 1;
    }
    if (std::system(cmd2.c_str()) != 0) {
        std::fprintf(stderr, "emeraldc: linker failed\n");
        return 1;
    }
    std::remove(oPath.c_str());
    if (asmPath.empty() && !keepAsm) std::remove(sPath.c_str());
    return 0;
}
