// rt.cpp - Runtime library for the emeraldc x86-64 compiler.
//
// Generated machine code performs all control flow, function calls and
// sequencing natively, and calls the extern "C" functions below for the
// dynamic-language operations. The Value / Environment / SQL / builtin
// machinery is the interpreter's own (vendored), so behaviour is identical
// to the reference implementation by construction.
//
// Conventions of the ABI:
//   * `void*` handles are `emerald::Value*` (heap "boxes") or
//     `emerald::Environment*` (raw pointers to pinned shared_ptr envs).
//   * Value boxes are immutable once returned; all mutation happens inside
//     the containers they reference (arrays/objects share inner state via
//     shared_ptr exactly as in the interpreter).
//   * Every entry point traps EmeraldError and control-flow signals and
//     reports them in the interpreter's own format, then exits(1) - C++
//     exceptions must never unwind through generated frames.
//   * Memory: boxes, environments and iterators are pinned for the lifetime
//     of the process (no GC in v1; see README).

#include "../vendored/value.h"
#include "../vendored/environment.h"
#include "../vendored/errors.h"
#include "../vendored/interpreter.h"
#include "rt_hooks.h"

#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <cmath>
#include <cctype>
#include <deque>
#include <memory>
#include <string>
#include <unordered_map>
#include <vector>

using namespace emerald;

//======================= process-global state =======================

static Interpreter* g_interp = nullptr;
extern "C" { long long em_line = -1, em_col = -1; }  // written by generated code

// Pins keeping shared_ptr-managed things alive while raw pointers circulate.
static std::deque<std::shared_ptr<Environment>>      g_envPins;
static std::unordered_map<std::string, void*>        g_moduleInits;
static std::unordered_map<std::string, Value>        g_moduleCache;
static std::vector<std::string>                      g_importing;

static Value* box(Value v) { return new Value(std::move(v)); }
static Environment* pin(std::shared_ptr<Environment> e) {
    Environment* raw = e.get();
    g_envPins.push_back(std::move(e));
    return raw;
}
// Recover the shared_ptr for a pinned raw Environment*.
static std::shared_ptr<Environment> shared_env(void* raw) {
    return static_cast<Environment*>(raw)->shared_from_this();
}
static Value& V(void* p) { return *static_cast<Value*>(p); }

[[noreturn]] static void die(const EmeraldError& e) {
    std::fflush(stdout);
    std::fprintf(stderr, "emerald: %s", e.stage.c_str());
    long long line = e.line >= 0 ? e.line : em_line;
    long long col  = e.line >= 0 ? e.col  : em_col;
    if (line >= 0) {
        std::fprintf(stderr, " at line %lld", line);
        if (col >= 0) std::fprintf(stderr, ", col %lld", col);
    }
    std::fprintf(stderr, ": %s\n", e.what());
    std::exit(1);
}
[[noreturn]] static void die_internal(const char* what) {
    std::fflush(stdout);
    std::fprintf(stderr, "emerald: internal error: %s\n", what);
    std::exit(1);
}

#define GUARD_BEGIN try {
#define GUARD_END                                                       \
    } catch (const EmeraldError& e)   { die(e); }                       \
      catch (const std::exception& e) { die_internal(e.what()); }       \
      catch (...)                     { die_internal("unknown exception"); }

static int LI() { return static_cast<int>(em_line); }
static int CO() { return static_cast<int>(em_col); }

//======================= hooks used by the patched interpreter =======================

typedef Value*    (*NativeFn)(void* env);
typedef void      (*NativeBody)(void* env);
typedef long long (*NativeArgs)(void* env, Value** out);

Value em_native_call(void* fnptr, const std::shared_ptr<Environment>& callEnv) {
    Value* r = reinterpret_cast<NativeFn>(fnptr)(callEnv.get());
    return r ? *r : Value::makeNil();
}
std::vector<Value> em_native_parent_args(void* fnptr,
                                         const std::shared_ptr<Environment>& env) {
    Value* out[64]; // parser-level realism: constructor arg lists are tiny
    long long n = reinterpret_cast<NativeArgs>(fnptr)(env.get(), out);
    std::vector<Value> args;
    args.reserve(static_cast<size_t>(n));
    for (long long i = 0; i < n; i++) args.push_back(*out[i]);
    return args;
}
void em_native_body(void* fnptr, const std::shared_ptr<Environment>& env) {
    reinterpret_cast<NativeBody>(fnptr)(env.get());
}

//======================= the extern "C" ABI =======================

extern "C" {

//--- lifecycle -------------------------------------------------------------

void em_rt_init(void) {
    GUARD_BEGIN
    static Interpreter interp;   // installs builtins, pi/e, SQL engine
    g_interp = &interp;
    g_envPins.push_back(interp.globals());
    GUARD_END
}
void* em_globals(void) { return g_interp->globals().get(); }
void  em_pos(long long line, long long col) { em_line = line; em_col = col; }

//--- environments -----------------------------------------------------------

void* em_env_new(void* parent) {
    GUARD_BEGIN
    return pin(std::make_shared<Environment>(shared_env(parent)));
    GUARD_END
}
void* em_env_get(void* env, const char* name) {
    GUARD_BEGIN
    return box(static_cast<Environment*>(env)->get(name, LI(), CO()));
    GUARD_END
}
void em_env_define(void* env, const char* name, void* v) {
    GUARD_BEGIN
    static_cast<Environment*>(env)->define(name, V(v));
    GUARD_END
}
void em_env_declare(void* env, const char* name, void* v) {
    GUARD_BEGIN
    static_cast<Environment*>(env)->declare(name, V(v));
    GUARD_END
}
void em_env_assign(void* env, const char* name, void* v) {
    GUARD_BEGIN
    static_cast<Environment*>(env)->assign(name, V(v));
    GUARD_END
}

//--- literal constructors ----------------------------------------------------

void* em_nil(void)                 { return box(Value::makeNil()); }
void* em_bool(long long b)         { return box(Value::makeBool(b != 0)); }
void* em_int(long long i)          { return box(Value::makeInt(i)); }
void* em_float_bits(long long bits){ double d; std::memcpy(&d, &bits, 8);
                                     return box(Value::makeFloat(d)); }
void* em_char(long long c)         { return box(Value::makeChar(static_cast<char>(c))); }
void* em_string(const char* p, long long n) {
    return box(Value::makeString(std::string(p, static_cast<size_t>(n))));
}
void* em_clone(void* v)            { GUARD_BEGIN return box(V(v).clone()); GUARD_END }

void* em_arraylit(void** elems, long long n) {
    GUARD_BEGIN
    std::vector<Value> es;
    es.reserve(static_cast<size_t>(n));
    for (long long i = 0; i < n; i++) es.push_back(V(elems[i]).clone());
    return box(Value::makeArray(std::move(es)));
    GUARD_END
}

// String interpolation: parts are already Values; literal segments arrive as
// String boxes. Mirrors Interpreter::evalStringLit (toString on every part).
void* em_interp(void** parts, long long n) {
    GUARD_BEGIN
    std::string out;
    for (long long i = 0; i < n; i++) out += V(parts[i]).toString();
    return box(Value::makeString(std::move(out)));
    GUARD_END
}

//--- operators ----------------------------------------------------------------

// Faithful port of Interpreter::binaryNumeric / evalBinary "+" special cases.
static bool numericIsInt(const Value& v) {
    return v.type == ValueType::Int || v.type == ValueType::Char ||
           v.type == ValueType::Bool;
}
static Value binNumeric(const char* op, const Value& l, const Value& r) {
    if ((!l.isNumeric() && l.type != ValueType::Bool))
        throw RuntimeError(std::string("Left operand of '") + op +
                           "' is not numeric (got " + l.typeName() + ")", LI(), CO());
    if ((!r.isNumeric() && r.type != ValueType::Bool))
        throw RuntimeError(std::string("Right operand of '") + op +
                           "' is not numeric (got " + r.typeName() + ")", LI(), CO());
    bool bothInt = numericIsInt(l) && numericIsInt(r);
    std::string o = op;
    if (o == "+") return bothInt ? Value::makeInt(l.asInt() + r.asInt())
                                 : Value::makeFloat(l.asDouble() + r.asDouble());
    if (o == "-") return bothInt ? Value::makeInt(l.asInt() - r.asInt())
                                 : Value::makeFloat(l.asDouble() - r.asDouble());
    if (o == "*") return bothInt ? Value::makeInt(l.asInt() * r.asInt())
                                 : Value::makeFloat(l.asDouble() * r.asDouble());
    if (o == "/") {
        double rd = r.asDouble();
        if (rd == 0.0) throw RuntimeError("Division by zero", LI(), CO());
        return Value::makeFloat(l.asDouble() / rd);
    }
    if (o == "//") {
        if (bothInt) {
            long long ri = r.asInt();
            if (ri == 0) throw RuntimeError("Division by zero", LI(), CO());
            long long li = l.asInt(), q = li / ri;
            if ((li % ri != 0) && ((li < 0) != (ri < 0))) q--;
            return Value::makeInt(q);
        }
        double rd = r.asDouble();
        if (rd == 0.0) throw RuntimeError("Division by zero", LI(), CO());
        return Value::makeFloat(std::floor(l.asDouble() / rd));
    }
    if (o == "%") {
        if (bothInt) {
            long long ri = r.asInt();
            if (ri == 0) throw RuntimeError("Modulo by zero", LI(), CO());
            long long m = l.asInt() % ri;
            if (m != 0 && ((m < 0) != (ri < 0))) m += ri;
            return Value::makeInt(m);
        }
        double rd = r.asDouble();
        if (rd == 0.0) throw RuntimeError("Modulo by zero", LI(), CO());
        double m = std::fmod(l.asDouble(), rd);
        if (m != 0.0 && ((m < 0) != (rd < 0))) m += rd;
        return Value::makeFloat(m);
    }
    if (o == "**") {
        if (bothInt && r.asInt() >= 0) {
            long long base = l.asInt(), exp = r.asInt(), result = 1;
            while (exp > 0) { if (exp & 1) result *= base; base *= base; exp >>= 1; }
            return Value::makeInt(result);
        }
        return Value::makeFloat(std::pow(l.asDouble(), r.asDouble()));
    }
    throw RuntimeError(std::string("Unknown numeric operator '") + op + "'", LI(), CO());
}

void* em_add(void* a, void* b) {
    GUARD_BEGIN
    const Value& l = V(a); const Value& r = V(b);
    if (l.type == ValueType::String || r.type == ValueType::String)
        return box(Value::makeString(l.toString() + r.toString()));
    if (l.type == ValueType::Array && r.type == ValueType::Array) {
        std::vector<Value> combined;
        combined.reserve(l.arr->size() + r.arr->size());
        for (auto& v : *l.arr) combined.push_back(v.clone());
        for (auto& v : *r.arr) combined.push_back(v.clone());
        return box(Value::makeArray(std::move(combined)));
    }
    return box(binNumeric("+", l, r));
    GUARD_END
}
#define BINOP(name, tok) \
    void* name(void* a, void* b) { GUARD_BEGIN return box(binNumeric(tok, V(a), V(b))); GUARD_END }
BINOP(em_sub,  "-")
BINOP(em_mul,  "*")
BINOP(em_div,  "/")
BINOP(em_fdiv, "//")
BINOP(em_mod,  "%")
BINOP(em_pow,  "**")

// Loose / strict equality: ports of Interpreter::looseEquals / strictEquals.
static bool looseEq(const Value& l, const Value& r);
static bool strictEq(const Value& l, const Value& r) {
    if (l.type != r.type) return false;
    switch (l.type) {
        case ValueType::Nil:    return true;
        case ValueType::Int:    return l.i == r.i;
        case ValueType::Float:  return l.f == r.f;
        case ValueType::Char:   return l.c == r.c;
        case ValueType::Bool:   return l.b == r.b;
        case ValueType::String: return *l.str == *r.str;
        default:                return looseEq(l, r);
    }
}
static bool looseEq(const Value& l, const Value& r) {
    if (l.isNil() || r.isNil()) return l.isNil() && r.isNil();
    auto asStr = [](const Value& v, std::string& out) -> bool {
        if (v.type == ValueType::String) { out = *v.str; return true; }
        if (v.type == ValueType::Char)   { out = std::string(1, v.c); return true; }
        return false;
    };
    bool lNum = l.isNumeric() || l.type == ValueType::Bool;
    bool rNum = r.isNumeric() || r.type == ValueType::Bool;
    if (l.type == ValueType::String || r.type == ValueType::String) {
        std::string ls, rs;
        bool lOk = asStr(l, ls), rOk = asStr(r, rs);
        if (lOk && rOk) return ls == rs;
        const Value& s = lOk ? l : r;
        const Value& n = lOk ? r : l;
        if (n.isNumeric() || n.type == ValueType::Bool) {
            try {
                size_t pos = 0;
                double parsed = std::stod(*s.str, &pos);
                while (pos < s.str->size() &&
                       std::isspace(static_cast<unsigned char>((*s.str)[pos]))) pos++;
                if (pos != s.str->size()) return false;
                return parsed == n.asDouble();
            } catch (...) { return false; }
        }
        return false;
    }
    if (lNum && rNum) return l.asDouble() == r.asDouble();
    if (l.type == ValueType::Array && r.type == ValueType::Array) {
        if (l.arr->size() != r.arr->size()) return false;
        for (size_t i = 0; i < l.arr->size(); i++)
            if (!looseEq((*l.arr)[i], (*r.arr)[i])) return false;
        return true;
    }
    if (l.type == ValueType::Object && r.type == ValueType::Object) {
        if (l.obj == r.obj) return true;
        if (l.obj->fields.size() != r.obj->fields.size()) return false;
        for (auto& kv : l.obj->fields) {
            auto it = r.obj->fields.find(kv.first);
            if (it == r.obj->fields.end()) return false;
            if (!looseEq(kv.second, it->second)) return false;
        }
        return true;
    }
    if (l.type == ValueType::Class    && r.type == ValueType::Class)    return l.cls == r.cls;
    if (l.type == ValueType::Function && r.type == ValueType::Function) return l.fn == r.fn;
    if (l.type == ValueType::File     && r.type == ValueType::File)     return l.file->path == r.file->path;
    return false;
}
void* em_eq(void* a, void* b, long long strict, long long negate) {
    GUARD_BEGIN
    bool eq = strict ? strictEq(V(a), V(b)) : looseEq(V(a), V(b));
    return box(Value::makeBool(negate ? !eq : eq));
    GUARD_END
}

// Ordering comparisons: port of Interpreter::compareValues.
static int cmpVals(const Value& l, const Value& r) {
    if ((l.type == ValueType::String || l.type == ValueType::Char) &&
        (r.type == ValueType::String || r.type == ValueType::Char)) {
        std::string ls = l.type == ValueType::Char ? std::string(1, l.c) : *l.str;
        std::string rs = r.type == ValueType::Char ? std::string(1, r.c) : *r.str;
        return ls.compare(rs) < 0 ? -1 : (ls == rs ? 0 : 1);
    }
    double ld = l.asDouble(), rd = r.asDouble();
    return ld < rd ? -1 : (ld == rd ? 0 : 1);
}
void* em_cmp(void* a, void* b, long long op) {
    GUARD_BEGIN
    int c = cmpVals(V(a), V(b));
    bool res = op == 0 ? c < 0 : op == 1 ? c <= 0 : op == 2 ? c > 0 : c >= 0;
    return box(Value::makeBool(res));
    GUARD_END
}

long long em_truthy(void* v) { GUARD_BEGIN return V(v).truthy() ? 1 : 0; GUARD_END }
void* em_not(void* v) { GUARD_BEGIN return box(Value::makeBool(!V(v).truthy())); GUARD_END }
void* em_neg(void* v) {
    GUARD_BEGIN
    const Value& x = V(v);
    switch (x.type) {
        case ValueType::Int:   return box(Value::makeInt(-x.i));
        case ValueType::Float: return box(Value::makeFloat(-x.f));
        case ValueType::Char:  return box(Value::makeInt(
                                   -static_cast<long long>(static_cast<unsigned char>(x.c))));
        case ValueType::Bool:  return box(Value::makeInt(x.b ? -1 : 0));
        default:
            throw RuntimeError("Cannot negate a value of type '" + x.typeName() + "'",
                               LI(), CO());
    }
    GUARD_END
}
void* em_pos_op(void* v) {
    GUARD_BEGIN
    const Value& x = V(v);
    if (x.isNumeric() || x.type == ValueType::Bool) return box(x);
    throw RuntimeError("Cannot apply unary '+' to a value of type '" +
                       x.typeName() + "'", LI(), CO());
    GUARD_END
}
// Type-preserving ++/-- step: port of Interpreter::applyIncDec.
void* em_incdec_next(void* v, long long delta) {
    GUARD_BEGIN
    const Value& old = V(v);
    switch (old.type) {
        case ValueType::Int:   return box(Value::makeInt(old.i + delta));
        case ValueType::Float: return box(Value::makeFloat(old.f + delta));
        case ValueType::Char:  return box(Value::makeChar(static_cast<char>(old.c + delta)));
        default:
            throw RuntimeError(std::string("Cannot apply '") + (delta > 0 ? "++" : "--") +
                               "' to a value of type '" + old.typeName() + "'", LI(), CO());
    }
    GUARD_END
}

//--- assignment helpers --------------------------------------------------------

// Matches evalAssign: assigning a class value instantiates it; then clone.
void* em_assign_prepare(void* v) {
    GUARD_BEGIN
    Value val = V(v);
    if (val.type == ValueType::Class) {
        std::vector<Value> noArgs;
        val = g_interp->rtInstantiate(val.cls, noArgs, LI(), CO());
    }
    return box(val.clone());
    GUARD_END
}

//--- members & indexing ---------------------------------------------------------

void* em_member_get(void* o, const char* name) {
    GUARD_BEGIN
    const Value& obj = V(o);
    switch (obj.type) {
        case ValueType::Object: {
            if (obj.obj->hasField(name)) return box(obj.obj->getField(name));
            throw RuntimeError("Object of class '" +
                               (obj.obj->cls ? obj.obj->cls->name : "?") +
                               "' has no member '" + name + "'", LI(), CO());
        }
        case ValueType::Module: {
            Value out;
            if (obj.mod->env->getOwn(name, out)) return box(out);
            throw RuntimeError("Module '" + obj.mod->name + "' has no member '" +
                               name + "'", LI(), CO());
        }
        case ValueType::Table: {
            std::string n = name;
            if (n == "rows") return box(Value::makeInt(
                static_cast<long long>(obj.table->rows.size())));
            if (n == "columns") {
                std::vector<Value> cols;
                for (auto& c : obj.table->columns) cols.push_back(Value::makeString(c));
                return box(Value::makeArray(std::move(cols)));
            }
            if (n == "name") return box(Value::makeString(obj.table->name));
            throw RuntimeError("Table has no member '" + n + "'", LI(), CO());
        }
        case ValueType::File: {
            if (std::string(name) == "path") return box(Value::makeString(obj.file->path));
            throw RuntimeError(std::string("File member '") + name +
                               "' must be called as a method", LI(), CO());
        }
        default:
            throw RuntimeError(std::string("Cannot access member '") + name +
                               "' on a value of type '" + obj.typeName() + "'", LI(), CO());
    }
    GUARD_END
}
void em_member_set(void* o, const char* name, void* v) {
    GUARD_BEGIN
    const Value& obj = V(o);
    if (obj.type == ValueType::Object) { obj.obj->setField(name, V(v)); return; }
    if (obj.type == ValueType::Module)
        throw RuntimeError("Cannot assign into module '" + obj.mod->name + "'", LI(), CO());
    throw RuntimeError(std::string("Cannot set member '") + name +
                       "' on a value of type '" + obj.typeName() + "'", LI(), CO());
    GUARD_END
}

void* em_index_get(void* o, void** idxs, long long n) {
    GUARD_BEGIN
    const Value& obj = V(o);
    auto ll = [&](long long k) { return V(idxs[k]).asInt(); };
    if (obj.type == ValueType::Array) {
        if (n == 1) {
            long long i = ll(0);
            if (i < 0 || static_cast<size_t>(i) >= obj.arr->size())
                throw RuntimeError("Array index " + std::to_string(i) +
                                   " out of range (size " +
                                   std::to_string(obj.arr->size()) + ")", LI(), CO());
            return box((*obj.arr)[static_cast<size_t>(i)]);
        }
        std::vector<Value> gathered;
        for (long long k = 0; k < n; k++) {
            long long i = ll(k);
            if (i < 0 || static_cast<size_t>(i) >= obj.arr->size())
                throw RuntimeError("Array index " + std::to_string(i) +
                                   " out of range (size " +
                                   std::to_string(obj.arr->size()) + ")", LI(), CO());
            gathered.push_back((*obj.arr)[static_cast<size_t>(i)].clone());
        }
        return box(Value::makeArray(std::move(gathered)));
    }
    if (obj.type == ValueType::String) {
        const std::string& s = *obj.str;
        if (n == 1) {
            long long i = ll(0);
            if (i < 0 || static_cast<size_t>(i) >= s.size())
                throw RuntimeError("String index " + std::to_string(i) +
                                   " out of range (length " +
                                   std::to_string(s.size()) + ")", LI(), CO());
            return box(Value::makeChar(s[static_cast<size_t>(i)]));
        }
        std::string gathered;
        for (long long k = 0; k < n; k++) {
            long long i = ll(k);
            if (i < 0 || static_cast<size_t>(i) >= s.size())
                throw RuntimeError("String index " + std::to_string(i) +
                                   " out of range (length " +
                                   std::to_string(s.size()) + ")", LI(), CO());
            gathered += s[static_cast<size_t>(i)];
        }
        return box(Value::makeString(std::move(gathered)));
    }
    if (obj.type == ValueType::Table && n == 1) {
        long long i = ll(0);
        if (i < 0 || static_cast<size_t>(i) >= obj.table->rows.size())
            throw RuntimeError("Table row " + std::to_string(i) + " out of range",
                               LI(), CO());
        return box(Value::makeArray(obj.table->rows[static_cast<size_t>(i)]));
    }
    throw RuntimeError("Cannot index a value of type '" + obj.typeName() + "'",
                       LI(), CO());
    GUARD_END
}
void em_index_set(void* o, void* idx, void* v) {
    GUARD_BEGIN
    const Value& obj = V(o);
    if (obj.type != ValueType::Array)
        throw RuntimeError("Cannot index-assign into a value of type '" +
                           obj.typeName() + "'", LI(), CO());
    long long i = V(idx).asInt();
    if (i < 0) throw RuntimeError("Negative array index", LI(), CO());
    if (static_cast<size_t>(i) >= obj.arr->size())
        obj.arr->resize(static_cast<size_t>(i) + 1, Value::makeNil());
    (*obj.arr)[static_cast<size_t>(i)] = V(v);
    GUARD_END
}
void em_index_set_multi_error(void) {
    GUARD_BEGIN
    throw RuntimeError("Cannot assign to a multi-index gather", LI(), CO());
    GUARD_END
}

//--- calls -----------------------------------------------------------------------

void* em_call_value(void* callee, void** args, long long n) {
    GUARD_BEGIN
    std::vector<Value> a;
    a.reserve(static_cast<size_t>(n));
    for (long long i = 0; i < n; i++) a.push_back(V(args[i]).clone());
    return box(g_interp->rtCallValue(V(callee), a, LI(), CO()));
    GUARD_END
}

// receiver.name(args): builtin method first (uncloned args), then object
// method / module member with cloned args - mirrors evalCall's Member branch.
// `readStmtCtx` reproduces the standalone `file.read(...)` printing rule.
void* em_method_call(void* recv, const char* name, void** args, long long n,
                     long long trailingComma, long long readStmtCtx) {
    GUARD_BEGIN
    const Value& receiver = V(recv);
    std::vector<Value> a;
    a.reserve(static_cast<size_t>(n));
    for (long long i = 0; i < n; i++) a.push_back(V(args[i]));

    Value result;
    bool handled = g_interp->rtBuiltinMethod(receiver, name, a,
                                             trailingComma != 0, LI(), CO(), result);
    if (!handled) {
        Value callee;
        if (receiver.type == ValueType::Object && receiver.obj->hasField(name)) {
            callee = receiver.obj->getField(name);
        } else if (receiver.type == ValueType::Module) {
            if (!receiver.mod->env->getOwn(name, callee))
                throw RuntimeError("Module '" + receiver.mod->name +
                                   "' has no member '" + name + "'", LI(), CO());
        } else {
            throw RuntimeError(std::string("No method '") + name +
                               "' on a value of type '" + receiver.typeName() + "'",
                               LI(), CO());
        }
        for (auto& x : a) x = x.clone();
        result = g_interp->rtCallValue(callee, a, LI(), CO());
    }
    if (readStmtCtx && std::string(name) == "read" &&
        result.type == ValueType::String) {
        std::fwrite(result.str->data(), 1, result.str->size(), stdout);
        if (result.str->empty() || result.str->back() != '\n') std::fputc('\n', stdout);
    }
    return box(result);
    GUARD_END
}

//--- declarations ------------------------------------------------------------------

// Full port of Interpreter::execVarDecl against the compiled world.
void em_vardecl(void* env, const char* typeName, const char* name,
                long long isArray, void* init /*nullable*/,
                void** ctorArgs, long long nCtor) {
    GUARD_BEGIN
    Environment* e = static_cast<Environment*>(env);
    std::string t = typeName;

    if (isArray) {
        Value v = init ? V(init).clone() : Value::makeArray({});
        if (v.type != ValueType::Array && !v.isNil())
            throw RuntimeError(std::string("Array declaration of '") + name +
                               "' requires an array initializer", LI(), CO());
        e->declare(name, v);
        return;
    }
    if (t == "File") {
        std::string path;
        if (init) {
            const Value& v = V(init);
            if (v.type != ValueType::String)
                throw RuntimeError("File path must be a string", LI(), CO());
            path = *v.str;
        } else {
            path = name;
        }
        auto fd = std::make_shared<FileData>();
        fd->path = path;
        {
            std::FILE* probe = std::fopen(path.c_str(), "rb");
            if (probe) { std::fclose(probe); }
            else {
                std::FILE* touch = std::fopen(path.c_str(), "wb");
                if (!touch)
                    throw RuntimeError("Cannot create file '" + path + "'", LI(), CO());
                std::fclose(touch);
            }
        }
        e->declare(name, Value::makeFile(fd));
        return;
    }
    if (t == "int" || t == "float" || t == "char" || t == "string") {
        Value v;
        if (init) {
            v = g_interp->rtCoerce(t, V(init), LI(), CO());
        } else {
            if (t == "int") v = Value::makeInt(0);
            else if (t == "float") v = Value::makeFloat(0.0);
            else if (t == "char") v = Value::makeChar('\0');
            else v = Value::makeString("");
        }
        e->declare(name, v.clone());
        return;
    }
    // Class-typed declaration.
    Value classVal = e->get(t, LI(), CO());
    if (classVal.type != ValueType::Class)
        throw RuntimeError("'" + t + "' is not a class", LI(), CO());
    if (init) {
        Value v = V(init);
        if (v.type == ValueType::Class) {
            std::vector<Value> noArgs;
            v = g_interp->rtInstantiate(v.cls, noArgs, LI(), CO());
        }
        e->declare(name, v.clone());
        return;
    }
    std::vector<Value> args;
    for (long long i = 0; i < nCtor; i++) args.push_back(V(ctorArgs[i]).clone());
    e->declare(name, g_interp->rtInstantiate(classVal.cls, args, LI(), CO()));
    GUARD_END
}

void em_fn_decl(void* env, const char* name, void* nativeFn,
                const char** params, long long nParams) {
    GUARD_BEGIN
    auto fn = std::make_shared<FunctionData>();
    fn->name = name;
    for (long long i = 0; i < nParams; i++) fn->params.emplace_back(params[i], "");
    fn->native = nativeFn;
    fn->closure = shared_env(env);
    static_cast<Environment*>(env)->declare(name, Value::makeFunction(fn));
    GUARD_END
}

void em_class_decl(void* env, const char* name,
                   const char** params, long long nParams,
                   void* nativeBody, const char* parentName /*nullable*/,
                   void* nativeParentArgs /*nullable*/) {
    GUARD_BEGIN
    Environment* e = static_cast<Environment*>(env);
    auto cls = std::make_shared<ClassData>();
    cls->name = name;
    for (long long i = 0; i < nParams; i++) cls->params.emplace_back(params[i], "");
    cls->closure = shared_env(env);
    cls->nativeBody = nativeBody;
    cls->nativeParentArgs = nativeParentArgs;
    if (parentName) {
        Value parent = e->get(parentName, LI(), CO());
        if (parent.type != ValueType::Class)
            throw RuntimeError(std::string("Parent '") + parentName +
                               "' is not a class", LI(), CO());
        cls->parent = parent.cls;
    }
    e->declare(name, Value::makeClass(cls));
    GUARD_END
}
void em_object_var_decl(void* env, const char* name) {
    GUARD_BEGIN
    static_cast<Environment*>(env)->declare(name, Value::makeNil());
    GUARD_END
}

//--- for-in iteration ----------------------------------------------------------------

struct EmIter { std::vector<Value> items; size_t pos = 0; };
static std::deque<std::unique_ptr<EmIter>> g_iterPins;

void* em_iter_begin(void* seq) {
    GUARD_BEGIN
    const Value& v = V(seq);
    auto it = std::make_unique<EmIter>();
    if (v.type == ValueType::Array) {
        it->items = *v.arr;                       // snapshot, as the interpreter does
    } else if (v.type == ValueType::String) {
        for (char ch : *v.str) it->items.push_back(Value::makeChar(ch));
    } else if (v.type == ValueType::Table) {
        for (auto& row : v.table->rows) it->items.push_back(Value::makeArray(row));
    } else {
        throw RuntimeError("Cannot iterate over a value of type '" +
                           v.typeName() + "'", LI(), CO());
    }
    EmIter* raw = it.get();
    g_iterPins.push_back(std::move(it));
    return raw;
    GUARD_END
}
void* em_iter_next(void* iter) {   // NULL when exhausted; element clone otherwise
    GUARD_BEGIN
    EmIter* it = static_cast<EmIter*>(iter);
    if (it->pos >= it->items.size()) return nullptr;
    return box(it->items[it->pos++].clone());     // pass-by-value into the loop var
    GUARD_END
}

//--- modules -----------------------------------------------------------------------

void em_module_register(const char* name, void* initFn) {
    g_moduleInits[name] = initFn;
}
static Value ensureModule(const std::string& name) {
    auto cached = g_moduleCache.find(name);
    if (cached != g_moduleCache.end()) return cached->second;
    auto init = g_moduleInits.find(name);
    if (init == g_moduleInits.end())
        throw RuntimeError("Cannot find module '" + name + "' (looked for " +
                           name + ".em / " + name + ".emerald)", LI(), CO());
    for (auto& n : g_importing)
        if (n == name)
            throw RuntimeError("Circular import of module '" + name + "'", LI(), CO());
    g_importing.push_back(name);
    auto moduleEnv = std::make_shared<Environment>(g_interp->globals());
    Environment* raw = pin(moduleEnv);
    reinterpret_cast<NativeBody>(init->second)(raw);
    g_importing.pop_back();
    auto mod = std::make_shared<ModuleData>();
    mod->name = name;
    mod->env = moduleEnv;
    Value v = Value::makeModule(mod);
    g_moduleCache[name] = v;
    return v;
}
void em_import(void* env, const char* moduleName) {
    GUARD_BEGIN
    Value mod = ensureModule(moduleName);
    static_cast<Environment*>(env)->declare(moduleName, mod);
    GUARD_END
}
void em_import_from(void* env, const char* moduleName, const char* symbolName) {
    GUARD_BEGIN
    Value mod = ensureModule(moduleName);
    Value symbol;
    if (!mod.mod->env->getOwn(symbolName, symbol))
        throw RuntimeError(std::string("Module '") + moduleName +
                           "' has no symbol '" + symbolName + "'", LI(), CO());
    static_cast<Environment*>(env)->declare(symbolName, symbol);
    GUARD_END
}

} // extern "C"
